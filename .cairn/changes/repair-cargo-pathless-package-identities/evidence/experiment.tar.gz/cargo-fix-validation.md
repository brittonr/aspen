# Cargo package-ID repair

## Scope and ownership

The user authorized a repair after the exact-source diagnostic.
Worktree: `implementation-cargo-fix`.
Branch: `completion/cargo-pathless-package-id-20260913`.
Base: `20e1233f82e42f821913408e8bc6497bab7942b7`.
The worktree was created from fetched `origin/molten`, then fast-forwarded to this base.
The primary checkout and other candidates are outside this implementation scope.

Cargo owns package-ID syntax. Molten's toolchain maintainers own the pinned consumer patch and Nix selection.
The upstream source is `rust-lang/cargo` at `4d1f984518c77fad6eeef4f40153b002a659e662`.
The patch changes deterministic formatter and parser decisions in `cargo-util-schemas`.
Nix owns source retrieval, compilation, and tool selection. No metadata rewriting or transport substitution is used.

## Current source evidence

The unmodified schema suite passed 15 tests and one doc test.
The new suite failed four cases before the correction, while 16 tests passed.
The failures include the formatter panic, explicit-name parsing, JSON/reference round-trips, and premature missing-path error classification.
The corrected suite passes all 20 tests and one doc test.

The patch writes an explicit name when a final path component is absent.
It requires a path only when parsing must infer a package name.
Existing fragment disambiguation, name/version validation, protocol rules, and Git reference handling remain in place.
Controls include two real Radicle source identifiers, a pathless SSH URL, optional versions, Git branch/tag/revision selectors, and JSON serialization.
Negative cases cover missing inferred names, empty names/fragments/versions, forbidden queries, unsupported protocols, and invalid `path+` schemes.
The unchanged upstream suite covers ordinary URL compatibility and earlier rejection rules.

The schema commands use the repository compiler and a command-local `RUSTC_WRAPPER=`.
They are source-level evidence, not normal cached-build or installed-Cargo acceptance.
The copied Cargo source retains the upstream lockfile. This round does not independently resolve newer registry dependencies.
The original cached Cargo checkout remains unchanged.
The red source archive includes the applicable upstream license notices and passes archive comparison.

## Nix integration

Nix generated the new `cargo-src` input at the exact upstream revision.
Its native NAR hash is `sha256-Ac0NAZ5z+DAgSplAG7Q0oapGI00VgCJlqFo6pvtHLiI=`.
No existing producer pin, Cargo lockfile, compiler selection, or global tool was changed.
The recipe builds patched Cargo and keeps the original Rust compiler and target libraries in the composed toolchain.
The intended version description is `molten-pathless-package-id`.
The recipe installs the patch, upstream revision, and license notices beside the binary.

The first package build exited 1 before Cargo compilation because the legacy crates.io API download endpoint returned HTTP 403.
The failing fixed-output input was `annotate-snippets` version `0.12.15`.
The version API confirms that this version exists and is not yanked.
The public index configuration declares `https://static.crates.io/crates` as its download endpoint.
The second recipe used that endpoint through `cargoLock.extraRegistries`.
Downloads completed, but Cargo rejected a duplicate `crates-io` source alias from the pinned import helper.
The remote builder selected `-j 32` despite the client-side core limit. The log shows no Cargo compilation before this rejection.

The current recipe overrides only the import helper's crate download URL.
It keeps the original registry identity and avoids the duplicate source alias.
Package versions and Cargo.lock checksums remain unchanged. Native registry checksums use SHA-256 as required by Cargo.
The new eight-minute round disables remote builders only for this command, with one Nix job and two build cores.
Earlier private-cache timeouts remain in the logs but were not the terminal causes of either rejected recipe.

## Built package and actual metadata

The first corrected local build reached its eight-minute deadline during dependency compilation.
The process observation showed the selected Cargo command and its compiler/build-script children. It does not explain every part of the elapsed time.
One new cold package-build allocation had a 24-minute limit. Source behavior, profiles, and two-job parallelism stayed unchanged.
That round passed with exit 0. Cargo reports 11m 04s for the release build and 59.41s for the schema check build.
All 20 schema tests and the doc test pass inside Nix. The tool-selection check also passes.

Package: `/nix/store/gcimdyzhrk0696qh554n1rlmpfyhh2rm-molten-cargo-pathless-1.98.0-nightly`.
Derivation: `/nix/store/iykx4bqma0yqp8r9csjq36x62sjjxsav-molten-cargo-pathless-1.98.0-nightly.drv`.
The binary reports `1.98.0-nightly` at source `4d1f984518c77fad6eeef4f40153b002a659e662`, with description `molten-pathless-package-id`.
The compiler remains `31a9463c6e2794a59ce57a8f37abc6966afc2a58`, LLVM 22.1.6.
The binary BLAKE3 digest, Nix derivation, dependency closure, and verbose versions are retained.
All nine selected cold-build source/configuration hashes pass after the build.

The generated zero-context patch avoids nested-diff whitespace errors without changing the patched Rust files.
The recipe verifies both patched file hashes before compilation. Matching files pass, and the unpatched source fails the hash control as expected.
The original context patch and red archive remain intact.

The actual locked all-feature Molten metadata command now exits 0 through `nix develop`.
Complete Steel JSON read-back reports 769 packages and four Radicle package identities.
Those identities cover `executable-extent-conformance`, `executable-extent-core`, `executable-extent-linux`, and `vm-cohort-core`.
Their source URLs and revisions remain `025d9636f0161777710dac37b3c210ca0ad9483f` and `31f1696ba9391bfda8577a58af84f72361d5573e`.
No false path component appears in those identities.
This command used no wrapper override. Its environment reported `cargo_env=unset` and `rustc_wrapper=unset`.
This observation does not prove that the earlier shared kache lock problem is resolved.

The first nextest command passed metadata discovery and reached Molten compilation, then ended at the eight-minute deadline with exit 124.
It produced no test summary. This is not a nextest pass.
One warm repeat uses the retained build artifacts, the same command arguments, and the same eight-minute deadline.
The final tool-selection guard also verifies the bootstrap command's exit before it checks for the absent patch marker.
This guard-only change leaves the Cargo derivation unchanged, as a fresh Nix evaluation verifies.
The warm default-profile run ended with exit 124 after 3m 25s compilation and 266.659s of test execution.
It ran 1,566 of 1,646 tests: 1,563 passed, one native-process case exceeded its 60-second limit, and two cases received SIGTERM.
The outer deadline caused the two SIGTERM results and left 80 tests unrun.
The timed-out case is `materializing_native_host_rejects_missing_mismatched_and_oversized_effect_values_without_retry`.
No default-profile pass or cause for its duration is established. No further unchanged default-profile retry is allocated.

The repository also owns a CI command at `flake.nix:697-705`, which selects the existing `ci` profile.
A separate bounded CI run used that unchanged profile, the same two-thread limit, and an eight-minute command deadline.
It exited 100 after 411.726s of test execution. All 1,646 tests ran: 1,645 passed and one exceeded the existing 180-second limit.
The timed-out case is `native_executor_fails_closed_for_malformed_nonzero_timeout_flood_spawn_and_cancellation`.
The earlier default-profile timeout case passed in 155.631s under the CI limit.
This result does not replace the failed default-profile observation or prove a cause for either duration.
No profile configuration or runtime timeout value changes.

The first queued metadata/nextest tasks were removed before they started so their Nix options also enforce the local two-core bound.
Their replacement commands retain the original check deadlines and test arguments.

## Final checks and lifecycle limits

Workspace/all-target Clippy and schema/all-target/all-feature Clippy pass with `-D warnings` and no compiler-wrapper override.
Rust and Nix formatting pass.
The expanded Nix selection check passes for Cargo, rustc, rustfmt, `cargo-clippy`, `clippy-driver`, and the complete Rust library tree.
It compares the unchanged tools and library tree against the bootstrap toolchain.
These guard-only changes did not require another Cargo compilation.
The earlier cold-build input manifests remain historical records. The final input manifest must bind the expanded guard separately.

Initial proposal, design, and tasks gates passed for `repair-cargo-pathless-package-identities`.
Strict Cairn validation then rejected six tasks without concurrency markers or recognized requirement references.
The corrected tasks use `[serial]` and the known `r[...]` references.
The corrected validation and tasks gate pass for 56 active changes. They use `legacy_default` without an installation receipt.
This structural result does not grant acceptance or archive authority.

The full Nix command exits 1 at `checks.x86_64-linux.inherited-tracey-debt`.
Its 13 guard tests pass. It reports 2,781 requirements, 791 referenced, 1,990 uncovered, 1,924 baseline entries, and six dangling references.
The terminal diagnostic is `error: dangling traceability references are not permitted`.
Cache download errors precede this source-gate rejection. The result is not a cache-only failure.
This attempt preceded enrollment of the new lifecycle files into the Git input for Nix.
It does not establish a complete final-source Nix pass.

## Independent source review

The first independent reviewer failed at the provider quota before any review.
A separate five-minute review used the existing multi-account provider extension and the two authority guards.
This was a new account-routing mechanism, not an unchanged retry of the failed invocation.
The worker used read-only tools under a sixteen-read limit and a 450-word output limit.
It completed with exit 0 and reported 14 reads/searches across two correlated source passes.
It found no concrete compatibility or tool-selection defect within that scope.
Broader fragment combinations and Git-reference escaping remain unexamined.
The coordinator compared its cited parser, formatter, and Nix selections with the current source.
The worker ran no checks and granted no lifecycle approval. Its source review does not replace the executed checks.

Nextest and complete repository acceptance remain blocked through this candidate.
The package build, schema checks, tool selection, and actual metadata are bounded evidence, not Molten completion.
No repair commit exists. Lifecycle acceptance, sync/archive, integration, publication, and deployment remain open.

## Retained evidence

All commands use direct exit files beside lossless logs under `logs/`.
The initial evidence includes `cargo-fix-initial-gates`, `cargo-fix-schema-baseline`, `cargo-fix-schema-red`, `cargo-fix-schema-green`, `cargo-fix-review`, and `cargo-fix-lock`.
The Nix rounds are `cargo-fix-nix-build`, `cargo-fix-nix-static-registry`, `cargo-fix-nix-vendor-route`, and `cargo-fix-nix-cold-build`.
`cargo-fix-metadata.json` retains the actual Cargo output, with its command log and direct exit.
`cargo-fix-schema-red.tar.gz` and `cargo-fix-schema-red-inputs.b3` retain the counterexample source.
Both completed nextest rounds retain their failed outcomes. Neither is a success receipt.
