You are a subagent. Don't run memo.

Read-only review. Do not edit, run commands, delegate, access credentials, publish, or mutate lifecycle state. You cannot grant approval.

Goal: audit the compatibility boundary for a minimal repair of Cargo package IDs that use pathless source URLs.
Source: /tmp/molten-cargo-pathless-source-20260913/crates/cargo-util-schemas/src/core/package_id_spec.rs at upstream Cargo revision 4d1f984518c77fad6eeef4f40153b002a659e662.
Consumer requirements: /home/brittonr/git/OnixResearch/aspen/.pi/molten-completion/implementation-cargo-fix/.cairn/changes/repair-cargo-pathless-package-identities/specs/development-toolchain/spec.md.

The current formatter panics for a URL such as rad://z2QJLUqyAZnnHPiZQ1BFjLsX9ush3. The current parser rejects even an explicit #vm-cohort-core@0.1.0 fragment.
Identify the smallest correct distinction between explicit names and names inferred from URL paths.
Try to find negative cases that a straightforward repair can accidentally admit or classify incorrectly.
Keep source URL, Git reference, version, name validation, protocol, and query boundaries separate.
Do not classify the current parser's documented rejection as an independent specification violation.

Budget: five minutes, twelve file reads/searches, and at most 400 words.
Output: concrete edge cases with source line citations, proposed regression cases, and any exact blocker.
Local source review is advisory. It does not establish Cargo metadata, nextest, Nix, or release acceptance.
