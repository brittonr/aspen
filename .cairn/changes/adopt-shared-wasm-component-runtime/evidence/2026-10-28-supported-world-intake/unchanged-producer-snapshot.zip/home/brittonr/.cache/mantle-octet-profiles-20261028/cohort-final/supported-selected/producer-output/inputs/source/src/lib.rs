#![no_std]
extern crate alloc;
mod actor;

const HEAP_BYTES: usize = 131_072;
#[repr(align(16))]
struct Heap([u8; HEAP_BYTES]);
static mut HEAP: Heap = Heap([0; HEAP_BYTES]);
static NEXT: core::sync::atomic::AtomicUsize = core::sync::atomic::AtomicUsize::new(0);
struct BoundedAllocator;
unsafe impl core::alloc::GlobalAlloc for BoundedAllocator {
    unsafe fn alloc(&self, layout: core::alloc::Layout) -> *mut u8 {
        let mut offset = NEXT.load(core::sync::atomic::Ordering::Relaxed);
        loop {
            let Some(start) = offset.checked_add(layout.align() - 1).map(|value| value & !(layout.align() - 1)) else {
                return core::ptr::null_mut();
            };
            let Some(end) = start.checked_add(layout.size()).filter(|end| *end <= HEAP_BYTES) else {
                return core::ptr::null_mut();
            };
            match NEXT.compare_exchange_weak(offset, end, core::sync::atomic::Ordering::Relaxed, core::sync::atomic::Ordering::Relaxed) {
                Ok(_) => return unsafe { core::ptr::addr_of_mut!(HEAP.0).cast::<u8>().add(start) },
                Err(actual) => offset = actual,
            }
        }
    }
    unsafe fn dealloc(&self, _: *mut u8, _: core::alloc::Layout) {}
}
#[global_allocator]
static ALLOCATOR: BoundedAllocator = BoundedAllocator;

struct Echo;
impl actor::Guest for Echo {
    fn invoke(input: actor::PreservesPayload) -> Result<actor::PreservesPayload, alloc::string::String> {
        Ok(input)
    }
}
actor::export!(Echo with_types_in actor);

#[unsafe(export_name = "cabi_realloc")]
unsafe extern "C" fn cabi_realloc(old: *mut u8, old_bytes: usize, align: usize, new_bytes: usize) -> *mut u8 {
    if new_bytes == 0 { return align as *mut u8; }
    let layout = core::alloc::Layout::from_size_align(new_bytes, align).expect("canonical ABI layout");
    let next = unsafe { alloc::alloc::alloc(layout) };
    if next.is_null() { core::arch::wasm32::unreachable(); }
    if old_bytes > 0 { unsafe { core::ptr::copy_nonoverlapping(old, next, old_bytes.min(new_bytes)); } }
    next
}

#[unsafe(export_name = "wizer.initialize")]
pub extern "C" fn initialize() {}
#[panic_handler]
fn panic(_: &core::panic::PanicInfo<'_>) -> ! { core::arch::wasm32::unreachable() }
