//! Small unkeyed BLAKE3-256 for canonical value identity in the no-WASI guest.
//! Only the ordinary 32-byte hash mode is exposed (no keys, XOF or derivation).

const IV: [u32; 8] = [
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
];

#[inline(always)]
fn mix(s: &mut [u32; 16], a: usize, b: usize, c: usize, d: usize, x: u32, y: u32) {
    s[a] = s[a].wrapping_add(s[b]).wrapping_add(x);
    s[d] = (s[d] ^ s[a]).rotate_right(16);
    s[c] = s[c].wrapping_add(s[d]);
    s[b] = (s[b] ^ s[c]).rotate_right(12);
    s[a] = s[a].wrapping_add(s[b]).wrapping_add(y);
    s[d] = (s[d] ^ s[a]).rotate_right(8);
    s[c] = s[c].wrapping_add(s[d]);
    s[b] = (s[b] ^ s[c]).rotate_right(7);
}

#[inline(always)]
fn round(s: &mut [u32; 16], m: &[u32; 16], order: [usize; 16]) {
    mix(s, 0, 4, 8, 12, m[order[0]], m[order[1]]);
    mix(s, 1, 5, 9, 13, m[order[2]], m[order[3]]);
    mix(s, 2, 6, 10, 14, m[order[4]], m[order[5]]);
    mix(s, 3, 7, 11, 15, m[order[6]], m[order[7]]);
    mix(s, 0, 5, 10, 15, m[order[8]], m[order[9]]);
    mix(s, 1, 6, 11, 12, m[order[10]], m[order[11]]);
    mix(s, 2, 7, 8, 13, m[order[12]], m[order[13]]);
    mix(s, 3, 4, 9, 14, m[order[14]], m[order[15]]);
}

#[derive(Clone, Copy)]
struct Output {
    cv: [u32; 8],
    block: [u32; 16],
    counter: u64,
    length: u32,
    flags: u32,
}

impl Output {
    fn compress(&self, root: bool) -> [u32; 16] {
        let mut s = [0; 16];
        s[..8].copy_from_slice(&self.cv);
        s[8..12].copy_from_slice(&IV[..4]);
        let counter = self.counter.to_le_bytes();
        s[12] = u32::from_le_bytes([counter[0], counter[1], counter[2], counter[3]]);
        s[13] = u32::from_le_bytes([counter[4], counter[5], counter[6], counter[7]]);
        s[14] = self.length;
        s[15] = self.flags | if root { 8 } else { 0 };
        let m = &self.block;
        round(&mut s, m, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]);
        round(&mut s, m, [2, 6, 3, 10, 7, 0, 4, 13, 1, 11, 12, 5, 9, 14, 15, 8]);
        round(&mut s, m, [3, 4, 10, 12, 13, 2, 7, 14, 6, 5, 9, 0, 11, 15, 8, 1]);
        round(&mut s, m, [10, 7, 12, 9, 14, 3, 13, 15, 4, 0, 11, 2, 5, 8, 1, 6]);
        round(&mut s, m, [12, 13, 9, 11, 15, 10, 14, 8, 7, 2, 5, 3, 0, 1, 6, 4]);
        round(&mut s, m, [9, 14, 11, 5, 8, 12, 15, 1, 13, 3, 0, 10, 2, 6, 4, 7]);
        round(&mut s, m, [11, 15, 5, 0, 1, 9, 8, 6, 14, 10, 2, 12, 3, 4, 7, 13]);
        for i in 0..8 {
            s[i] ^= s[i + 8];
            s[i + 8] ^= self.cv[i];
        }
        s
    }
    fn chaining(&self) -> [u32; 8] {
        self.compress(false)[..8].try_into().unwrap()
    }
}

fn chunk(bytes: &[u8], counter: u64) -> Output {
    let mut cv = IV;
    let blocks = bytes.len().max(1).div_ceil(64);
    for index in 0..blocks {
        let start = index * 64;
        let end = bytes.len().min(start + 64);
        let part = &bytes[start..end];
        let mut padded = [0; 64];
        padded[..part.len()].copy_from_slice(part);
        let block = core::array::from_fn(|i| u32::from_le_bytes(padded[i * 4..i * 4 + 4].try_into().unwrap()));
        let output = Output {
            cv,
            block,
            counter,
            length: part.len() as u32,
            flags: (if index == 0 { 1 } else { 0 }) | (if index + 1 == blocks { 2 } else { 0 }),
        };
        if index + 1 == blocks {
            return output;
        }
        cv = output.chaining();
    }
    unreachable!()
}
fn parent(left: [u32; 8], right: [u32; 8]) -> Output {
    let mut block = [0; 16];
    block[..8].copy_from_slice(&left);
    block[8..].copy_from_slice(&right);
    Output {
        cv: IV,
        block,
        counter: 0,
        length: 64,
        flags: 4,
    }
}

pub fn reference(bytes: &[u8]) -> [u8; 71] {
    let count = bytes.len().max(1).div_ceil(1024);
    let mut stack = [[0u32; 8]; core::mem::size_of::<usize>() * 8];
    let mut stack_length = 0;
    for index in 0..count - 1 {
        let mut cv = chunk(&bytes[index * 1024..index * 1024 + 1024], index as u64).chaining();
        let mut total = index + 1;
        while total & 1 == 0 {
            stack_length -= 1;
            cv = parent(stack[stack_length], cv).chaining();
            total >>= 1;
        }
        stack[stack_length] = cv;
        stack_length += 1;
    }
    let index = count - 1;
    let mut output = chunk(&bytes[index * 1024..], index as u64);
    while stack_length != 0 {
        stack_length -= 1;
        output = parent(stack[stack_length], output.chaining());
    }
    let words = output.compress(true);
    let mut text = [0; 71];
    text[..7].copy_from_slice(b"blake3:");
    for (word_index, word) in words[..8].iter().enumerate() {
        for (byte_index, byte) in word.to_le_bytes().into_iter().enumerate() {
            let index = 7 + word_index * 8 + byte_index * 2;
            text[index] = b"0123456789abcdef"[usize::from(byte >> 4)];
            text[index + 1] = b"0123456789abcdef"[usize::from(byte & 15)];
        }
    }
    text
}
