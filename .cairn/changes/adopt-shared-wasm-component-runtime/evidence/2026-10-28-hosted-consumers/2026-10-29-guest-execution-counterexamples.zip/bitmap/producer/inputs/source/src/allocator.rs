use core::alloc::{GlobalAlloc, Layout};

const BLOCK_BYTES: usize = 16;
const BLOCK_COUNT: usize = 16_384;
const BITMAP_WORDS: usize = BLOCK_COUNT / 64;

#[repr(align(16))]
struct Heap([u8; BLOCK_BYTES * BLOCK_COUNT]);
static mut HEAP: Heap = Heap([0; BLOCK_BYTES * BLOCK_COUNT]);
static mut USED: [u64; BITMAP_WORDS] = [0; BITMAP_WORDS];

// Single-threaded bounded fixture arena. Freeing canonical input/response and
// post-return buffers makes repeated actor invocations reclaim their storage.
struct Arena;

unsafe impl GlobalAlloc for Arena {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let blocks = layout.size().max(1).div_ceil(BLOCK_BYTES);
        if blocks > BLOCK_COUNT { return core::ptr::null_mut(); }
        let base = unsafe { core::ptr::addr_of_mut!(HEAP.0).cast::<u8>() };
        let mut start = 0;
        let mut run = 0;
        let mut index = 0;
        while index < BLOCK_COUNT {
            let word = unsafe { (*core::ptr::addr_of!(USED))[index / 64] } >> (index % 64);
            let remaining = 64 - index % 64;
            if word & 1 != 0 {
                run = 0;
                index += (word.trailing_ones() as usize).min(remaining);
                continue;
            }
            if run == 0 {
                if (base as usize + index * BLOCK_BYTES) % layout.align() != 0 {
                    index += 1;
                    continue;
                }
                start = index;
            }
            let available = (word.trailing_zeros() as usize).min(remaining);
            run += available;
            index += available;
            if run >= blocks {
                unsafe { set_range(start, blocks, true); }
                return unsafe { base.add(start * BLOCK_BYTES) };
            }
        }
        core::ptr::null_mut()
    }

    unsafe fn dealloc(&self, pointer: *mut u8, layout: Layout) {
        let base = unsafe { core::ptr::addr_of_mut!(HEAP.0).cast::<u8>() };
        let first = (pointer as usize - base as usize) / BLOCK_BYTES;
        let blocks = layout.size().max(1).div_ceil(BLOCK_BYTES);
        unsafe { set_range(first, blocks, false); }
    }
}

unsafe fn set_range(mut first: usize, mut blocks: usize, is_used: bool) {
    while blocks != 0 {
        let offset = first % 64;
        let count = blocks.min(64 - offset);
        let mask = (u64::MAX >> (64 - count)) << offset;
        let word = unsafe { &mut (*core::ptr::addr_of_mut!(USED))[first / 64] };
        if is_used {
            *word |= mask;
        } else {
            *word &= !mask;
        }
        first += count;
        blocks -= count;
    }
}

#[cfg(target_arch = "wasm32")]
#[global_allocator]
static ALLOCATOR: Arena = Arena;

// The freestanding guest has no libc import. Volatile loads keep LLVM from
// lowering this implementation back into a call to the same builtin.
// SAFETY: callers supply two readable regions of at least `length` bytes.
#[cfg(target_arch = "wasm32")]
#[unsafe(no_mangle)]
unsafe extern "C" fn memcmp(left: *const u8, right: *const u8, length: usize) -> core::ffi::c_int {
    for index in 0..length {
        let left_byte = unsafe { left.add(index).read_volatile() };
        let right_byte = unsafe { right.add(index).read_volatile() };
        if left_byte != right_byte {
            return core::ffi::c_int::from(left_byte) - core::ffi::c_int::from(right_byte);
        }
    }
    0
}
