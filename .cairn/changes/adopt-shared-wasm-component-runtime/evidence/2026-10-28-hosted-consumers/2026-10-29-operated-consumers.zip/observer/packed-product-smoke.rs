extern crate alloc;
pub use molten::{preserves_rail, system_extension};
#[path = "/home/brittonr/git/OnixResearch/.worktrees/aspen-runtime-adoption-20261026/src/wasm/component/tests/parity/guest.rs"]
mod guest;
#[path = "/home/brittonr/git/OnixResearch/.worktrees/aspen-runtime-adoption-20261026/src/wasm/component/tests/parity/guestarena.rs"]
mod guestarena;
