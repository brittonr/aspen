use molten::{preserves_rail as rail, wasm_component as wc};
use crate::actor_authority::{Result, require};

pub fn measure(bundle: &wc::VerifiedBundle, profile: &wc::RuntimeProfile) -> Result<wc::ArtifactFacts> {
    let bytes = bundle.component_bytes();
    let component_ref = rail::content_ref_from_bytes(bytes);
    let surface = wc::observe_artifact_surface(&profile.wit.world, &component_ref, bytes)?;
    let empty = || wc::GrowthFacts { initial: 0, maximum: Some(0), strategy: wc::GrowthStrategy::Fixed };
    let features = serde_json::to_value(&profile.features)?;
    let mut enabled_features = features.as_object().ok_or("profile feature posture is not an object")?
        .iter().filter_map(|(name, enabled)| (enabled.as_bool() == Some(true)).then(|| name.replace('_', "-")))
        .collect::<Vec<_>>();
    enabled_features.sort();
    let mut facts = wc::ArtifactFacts {
        artifact_kind: wc::ArtifactKind::Component, declared_profile_id: profile.profile_id.clone(),
        declared_cohort_ref: wc::r#ref(profile), declared_world: profile.wit.world.clone(),
        imports: surface.imports, exports: surface.exports, enabled_features,
        memory: empty(), table: empty(), instances: 0, memories: 0, tables: 0,
    };
    for payload in wasmparser::Parser::new(0).parse_all(bytes) {
        match payload? {
            wasmparser::Payload::ImportSection(section) => {
                for import in section {
                    match import?.ty {
                        wasmparser::TypeRef::Memory(memory) => memory_facts(&mut facts, memory)?,
                        wasmparser::TypeRef::Table(table) => table_facts(&mut facts, table)?,
                        _ => {},
                    }
                }
            },
            wasmparser::Payload::MemorySection(section) => {
                for memory in section { memory_facts(&mut facts, memory?)?; }
            },
            wasmparser::Payload::TableSection(section) => {
                for table in section { table_facts(&mut facts, table?.ty)?; }
            },
            wasmparser::Payload::InstanceSection(section) => facts.instances = facts.instances.checked_add(u64::from(section.count())).ok_or("instance count overflow")?,
            wasmparser::Payload::ComponentInstanceSection(section) => facts.instances = facts.instances.checked_add(u64::from(section.count())).ok_or("component instance count overflow")?,
            _ => {},
        }
    }
    Ok(facts)
}
fn memory_facts(facts: &mut wc::ArtifactFacts, memory: wasmparser::MemoryType) -> Result<()> {
    require(!memory.memory64 && !memory.shared && memory.page_size_log2.is_none(), "unsupported actual memory declaration")?;
    require(memory.maximum == Some(memory.initial), "actual memory declaration is not fixed")?;
    facts.memory.initial = facts.memory.initial.max(memory.initial.checked_mul(65_536).ok_or("memory byte overflow")?);
    facts.memory.maximum = Some(facts.memory.initial);
    facts.memories = facts.memories.checked_add(1).ok_or("memory count overflow")?;
    Ok(())
}
fn table_facts(facts: &mut wc::ArtifactFacts, table: wasmparser::TableType) -> Result<()> {
    require(!table.table64 && !table.shared, "unsupported actual table declaration")?;
    require(table.maximum == Some(table.initial), "actual table declaration is not fixed")?;
    facts.table.initial = facts.table.initial.max(table.initial);
    facts.table.maximum = Some(facts.table.initial);
    facts.tables = facts.tables.checked_add(1).ok_or("table count overflow")?;
    Ok(())
}
pub fn facts_value(facts: &wc::ArtifactFacts) -> preserves::IOValue {
    rail::record("actor-smoke-measured-facts-v1", vec![
        rail::string(&facts.declared_profile_id), rail::string(&facts.declared_cohort_ref), rail::string(&facts.declared_world),
        rail::sequence(facts.imports.iter().map(rail::string).collect()),
        rail::sequence(facts.exports.iter().map(rail::string).collect()),
        rail::sequence(facts.enabled_features.iter().map(rail::string).collect()),
        rail::u64_value(facts.memory.initial), rail::u64_value(facts.memory.maximum.unwrap()),
        rail::u64_value(facts.table.initial), rail::u64_value(facts.table.maximum.unwrap()),
        rail::u64_value(facts.instances), rail::u64_value(facts.memories), rail::u64_value(facts.tables),
    ])
}
pub fn envelope_value(envelope: &wc::AdmissionEnvelope) -> preserves::IOValue {
    let strings = |values: &[String]| rail::sequence(values.iter().map(rail::string).collect());
    rail::record("actor-smoke-admission-envelope-v1", vec![
        rail::string(&envelope.schema_id), rail::string(&envelope.bundle_ref),
        strings(&envelope.valence_sidecar_refs), strings(&envelope.cairn_acceptance_refs),
        strings(&envelope.policy_refs), strings(&envelope.authority_refs), strings(&envelope.resource_refs),
    ])
}
