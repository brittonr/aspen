use std::cell::Cell;
use std::sync::{Arc, atomic::{AtomicUsize, Ordering}};

use basalt::ucan::{HolderInvocationReplayAdmission, TokenSigner};
use molten::{effects, preserves_rail as rail, system_extension as extension, wasm_component as wc};

pub const GENERATION: u64 = 3;
pub const INCARNATION: u64 = 5;
pub type Result<T, E = Box<dyn std::error::Error>> = std::result::Result<T, E>;
pub fn require(ok: bool, message: &str) -> Result<()> {
    if ok { Ok(()) } else { Err(std::io::Error::other(message).into()) }
}
pub fn identity(label: &str, artifact: &str) -> String {
    rail::canonical_hash(&rail::record("actor-smoke-binding-v1", vec![rail::string(label), rail::string(artifact)])).unwrap()
}

struct NoCaveats;
impl basalt::ucan::CaveatPolicySet for NoCaveats {
    fn policy_for(&self, _: &basalt::ucan::CaveatIdentifier) -> Option<&dyn basalt::ucan::CaveatPolicy> { None }
}
struct OneInvocation(Cell<bool>);
impl HolderInvocationReplayAdmission for OneInvocation {
    fn admit_holder_invocation(&self, _: &basalt::ucan::HolderInvocationReplayCandidate<'_>)
        -> std::result::Result<(), basalt::ucan::HolderInvocationReplayError> {
        if self.0.replace(true) { Err(basalt::ucan::HolderInvocationReplayError::Duplicate) } else { Ok(()) }
    }
}

pub struct Authority {
    issuer: String,
    audience: basalt::ucan::AudienceDid,
    resolver: basalt::ucan::KeyResolutionContext,
    token: basalt::ucan::CompactToken,
    signature: basalt::ucan::SignerSignature,
    replay: OneInvocation,
    expired: bool,
    policy_json: String,
    pub manifest: preserves::IOValue,
    pub profile: preserves::IOValue,
    pub grant: wc::ImportGrant,
    pub scope: wc::host::Scope,
    pub request: Vec<u8>,
    pub blob: preserves::IOValue,
    capabilities: Vec<String>,
    limits: wc::host::Limits,
}
impl Authority {
    pub fn new(artifact_ref: &str, policy_json: String, expired: bool) -> Result<Self> {
        let blob = rail::record("actor-smoke-blob-v1", vec![rail::string(artifact_ref), rail::string("actual capability-stored canonical value")]);
        let blob_ref = rail::canonical_hash(&blob)?;
        let issuer = basalt::ucan::Ed25519InMemorySigner::from_seed_bytes([11; 32]);
        let holder = basalt::ucan::Ed25519InMemorySigner::from_seed_bytes([13; 32]);
        let audience = basalt::ucan::AudienceDid::from(holder.issuer()?);
        let capability_set = basalt::ucan::CapabilitySet::new(vec![
            basalt::ucan::CapabilityDocument::new(format!("molten://blob/{blob_ref}"), "blob/get".to_string())?,
        ])?;
        let token = basalt::ucan::issue_token_with_signer(&issuer, &audience, &capability_set,
            &basalt::ucan::ProofReferences::empty(), basalt::ucan::TokenTimeBounds::new(100, 200)?)?;
        let resolver = basalt::ucan::KeyResolutionContext::new(vec![issuer.verification_key()?, holder.verification_key()?]);
        let issuer = issuer.issuer()?.as_str().to_string();
        let policy_ref = wc::host::authority::policy_ref(&policy_json)?;
        let authority_ref = wc::host::authority::credential_ref(token.as_str(), &issuer, audience.as_str())?;
        let limits = wc::host::Limits { max_calls: 2, max_output_bytes: 4_096 };
        let resource_ref = wc::host::limits_ref(limits)?;
        let profile = effects::handler_profile_value(&effects::HandlerProfileInput {
            profile: "production".to_string(),
            handler_binding_refs: vec![identity("blob-get-handler", artifact_ref)],
            policy_ref: policy_ref.clone(), capability_context_ref: authority_ref.clone(),
            resource_refs: vec![resource_ref.clone()], evidence_refs: Vec::new(),
        })?;
        let scope = wc::host::Scope {
            run_ref: identity("run", artifact_ref), handler_profile_ref: rail::canonical_hash(&profile)?,
            turn_ref: identity("turn", artifact_ref), boundary_ref: identity("boundary", artifact_ref),
        };
        let capabilities = vec![authority_ref.clone()];
        let manifest = effects::effect_manifest_value(&effects::EffectManifestInput {
            artifact_kind: "wasm".to_string(), artifact_ref: artifact_ref.to_string(), executor_kind: "wasm".to_string(),
            declared_effects: vec![effects::DeclaredEffect {
                effect_id: "blob.get".to_string(), operation: "get".to_string(),
                input_schema_ref: rail::canonical_hash(&rail::record("blob-get-schema", vec![rail::string("content-ref")]))?,
                output_schema_ref: rail::canonical_hash(&rail::record("actor-smoke-blob-schema", vec![rail::string("artifact-ref"), rail::string("string")]))?,
                resource_class: "hostcall".to_string(), capability_refs: capabilities.clone(), evidence_refs: Vec::new(),
            }], policy_refs: vec![policy_ref.clone()], evidence_refs: Vec::new(),
        })?;
        let grant = wc::ImportGrant {
            import: wc::HOST_REQUEST_IMPORT.to_string(), capability: wc::HOST_BLOB_CAPABILITY.to_string(),
            policy_ref, authority_ref, resource_ref,
            recorded_effect_ref: wc::host::recording_ref(&scope, GENERATION, INCARNATION)?,
        };
        let payload = rail::record("blob-get", vec![rail::string(&blob_ref)]);
        let effect = effects::effect_request_value(&effects::EffectRequestInput {
            artifact_ref: artifact_ref.to_string(), effect_id: "blob.get".to_string(), operation: "get".to_string(),
            handler_profile: "production".to_string(), input_ref: rail::canonical_hash(&payload)?,
            capability_refs: capabilities.clone(), evidence_refs: Vec::new(),
        })?;
        let request = wc::encode_host_request(wc::HostRequestInput {
            generation: GENERATION, incarnation: INCARNATION, sequence: 0, grant: &grant, effect: &effect, payload: &payload,
        })?;
        let decoded = wc::decode_host_request(&request)?;
        let signature = basalt::ucan::sign_holder_invocation(
            &basalt::ucan::HolderInvocationSigningRequest::new(token.as_str(), &audience,
                &wc::host::authority::blob_resource(&decoded)?, wc::host::authority::BLOB_ABILITY,
                wc::host::authority::holder_binding(&decoded, &scope)?,
                basalt::ucan::HolderInvocationNonce::from_bytes([7; 32])),
            &holder, basalt::ucan::VerificationLimits::default(), basalt::ucan::HolderInvocationLimits::default())?;
        Ok(Self { issuer, audience, resolver, token, signature, replay: OneInvocation(Cell::new(false)), expired,
            policy_json, manifest, profile, grant, scope, request, blob, capabilities, limits })
    }
    pub fn public_credential(&self) -> preserves::IOValue {
        // Disposable smoke keys/tokens only, never product credentials.
        rail::record("component-host-authority-v1", vec![rail::string("onix-compact-ed25519-v1"),
            rail::string(&self.issuer), rail::string(self.audience.as_str()), rail::string(self.token.as_str())])
    }
}
impl wc::consumer::host::CurrentContext for Authority {
    fn with_current<R>(&mut self, use_current: impl FnOnce(wc::host::CurrentInput<'_>) -> R) -> R {
        let proofs = basalt::ucan::ProofCollection::empty();
        let services = basalt::ucan_enforcement::UcanEnforcementBoundaries {
            verification_time: basalt::ucan::VerificationTime::from_unix_seconds(if self.expired { 201 } else { 150 }),
            key_resolver: &self.resolver, proof_store: &proofs, revocations: &basalt::ucan::NoRevocations,
            caveat_policies: &NoCaveats, replay: &self.replay,
            verification_limits: basalt::ucan::VerificationLimits::default().with_clock_skew_tolerance_seconds(0),
            holder_limits: basalt::ucan::HolderInvocationLimits::default(),
        };
        use_current(wc::host::CurrentInput {
            generation: GENERATION, incarnation: INCARNATION, effect_manifest: &self.manifest,
            handler_profile: &self.profile, grant: &self.grant, capability_refs: &self.capabilities, limits: self.limits,
            authority: wc::host::authority::Input {
                policy_json: &self.policy_json, trusted_issuer: &self.issuer, expected_holder: self.audience.as_str(),
                credential: wc::host::authority::Credential {
                    compact_token: self.token.as_str(), nonce: basalt::ucan::HolderInvocationNonce::from_bytes([7; 32]),
                    holder_signature: &self.signature,
                }, services: &services,
            },
        })
    }
}

pub struct CountedValues {
    pub actual: extension::CapabilityCallbackValuePort,
    pub materializations: Arc<AtomicUsize>,
    pub delay_once: Option<std::time::Duration>,
}
impl extension::NativeCallbackValuePort for CountedValues {
    fn materialize(&mut self, reference: &str, maximum: u64)
        -> std::result::Result<extension::NativeCallbackValue, extension::ValuePortFailure> {
        self.materializations.fetch_add(1, Ordering::SeqCst);
        if let Some(delay) = self.delay_once.take() {
            // The synchronous host operation completes against real storage;
            // the engine epoch service remains live during this adverse latency.
            std::thread::sleep(delay);
        }
        self.actual.materialize(reference, maximum)
    }
    fn publish(&mut self, value: &extension::NativeCallbackValue, maximum: u64)
        -> std::result::Result<extension::ValuePublicationReceipt, extension::ValuePortFailure> {
        self.actual.publish(value, maximum)
    }
}
