use molten::wasm_component as component;
use super::extension_authority::{check, denial, Result};

// Disposable measurement bridge while production resource inspection remains
// crate-private. The retained component bytes are the sole resource/surface source.
pub fn measure(bytes: &[u8], profile: &component::RuntimeProfile) -> Result<component::ArtifactFacts> {
    let allowed = wasmparser::WasmFeatures::WASM1
        | wasmparser::WasmFeatures::REFERENCE_TYPES | wasmparser::WasmFeatures::MULTI_VALUE
        | wasmparser::WasmFeatures::BULK_MEMORY | wasmparser::WasmFeatures::SIMD
        | wasmparser::WasmFeatures::COMPONENT_MODEL;
    wasmparser::Validator::new_with_features(allowed).validate_all(bytes).map_err(denial)?;
    component::classify_for_profile(component::RequestedExecutionProfile::ComponentV1, bytes).map_err(denial)?;
    let component_ref = molten::preserves_rail::content_ref_from_bytes(bytes);
    let surface = component::observe_artifact_surface(&profile.wit.world, &component_ref, bytes).map_err(denial)?;
    let empty = || component::GrowthFacts { initial: 0, maximum: Some(0), strategy: component::GrowthStrategy::Fixed };
    let mut memory = empty();
    let mut table = empty();
    let mut memories = 0u64;
    let mut tables = 0u64;
    let mut instances = 0u64;
    for payload in wasmparser::Parser::new(0).parse_all(bytes) {
        match payload.map_err(denial)? {
            wasmparser::Payload::MemorySection(section) => {
                for item in section { memory_fact(item.map_err(denial)?, &mut memory, &mut memories)?; }
            }
            wasmparser::Payload::TableSection(section) => {
                for item in section { table_fact(item.map_err(denial)?.ty, &mut table, &mut tables)?; }
            }
            wasmparser::Payload::ImportSection(section) => {
                for item in section {
                    match item.map_err(denial)?.ty {
                        wasmparser::TypeRef::Memory(item) => memory_fact(item, &mut memory, &mut memories)?,
                        wasmparser::TypeRef::Table(item) => table_fact(item, &mut table, &mut tables)?,
                        _ => {}
                    }
                }
            }
            wasmparser::Payload::InstanceSection(section) => instances = instances.checked_add(u64::from(section.count())).ok_or("instance overflow")?,
            wasmparser::Payload::ComponentInstanceSection(section) => instances = instances.checked_add(u64::from(section.count())).ok_or("instance overflow")?,
            _ => {}
        }
    }
    let f = &profile.features;
    let enabled_features = [
        ("bulk-memory", f.bulk_memory), ("component-async", f.component_async), ("component-model", f.component_model),
        ("custom-page-sizes", f.custom_page_sizes), ("exceptions", f.exceptions), ("extended-const", f.extended_const),
        ("function-references", f.function_references), ("gc", f.gc), ("memory64", f.memory64),
        ("multi-memory", f.multi_memory), ("multi-value", f.multi_value), ("reference-types", f.reference_types),
        ("relaxed-simd", f.relaxed_simd), ("simd", f.simd), ("tail-call", f.tail_call), ("threads", f.threads),
        ("wide-arithmetic", f.wide_arithmetic),
    ].into_iter().filter_map(|(name, enabled)| enabled.then(|| name.to_string())).collect();
    // These are the verifier-checked Mantle/profile declaration, not guessed
    // instructions-used flags. Validation above separately checks actual bytes.
    Ok(component::ArtifactFacts {
        artifact_kind: component::ArtifactKind::Component,
        declared_profile_id: profile.profile_id.clone(), declared_cohort_ref: component::r#ref(profile),
        declared_world: profile.wit.world.clone(), imports: surface.imports, exports: surface.exports,
        enabled_features, memory, table, instances, memories, tables,
    })
}
fn memory_fact(item: wasmparser::MemoryType, growth: &mut component::GrowthFacts, count: &mut u64) -> Result<()> {
    check(!item.memory64 && !item.shared && item.page_size_log2.is_none(), "unsupported memory features")?;
    check(item.maximum == Some(item.initial), "memory is not fixed")?;
    let initial = item.initial.checked_mul(65_536).ok_or("memory size overflow")?;
    growth.initial = growth.initial.max(initial);
    growth.maximum = Some(growth.initial);
    *count = count.checked_add(1).ok_or("memory count overflow")?;
    Ok(())
}
fn table_fact(item: wasmparser::TableType, growth: &mut component::GrowthFacts, count: &mut u64) -> Result<()> {
    check(!item.table64 && !item.shared, "unsupported table features")?;
    check(item.maximum == Some(item.initial), "table is not fixed")?;
    growth.initial = growth.initial.max(item.initial);
    growth.maximum = Some(growth.initial);
    *count = count.checked_add(1).ok_or("table count overflow")?;
    Ok(())
}
