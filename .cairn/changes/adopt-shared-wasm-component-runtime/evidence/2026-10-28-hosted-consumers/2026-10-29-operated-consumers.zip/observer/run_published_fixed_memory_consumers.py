import json
from pathlib import Path
import subprocess
import sys

# Each consumer receives the original published bundle unchanged and independently
# remeasures it through the product verifier. No bundle/receipt constructor here.
if len(sys.argv) != 7:
    raise SystemExit('usage: run_consumers.py NEUTRAL_BUNDLE CALLBACK_BUNDLE NEUTRAL_SIDECAR CALLBACK_SIDECAR NEUTRAL_ACCEPTANCE CALLBACK_ACCEPTANCE')
ROOT = Path('/home/brittonr/git/OnixResearch/.worktrees/aspen-runtime-adoption-20261026')
OUT = Path('/home/brittonr/.cache/aspen-hosted-effects-20261028/operated-published-fixed-memory-cohort')
OUT.mkdir(exist_ok=False)
TARGET = Path('/home/brittonr/.cache/aspen-component-adoption-20261028/target/debug')
POLICY = ROOT / 'docs/wasm-component-runtime/generated/host-policy.json'
records = []
for label, example, bundle, sidecar, acceptance in [
    ('actor', 'actor-hosted-effects-smoke', sys.argv[1], sys.argv[3], sys.argv[5]),
    ('extension', 'extension-hosted-effects-smoke', sys.argv[2], sys.argv[4], sys.argv[6]),
]:
    bundle = Path(bundle).resolve(strict=True)
    acceptance = Path(acceptance).resolve(strict=True)
    if label == 'actor':
        command = [str(TARGET / example), str(bundle), str(OUT / label), str(Path(sidecar).resolve(strict=True)), str(acceptance), str(POLICY)]
    else:
        admission = OUT / 'extension-admission.json'
        admission.write_text(json.dumps({
            'valence_evidence_paths': [str(Path(sidecar).resolve(strict=True))],
            'cairn_evidence_paths': [str(acceptance)],
            'issuer_seed_hex': '11' * 32,
            'holder_seed_hex': '22' * 32,
            'verification_unix_seconds': 200,
            'not_before_unix_seconds': 100,
            'expires_unix_seconds': 300,
            'host_policy_path': str(POLICY),
        }, indent=2) + '\n')
        command = [str(TARGET / example), str(bundle), str(OUT / label), str(admission)]
    log = OUT / (label + '.log')
    with log.open('x') as stream:
        result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, timeout=180)
    record = {'consumer': label, 'command': command, 'cwd': str(ROOT), 'exit': result.returncode, 'log': str(log)}
    records.append(record)
    (OUT / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    print(log.read_text(), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
