use std::cell::RefCell;
use std::collections::BTreeSet;
use std::rc::Rc;
use std::sync::{Arc, Mutex};

use basalt::ucan::{HolderInvocationReplayAdmission, TokenSigner};
use molten::preserves_rail as rail;
use molten::system_extension as extension;
use molten::wasm_component as component;
use component::consumer::host::{CurrentContext, Recording, Live, SharedValuePort};
use component::host::{authority, Limits, Scope};

pub type Error = Box<dyn std::error::Error>;
pub type Result<T, E = Error> = std::result::Result<T, E>;
pub type EffectHost = Live<ExtensionCurrent, SharedValuePort>;

pub fn denial(error: impl std::fmt::Debug) -> Error { format!("{error:?}").into() }
pub fn check(condition: bool, message: &str) -> Result<()> {
    if condition { Ok(()) } else { Err(message.to_string().into()) }
}
pub fn value(bytes: Vec<u8>) -> extension::NativeCallbackValue {
    extension::NativeCallbackValue { value_ref: rail::content_ref_from_bytes(&bytes), bytes }
}
pub fn hash_value(value: &preserves::IOValue) -> Result<String> { Ok(rail::canonical_hash(value)?) }
pub fn reference(label: &'static str, refs: &[String]) -> Result<String> {
    hash_value(&rail::record(label, refs.iter().map(rail::string).collect()))
}

#[derive(serde::Deserialize)]
#[serde(deny_unknown_fields)]
pub struct AdmissionInput {
    pub valence_evidence_paths: Vec<std::path::PathBuf>,
    pub cairn_evidence_paths: Vec<std::path::PathBuf>,
    pub issuer_seed_hex: String,
    pub holder_seed_hex: String,
    pub verification_unix_seconds: u64,
    pub not_before_unix_seconds: u64,
    pub expires_unix_seconds: u64,
    pub host_policy_path: std::path::PathBuf,
}

fn seed(hex: &str) -> Result<[u8; 32]> {
    check(hex.len() == 64, "signing seed must be 32 bytes, encoded as 64 hex digits")?;
    let mut result = [0; 32];
    for (index, pair) in hex.as_bytes().chunks_exact(2).enumerate() {
        result[index] = u8::from_str_radix(std::str::from_utf8(pair)?, 16)?;
    }
    Ok(result)
}

pub fn evidence_refs(paths: &[std::path::PathBuf]) -> Result<Vec<String>> {
    check(!paths.is_empty(), "real admission evidence source files are required")?;
    let mut refs = Vec::new();
    for path in paths {
        let bytes = std::fs::read(path)?;
        check(!bytes.is_empty(), "admission evidence source is empty")?;
        refs.push(rail::content_ref_from_bytes(&bytes));
    }
    refs.sort();
    refs.dedup();
    Ok(refs)
}

pub struct ExtensionReplay {
    admitted: Rc<RefCell<BTreeSet<String>>>,
}
impl HolderInvocationReplayAdmission for ExtensionReplay {
    fn admit_holder_invocation(
        &self,
        candidate: &basalt::ucan::HolderInvocationReplayCandidate<'_>,
    ) -> std::result::Result<(), basalt::ucan::HolderInvocationReplayError> {
        // Basalt calls this only for an actually verified audience-scoped nonce.
        let key = format!("{}:{}", candidate.audience().as_str(), rail::content_ref_from_bytes(candidate.nonce().as_bytes()));
        if self.admitted.borrow_mut().insert(key) {
            Ok(())
        } else {
            Err(basalt::ucan::HolderInvocationReplayError::Duplicate)
        }
    }
}
struct ExtensionNoCaveats;
impl basalt::ucan::CaveatPolicySet for ExtensionNoCaveats {
    fn policy_for(&self, _: &basalt::ucan::CaveatIdentifier) -> Option<&dyn basalt::ucan::CaveatPolicy> { None }
}
static EMPTY_PROOFS: basalt::ucan::ProofCollection = basalt::ucan::ProofCollection::empty();

pub struct ExtensionAuthority {
    holder: basalt::ucan::Ed25519InMemorySigner,
    issuer: String,
    audience: basalt::ucan::AudienceDid,
    resolver: basalt::ucan::KeyResolutionContext,
    token: basalt::ucan::CompactToken,
    policy_json: String,
    now: u64,
    expired_now: u64,
    admitted_nonces: Rc<RefCell<BTreeSet<String>>>,
    pub policy_ref: String,
    pub credential_ref: String,
    pub manifest: preserves::IOValue,
    pub handler_profile: preserves::IOValue,
    pub scope: Scope,
    pub grant: component::ImportGrant,
    pub capabilities: Vec<String>,
    pub limits: Limits,
    pub payload: preserves::IOValue,
    pub output: preserves::IOValue,
    pub artifact_ref: String,
}

impl ExtensionAuthority {
    pub fn new(input: &AdmissionInput, artifact_ref: String, bundle_ref: String) -> Result<Self> {
        let output = rail::record("extension-smoke-blob-v1", vec![rail::string(&artifact_ref), rail::string(&bundle_ref)]);
        let object_ref = hash_value(&output)?;
        let payload = rail::record("blob-get", vec![rail::string(&object_ref)]);
        let issuer = basalt::ucan::Ed25519InMemorySigner::from_seed_bytes(seed(&input.issuer_seed_hex)?);
        let holder = basalt::ucan::Ed25519InMemorySigner::from_seed_bytes(seed(&input.holder_seed_hex)?);
        let audience = basalt::ucan::AudienceDid::from(holder.issuer().map_err(denial)?);
        let issuer_did = issuer.issuer().map_err(denial)?.as_str().to_string();
        let capabilities = basalt::ucan::CapabilitySet::new(vec![
            basalt::ucan::CapabilityDocument::new(format!("molten://blob/{object_ref}"), "blob/get".to_string()).map_err(denial)?,
        ]).map_err(denial)?;
        let token = basalt::ucan::issue_token_with_signer(
            &issuer, &audience, &capabilities, &basalt::ucan::ProofReferences::empty(),
            basalt::ucan::TokenTimeBounds::new(input.not_before_unix_seconds, input.expires_unix_seconds).map_err(denial)?,
        ).map_err(denial)?;
        check(input.verification_unix_seconds >= input.not_before_unix_seconds
            && input.verification_unix_seconds < input.expires_unix_seconds, "positive authority time must be within signed token bounds")?;
        let resolver = basalt::ucan::KeyResolutionContext::new(vec![
            issuer.verification_key().map_err(denial)?, holder.verification_key().map_err(denial)?,
        ]);
        let policy_json = std::fs::read_to_string(&input.host_policy_path)?;
        let policy_ref = authority::policy_ref(&policy_json).map_err(denial)?;
        let credential_ref = authority::credential_ref(token.as_str(), &issuer_did, audience.as_str()).map_err(denial)?;
        let limits = Limits { max_calls: 1, max_output_bytes: component::HOST_PAYLOAD_BYTES };
        let resource_ref = component::host::limits_ref(limits).map_err(denial)?;
        // Capability context names the real signed credential, not an arbitrary label.
        let capabilities = vec![credential_ref.clone()];
        let handler_profile = molten::effects::handler_profile_value(&molten::effects::HandlerProfileInput {
            profile: "production".to_string(),
            handler_binding_refs: vec![hash_value(&rail::record("extension-host-binding-v1", vec![rail::string(&artifact_ref), rail::string(&policy_ref)]))?],
            policy_ref: policy_ref.clone(), capability_context_ref: credential_ref.clone(),
            resource_refs: vec![resource_ref.clone()], evidence_refs: vec![bundle_ref.clone()],
        })?;
        let scope = Scope {
            run_ref: reference("extension-host-run-v1", &[bundle_ref.clone(), artifact_ref.clone()])?,
            handler_profile_ref: hash_value(&handler_profile)?,
            turn_ref: reference("extension-host-turn-v1", &[artifact_ref.clone(), credential_ref.clone()])?,
            boundary_ref: reference("extension-host-boundary-v1", &[object_ref, policy_ref.clone()])?,
        };
        let grant = component::ImportGrant {
            import: component::HOST_REQUEST_IMPORT.to_string(), capability: component::HOST_BLOB_CAPABILITY.to_string(),
            policy_ref: policy_ref.clone(), authority_ref: credential_ref.clone(), resource_ref,
            recorded_effect_ref: component::host::recording_ref(&scope, 1, 0).map_err(denial)?,
        };
        let schema_ref = hash_value(&rail::record("extension-blob-schema-v1", vec![rail::string("canonical-preserves")]))?;
        let manifest = molten::effects::effect_manifest_value(&molten::effects::EffectManifestInput {
            artifact_kind: "wasm".to_string(), artifact_ref: artifact_ref.clone(), executor_kind: "wasm".to_string(),
            declared_effects: vec![molten::effects::DeclaredEffect {
                effect_id: "blob.get".to_string(), operation: "get".to_string(),
                input_schema_ref: schema_ref.clone(), output_schema_ref: schema_ref,
                resource_class: "hostcall".to_string(), capability_refs: capabilities.clone(), evidence_refs: vec![bundle_ref.clone()],
            }],
            policy_refs: vec![policy_ref.clone()], evidence_refs: vec![bundle_ref],
        })?;
        Ok(Self { holder, issuer: issuer_did, audience, resolver, token, policy_json,
            now: input.verification_unix_seconds, expired_now: input.expires_unix_seconds.checked_add(1).ok_or("expiration overflow")?,
            admitted_nonces: Rc::new(RefCell::new(BTreeSet::new())), policy_ref, credential_ref, manifest, handler_profile,
            scope, grant, capabilities, limits, payload, output, artifact_ref })
    }

    pub fn grant(&self, generation: u64, incarnation: u64) -> Result<component::ImportGrant> {
        let mut grant = self.grant.clone();
        grant.recorded_effect_ref = component::host::recording_ref(&self.scope, generation, incarnation).map_err(denial)?;
        Ok(grant)
    }

    pub fn request(&self, generation: u64, incarnation: u64, sequence: u64) -> Result<Vec<u8>> {
        let effect = molten::effects::effect_request_value(&molten::effects::EffectRequestInput {
            artifact_ref: self.artifact_ref.clone(), effect_id: "blob.get".to_string(), operation: "get".to_string(),
            handler_profile: "production".to_string(), input_ref: hash_value(&self.payload)?,
            capability_refs: self.capabilities.clone(), evidence_refs: Vec::new(),
        })?;
        Ok(component::encode_host_request(component::HostRequestInput {
            generation, incarnation, sequence, grant: &self.grant(generation, incarnation)?, effect: &effect, payload: &self.payload,
        }).map_err(denial)?)
    }

    pub fn current(self: &Rc<Self>, request_bytes: &[u8], generation: u64, incarnation: u64, callback_sequence: u64, deny: bool) -> Result<ExtensionCurrent> {
        let request = component::decode_host_request(request_bytes).map_err(denial)?;
        let nonce_value = rail::record("extension-holder-nonce-v1", vec![
            rail::string(rail::content_ref_from_bytes(request_bytes)), rail::u64_value(generation),
            rail::u64_value(incarnation), rail::u64_value(callback_sequence),
        ]);
        let nonce_bytes = *blake3::hash(&rail::canonical_bytes(&nonce_value)?).as_bytes();
        let nonce = basalt::ucan::HolderInvocationNonce::from_bytes(nonce_bytes);
        let signature = basalt::ucan::sign_holder_invocation(
            &basalt::ucan::HolderInvocationSigningRequest::new(
                self.token.as_str(), &self.audience, &authority::blob_resource(&request).map_err(denial)?,
                authority::BLOB_ABILITY, authority::holder_binding(&request, &self.scope).map_err(denial)?, nonce,
            ), &self.holder, basalt::ucan::VerificationLimits::default(), basalt::ucan::HolderInvocationLimits::default(),
        ).map_err(denial)?;
        Ok(ExtensionCurrent { authority: self.clone(), signature, nonce_bytes,
            generation, incarnation, grant: self.grant(generation, incarnation)?, deny, replay: ExtensionReplay {
                admitted: self.admitted_nonces.clone(),
            } })
    }
}

pub struct ExtensionCurrent {
    authority: Rc<ExtensionAuthority>,
    signature: basalt::ucan::SignerSignature,
    nonce_bytes: [u8; 32],
    generation: u64,
    incarnation: u64,
    grant: component::ImportGrant,
    deny: bool,
    replay: ExtensionReplay,
}
impl CurrentContext for ExtensionCurrent {
    fn with_current<R>(&mut self, use_current: impl FnOnce(component::host::CurrentInput<'_>) -> R) -> R {
        let a = &self.authority;
        // The negative case uses the same real credential under an explicitly
        // advanced current verification time. No fake authority or reply exists.
        let services = basalt::ucan_enforcement::UcanEnforcementBoundaries {
            verification_time: basalt::ucan::VerificationTime::from_unix_seconds(if self.deny { a.expired_now } else { a.now }),
            key_resolver: &a.resolver, proof_store: &EMPTY_PROOFS,
            revocations: &basalt::ucan::NoRevocations, caveat_policies: &ExtensionNoCaveats, replay: &self.replay,
            verification_limits: basalt::ucan::VerificationLimits::default().with_clock_skew_tolerance_seconds(0),
            holder_limits: basalt::ucan::HolderInvocationLimits::default(),
        };
        use_current(component::host::CurrentInput {
            generation: self.generation, incarnation: self.incarnation,
            effect_manifest: &a.manifest, handler_profile: &a.handler_profile, grant: &self.grant,
            capability_refs: &a.capabilities, limits: a.limits,
            authority: authority::Input {
                policy_json: &a.policy_json, trusted_issuer: &a.issuer, expected_holder: a.audience.as_str(),
                credential: authority::Credential { compact_token: a.token.as_str(),
                    nonce: basalt::ucan::HolderInvocationNonce::from_bytes(self.nonce_bytes), holder_signature: &self.signature },
                services: &services,
            },
        })
    }
}

#[derive(Clone)]
pub struct ExtensionHostFactory {
    pub authority: Rc<ExtensionAuthority>,
    pub values: extension::SharedCallbackValuePort,
    pub deny: Rc<std::cell::Cell<bool>>,
    pub recordings: Rc<RefCell<Vec<(u64, Recording)>>>,
}
impl extension::ComponentCallbackHostFactory for ExtensionHostFactory {
    type Host = EffectHost;
    fn create(&mut self, _: &extension::CallbackContext, invocation: &extension::CallbackInvocation) -> component::Result<extension::Binding<EffectHost>> {
        let build = || -> Result<_> {
            // The expected operation is host-owned. Malformed/unexpected guest
            // payload cannot ask the host to sign arbitrary request bytes.
            let request = self.authority.request(invocation.generation, invocation.incarnation, 0)?;
            let current = self.authority.current(&request, invocation.generation, invocation.incarnation, invocation.sequence, self.deny.get())?;
            Ok(Live::new(self.authority.scope.clone(), invocation.generation, invocation.incarnation,
                current, SharedValuePort(self.values.clone())).map_err(denial)?)
        };
        let (host, recording) = build().map_err(|error| component::Denial::new(error.to_string()))?;
        self.recordings.borrow_mut().push((invocation.sequence, recording));
        Ok(extension::Binding::live(host))
    }
}

pub fn shared_values(directory: &std::path::Path) -> Result<extension::SharedCallbackValuePort> {
    let dir = cap_std::fs::Dir::open_ambient_dir(directory, cap_std::ambient_authority())?;
    let scope = molten::node_state::Scope::from_dir(molten::node_state::NamespaceKind::Ledger, dir)?;
    Ok(Arc::new(Mutex::new(Box::new(extension::CapabilityCallbackValuePort::new(scope)?))))
}
