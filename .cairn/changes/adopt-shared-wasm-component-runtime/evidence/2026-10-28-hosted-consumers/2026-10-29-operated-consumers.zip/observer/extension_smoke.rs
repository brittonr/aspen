mod extension_authority;
mod extension_measure;
mod extension_regressions;

use std::cell::{Cell, RefCell};
use std::path::{Path, PathBuf};
use std::rc::Rc;
use std::sync::Arc;

use molten::preserves_rail as rail;
use molten::system_extension as extension;
use molten::wasm_component as component;
use extension_authority::{check, denial, hash_value, value, AdmissionInput, ExtensionAuthority, ExtensionHostFactory, Result};

type Host = extension::Dispatcher<extension::Executor<ExtensionHostFactory>>;

fn save(dir: &Path, name: &str, value: &preserves::IOValue) -> Result<String> {
    let bytes = rail::canonical_bytes(value)?;
    std::fs::write(dir.join(name), &bytes)?;
    Ok(rail::content_ref_from_bytes(&bytes))
}
fn strings(values: &[String]) -> preserves::IOValue {
    rail::sequence(values.iter().map(rail::string).collect())
}
fn publish(values: &extension::SharedCallbackValuePort, bytes: Vec<u8>) -> Result<extension::NativeCallbackValue> {
    let value = value(bytes);
    let receipt = values.lock().map_err(|_| "callback values lock poisoned")?.publish(&value, component::HOST_PAYLOAD_BYTES).map_err(denial)?;
    check(receipt.value_ref == value.value_ref && receipt.byte_count == value.bytes.len() as u64, "initial publication receipt mismatch")?;
    Ok(value)
}

fn manifest(component_ref: &str, bundle: &component::VerifiedBundle, a: &ExtensionAuthority, profile: &component::RuntimeProfile) -> Result<extension::AdmittedManifest> {
    // Use the product descriptor factory unchanged. This is an exact installed
    // binding, not a claim that this smoke exercises the fabric stream protocol;
    // effect-request reads the separate capability-backed callback value port.
    let descriptors = molten::content_store_adapter::port_descriptors(&component::r#ref(profile));
    let descriptor = descriptors.iter().find(|descriptor| descriptor.port_id == "content-store").ok_or("product content-store descriptor missing")?;
    let requirement = molten::fabric::FabricPortRequirement {
        port_id: descriptor.port_id.clone(), version: descriptor.version.clone(), class: descriptor.class,
        operation_classes: descriptor.operation_classes.clone(), input_schema_refs: descriptor.input_schema_refs.clone(),
        output_schema_refs: descriptor.output_schema_refs.clone(), allowed_authorities: descriptor.authority_requirements.clone(),
        available_resources: descriptor.resource_requirements.clone(), expected_determinism: descriptor.determinism,
        expected_replay: descriptor.replay, expected_profile: descriptor.implementation_profile.clone(),
    };
    let mut authorities = descriptor.authority_requirements.clone();
    authorities.push(molten::fabric::FabricAuthority::Supervision);
    authorities.sort();
    authorities.dedup();
    let tier = molten::fabric::canonical_extension_tier_admission(&molten::fabric::ExtensionTierRequest {
        tier: molten::fabric::ExtensionTier::SystemExtension, requested_authorities: authorities,
        admission_evidence: molten::fabric::REQUIRED_SYSTEM_EXTENSION_EVIDENCE.to_vec(),
    })?;
    let input = extension::SystemExtensionManifestInput {
        schema: extension::SYSTEM_EXTENSION_MANIFEST_SCHEMA.to_string(),
        extension_id: "molten.smoke.hosted-effects.extension".to_string(),
        service_id: "molten.smoke.hosted-effects.service".to_string(), implementation_ref: component_ref.to_string(),
        callback_groups: ["initialize", "start", "request", "health", "checkpoint", "recover", "drain", "shutdown"].into_iter().map(str::to_string).collect(),
        required_ports: vec![requirement], optional_ports: Vec::new(), capability_refs: a.capabilities.clone(),
        policy_refs: vec![a.policy_ref.clone()], provenance_refs: vec![bundle.bundle_ref().to_string()],
        resources: extension::ResourceEnvelope {
            max_concurrent_callbacks: profile.resources.max_concurrency, max_queued_events: 16,
            max_inflight_bytes: profile.resources.max_hostcall_bytes.max(profile.resources.max_result_bytes),
            max_open_streams: 1, max_timers: 1, max_effect_requests: 4,
            callback_deadline_ticks: 16, shutdown_grace_ticks: 32, max_restart_attempts: 2,
            overload_policy: extension::OverloadPolicy::UpstreamBackpressure,
        },
        recovery_group: None, execution_profile: extension::ExecutionProfile::SandboxedComponent,
        state_schema: "molten.smoke.hosted-effects.state.v1".to_string(),
        compatible_state_schemas: vec!["molten.smoke.hosted-effects.state.v1".to_string()],
        evidence_profile_ref: component::r#ref(profile), initial_generation: 1,
        non_claims: extension::REQUIRED_SYSTEM_EXTENSION_NON_CLAIMS.to_vec(),
    };
    Ok(extension::admit_manifest(&input, &descriptors, &tier, &[extension::ExecutionProfile::SandboxedComponent])?)
}

fn boundary(host: &mut Host, dir: &Path, label: &str, generation: u64, incarnation: u64, deadline: u64) -> Result<()> {
    let before = host.executor().observations().len();
    let before_sequence = host.invocation_sequence();
    let event_ref = hash_value(&rail::record("extension-smoke-fence-event-v1", vec![
        rail::string(label), rail::u64_value(generation), rail::u64_value(incarnation), rail::u64_value(deadline),
    ]))?;
    let result = host.dispatch(extension::CallbackEvent {
        callback: extension::CallbackKind::Health, generation, incarnation, event_ref: event_ref.clone(),
        payload_ref: None, accounted_bytes: 0, logical_tick: 30, deadline_tick: Some(deadline), cancellation_requested: false,
    });
    let error = match result { Err(error) => error.to_string(), Ok(_) => return Err(format!("{label} unexpectedly reached dispatch").into()) };
    check(host.executor().observations().len() == before && host.invocation_sequence() == before_sequence,
        "denied boundary executed guest or consumed callback sequence")?;
    save(dir, &format!("{label}.preserves"), &rail::record("extension-smoke-boundary-observation-v1", vec![
        rail::string(label), rail::string(event_ref), rail::string(error), rail::u64_value(before_sequence),
        rail::u64_value(host.invocation_sequence()),
    ]))?;
    Ok(())
}

fn request(host: &mut Host, a: &ExtensionAuthority, values: &extension::SharedCallbackValuePort, dir: &Path, label: &str, tick: u64, expected: &str) -> Result<String> {
    // Each callback owns a fresh one-call Session, so its effect sequence is 0.
    let request_bytes = a.request(host.state().generation, host.state().incarnation, 0)?;
    let decoded_request = component::decode_host_request(&request_bytes).map_err(denial)?;
    let payload = publish(values, request_bytes.clone())?;
    std::fs::write(dir.join(format!("{label}-request.preserves")), &request_bytes)?;
    let dispatched = host.dispatch_request(&payload.value_ref, payload.bytes.len() as u64, tick)?.require_executed(label);
    if dispatched.is_err() {
        eprintln!("request executor observations={:#?}", host.executor().observations());
        for observation in host.executor().observations() {
            let sequence = observation.envelope.invocation.sequence;
            std::fs::write(dir.join(format!("diagnostic-callback-{sequence}-envelope.preserves")), &observation.envelope.bytes)?;
            for (ordinal, receipt) in observation.execution.receipts.iter().enumerate() {
                save(dir, &format!("diagnostic-callback-{sequence}-runtime-{ordinal}.preserves"), &component::value(receipt))?;
            }
        }
    }
    let (receipt, outcome) = dispatched?;
    check(outcome.output_refs.len() == 1, "guest did not produce exactly one host-response output")?;
    let output = values.lock().map_err(|_| "callback values lock poisoned")?.materialize(&outcome.output_refs[0], component::HOST_PAYLOAD_BYTES).map_err(denial)?;
    let response = component::decode_host_response(&output.bytes, &decoded_request).map_err(denial)?;
    check(response.response().decision == expected, "host response admission decision mismatch")?;
    if expected == "pass" {
        check(response.output() == Some(&a.output), "live blob host did not return the published canonical value")?;
    } else {
        check(response.output().is_none(), "authority-denied response leaked output")?;
        check(response.response().diagnostics == vec!["authority-denial".to_string()], "negative case was not a real authority denial")?;
    }
    check(host.semantic_state_ref() == Some(output.value_ref.as_str()), "Dispatcher semantic state did not adopt admitted guest response")?;
    check(host.executor().state_ref() == host.semantic_state_ref(), "executor and lifecycle semantic state diverged")?;
    std::fs::write(dir.join(format!("{label}-response.preserves")), output.bytes)?;
    save(dir, &format!("{label}-callback.preserves"), &receipt.value)?;
    Ok(output.value_ref)
}

fn fail_request(host: &mut Host, values: &extension::SharedCallbackValuePort, dir: &Path) -> Result<()> {
    let payload = publish(values, rail::canonical_bytes(&rail::record("extension-smoke-invalid-effect-carrier-v1", Vec::new()))?)?;
    let before = host.executor().observations().len();
    match host.dispatch_request(&payload.value_ref, payload.bytes.len() as u64, 45)? {
        extension::DispatchResult::Failed { receipt, lifecycle } => {
            check(receipt.decision == extension::CallbackExecutionDecision::ExecutorFailed, "malformed host carrier was not a real executor failure")?;
            save(dir, "failed-request-callback.preserves", &receipt.value)?;
            save(dir, "failed-request-lifecycle.preserves", &lifecycle.value)?;
        }
        _ => return Err("malformed effect carrier unexpectedly succeeded or deferred".into()),
    }
    check(host.executor().observations().len() == before + 1, "failure happened before actual guest execution")?;
    let observed = host.executor().observations().last().ok_or("failed callback observation missing")?;
    check(!observed.execution.is_pass() && !observed.is_committed && observed.publication_refs.is_empty(), "failed guest callback was committed")?;
    check(host.state().phase == extension::LifecyclePhase::Failed, "actual callback failure did not reach failed lifecycle")?;
    Ok(())
}

fn write_observations(host: &Host, factory: &ExtensionHostFactory, dir: &Path) -> Result<()> {
    let values = host.executor().values();
    let mut index = Vec::new();
    for observation in host.executor().observations() {
        let sequence = observation.envelope.invocation.sequence;
        std::fs::write(dir.join(format!("callback-{sequence}-envelope.preserves")), &observation.envelope.bytes)?;
        if !observation.is_committed {
            check(observation.envelope.invocation.callback == extension::CallbackKind::Request
                && !observation.execution.is_pass() && observation.publication_refs.is_empty(),
                "an unexpected required lifecycle callback failed or published unadmitted values")?;
        }
        let mut receipt_refs = Vec::new();
        for (ordinal, receipt) in observation.execution.receipts.iter().enumerate() {
            let actual = save(dir, &format!("callback-{sequence}-runtime-{ordinal}.preserves"), &component::value(receipt))?;
            check(actual == receipt.receipt_ref, "runtime receipt hash differs from canonical value")?;
            receipt_refs.push(actual);
        }
        if let Some(outcome) = &observation.materialized_outcome {
            let expected_values = outcome.values().collect::<Vec<_>>();
            check(expected_values.len() == observation.publication_refs.len(), "callback publication receipts do not cover every materialized value")?;
            for item in expected_values {
                let stored = values.lock().map_err(|_| "callback values lock poisoned")?.materialize(&item.value_ref, component::HOST_PAYLOAD_BYTES).map_err(denial)?;
                check(stored == *item, "committed callback value not present in real capability store")?;
            }
        }
        index.push(rail::record("extension-smoke-callback-observation-v1", vec![
            rail::u64_value(sequence), rail::string(observation.envelope.invocation.callback.as_str()),
            rail::string(&observation.envelope.envelope_ref), strings(&receipt_refs), strings(&observation.publication_refs),
            rail::string(if observation.is_committed { "committed" } else { "rejected" }),
        ]));
    }
    for (sequence, recording) in factory.recordings.borrow().iter() {
        let records = recording.snapshot().map_err(denial)?;
        if let Some(failure) = &records.failure {
            let callback = host.executor().observations().iter().find(|observation| observation.envelope.invocation.sequence == *sequence)
                .ok_or("host recording has no callback observation")?;
            check(!callback.execution.is_pass() && !callback.is_committed && records.effects.is_empty(), "unexpected live host recording failure")?;
            save(dir, &format!("callback-{sequence}-host-denial.preserves"), &rail::record("extension-smoke-host-denial-observation-v1", vec![
                rail::u64_value(*sequence), rail::string(failure.canonical_class()),
            ]))?;
        }
        for (ordinal, effect) in records.effects.iter().enumerate() {
            std::fs::write(dir.join(format!("callback-{sequence}-effect-{ordinal}-record.preserves")), &effect.record.bytes)?;
            std::fs::write(dir.join(format!("callback-{sequence}-effect-{ordinal}-response.preserves")), &effect.response_bytes)?;
            let stored = values.lock().map_err(|_| "callback values lock poisoned")?.materialize(&effect.record.value_ref, component::HOST_PAYLOAD_BYTES).map_err(denial)?;
            check(stored == effect.record, "live Session recording not published to actual store")?;
        }
    }
    for (ordinal, evidence) in host.evidence().iter().enumerate() {
        let canonical = match evidence {
            extension::Evidence::Lifecycle(receipt) => &receipt.value,
            extension::Evidence::Callback(receipt) => &receipt.value,
            extension::Evidence::EffectCompletion(receipt) => &receipt.value,
            extension::Evidence::Migration(receipt) => &receipt.value,
            extension::Evidence::Readiness(receipt) => &receipt.value,
        };
        check(save(dir, &format!("lifecycle-evidence-{ordinal}.preserves"), canonical)? == evidence.evidence_ref(), "lifecycle evidence identity mismatch")?;
    }
    save(dir, "callback-observations.preserves", &rail::record("extension-smoke-callback-index-v1", index))?;
    Ok(())
}

fn run() -> Result<()> {
    let args = std::env::args_os().skip(1).map(PathBuf::from).collect::<Vec<_>>();
    check(args.len() == 3, "usage: extension_smoke BUNDLE_JSON OUTPUT_DIR ADMISSION_JSON")?;
    let bundle_bytes = std::fs::read(&args[0])?;
    let admission: AdmissionInput = serde_json::from_slice(&std::fs::read(&args[2])?)?;
    std::fs::create_dir(&args[1])?; // fresh output is required; prior evidence is never overwritten
    let dir = &args[1];
    let profile = component::hosted().map_err(denial)?;
    let root = cap_std::fs::Dir::open_ambient_dir("/", cap_std::ambient_authority())?;
    let staging = cap_std::fs::Dir::open_ambient_dir(dir, cap_std::ambient_authority())?;
    let bundle = Arc::new(component::VerifiedBundle::load(&root, &staging, "extension-private-stage", &bundle_bytes, &profile).map_err(denial)?);
    std::fs::write(dir.join("mantle-structural.json"), serde_json::to_vec_pretty(bundle.structural_report())?)?;
    std::fs::write(dir.join("mantle-byte-verification.json"), serde_json::to_vec_pretty(bundle.verification_report())?)?;
    std::fs::write(dir.join("mantle-member-observations.json"), serde_json::to_vec_pretty(bundle.member_observations())?)?;
    let component_ref = rail::content_ref_from_bytes(bundle.component_bytes());
    let facts = extension_measure::measure(bundle.component_bytes(), &profile)?;
    save(dir, "measured-facts.preserves", &rail::record("extension-smoke-measured-facts-v1", vec![
        rail::string(&component_ref), rail::string(rail::content_ref_from_bytes(bundle.wit_bytes())),
        rail::string(component::r#ref(&profile)), rail::string(&facts.declared_world),
        strings(&facts.imports), strings(&facts.exports), strings(&facts.enabled_features),
        rail::u64_value(facts.memory.initial), rail::u64_value(facts.table.initial),
        rail::u64_value(facts.instances), rail::u64_value(facts.memories), rail::u64_value(facts.tables),
    ]))?;
    let import_manifest = component::build_manifest(component::ManifestInput {
        profile_id: profile.profile_id.clone(), wit_package: profile.wit.package.clone(), world: profile.wit.world.clone(),
        imports: facts.imports.clone(), exports: facts.exports.clone(),
    }).map_err(denial)?;
    let authority = Rc::new(ExtensionAuthority::new(&admission, component_ref.clone(), bundle.bundle_ref().to_string())?);
    let envelope = component::AdmissionEnvelope {
        schema_id: component::COMPONENT_ADMISSION_ENVELOPE_SCHEMA.to_string(), bundle_ref: bundle.bundle_ref().to_string(),
        valence_sidecar_refs: extension_authority::evidence_refs(&admission.valence_evidence_paths)?,
        cairn_acceptance_refs: extension_authority::evidence_refs(&admission.cairn_evidence_paths)?,
        policy_refs: vec![authority.policy_ref.clone()], authority_refs: vec![authority.credential_ref.clone()],
        resource_refs: vec![authority.grant.resource_ref.clone()],
    };
    save(dir, "admission-linkage.preserves", &rail::record("extension-smoke-admission-linkage-v1", vec![
        rail::string(&envelope.schema_id), rail::string(&envelope.bundle_ref),
        strings(&envelope.valence_sidecar_refs), strings(&envelope.cairn_acceptance_refs),
        strings(&envelope.policy_refs), strings(&envelope.authority_refs), strings(&envelope.resource_refs),
    ]))?;
    let admitted = manifest(&component_ref, &bundle, &authority, &profile)?;
    save(dir, "installed-manifest.preserves", admitted.value())?;
    save(dir, "effect-manifest.preserves", &authority.manifest)?;
    save(dir, "handler-profile.preserves", &authority.handler_profile)?;
    save(dir, "import-manifest.preserves", &component::manifest_value(&import_manifest))?;
    let values = extension_authority::shared_values(dir)?;
    publish(&values, rail::canonical_bytes(&authority.output)?)?;
    let factory = ExtensionHostFactory {
        authority: authority.clone(), values: values.clone(), deny: Rc::new(Cell::new(false)),
        recordings: Rc::new(RefCell::new(Vec::new())),
    };
    let installation = extension::Installation {
        admitted: admitted.clone(), profile, materialization: bundle.clone(), envelope, facts, import_manifest,
        import_grants: vec![authority.grant.clone()], instance_id: "extension-smoke-instance".to_string(),
    };
    let executor = extension::Executor::new(installation, values.clone(), factory.clone()).map_err(denial)?;
    let mut host = extension::Dispatcher::new(admitted, executor)?;
    let activated = host.activate(10);
    if activated.is_err() {
        eprintln!("startup executor observations={:#?}", host.executor().observations());
        eprintln!("startup canonical lifecycle evidence={:#?}", host.evidence());
    }
    activated?;
    check(host.state().phase == extension::LifecyclePhase::Running, "real initialization/start did not reach running")?;
    let pass_ref = request(&mut host, &authority, &values, dir, "admitted", 20, "pass")?;
    extension_regressions::run(&host, &factory, dir)?;
    factory.deny.set(true);
    let deny_ref = request(&mut host, &authority, &values, dir, "denied", 21, "deny")?;
    factory.deny.set(false);
    check(pass_ref != deny_ref, "admitted and denied canonical host responses have the same identity")?;
    let generation = host.state().generation;
    let incarnation = host.state().incarnation;
    boundary(&mut host, dir, "stale-installed-generation", generation.checked_sub(1).ok_or("installed generation is zero")?, incarnation, 40)?;
    boundary(&mut host, dir, "expired-callback-deadline", generation, incarnation, 29)?;
    host.checkpoint(40)?;
    let checkpoint_ref = host.state().checkpoint_ref.clone().ok_or("checkpoint missing")?;
    check(checkpoint_ref == deny_ref, "guest checkpoint did not preserve exact committed response bytes")?;
    fail_request(&mut host, &values, dir)?;
    host.restart(50)?;
    check(host.state().phase == extension::LifecyclePhase::Running && host.state().incarnation > incarnation, "real restart/recover did not return running with a new incarnation")?;
    check(host.semantic_state_ref() == Some(checkpoint_ref.as_str()), "restart did not recover exact published checkpoint")?;
    boundary(&mut host, dir, "stale-pre-restart-incarnation", generation, incarnation, 40)?;
    request(&mut host, &authority, &values, dir, "refreshed-post-restart", 59, "pass")?;
    host.health(60)?.require_executed("post-restart health")?;
    host.drain(70)?;
    host.shutdown(80)?;
    check(host.state().phase == extension::LifecyclePhase::Stopped, "real drain/shutdown did not reach stopped")?;
    write_observations(&host, &factory, dir)?;
    let status = host.operator_status()?;
    save(dir, "status.preserves", &status.value)?;
    let report = rail::record("extension-smoke-observed-v1", vec![
        rail::string(bundle.bundle_ref()), rail::string(component_ref), rail::string(host.manifest().manifest_ref()),
        rail::string(component::r#ref(&host.executor().installation().profile)),
        rail::string(pass_ref), rail::string(deny_ref), rail::string(checkpoint_ref),
        rail::u64_value(host.state().generation), rail::u64_value(host.state().incarnation),
        rail::string(host.state().phase.as_str()),
        strings(&host.evidence().iter().map(|evidence| evidence.evidence_ref().to_string()).collect::<Vec<_>>()),
        rail::string("fabric content-store binding is declared, not stream-protocol exercised; value publication is process-visible, not a durability proof; neutral trap/malformed/fuel coverage belongs to actor smoke"),
    ]);
    let report_ref = save(dir, "extension-smoke.preserves", &report)?;
    println!("extension-smoke observed={report_ref} output={}", dir.display());
    Ok(())
}
fn main() {
    if let Err(error) = run() { eprintln!("extension-smoke failed: {error}"); std::process::exit(1); }
}
