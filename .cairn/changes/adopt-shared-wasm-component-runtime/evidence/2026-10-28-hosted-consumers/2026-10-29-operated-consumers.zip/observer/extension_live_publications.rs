use super::*;
use component::consumer::host::{Live, SharedValuePort};
use std::sync::atomic::{AtomicUsize, Ordering};

struct ProtectedReadPort {
    publications: PublicationBoundaryPort,
    protected_ref: String,
    protected_reads: Arc<AtomicUsize>,
}

impl extension::NativeCallbackValuePort for ProtectedReadPort {
    fn materialize(&mut self, reference: &str, maximum: u64) -> std::result::Result<extension::NativeCallbackValue, extension::ValuePortFailure> {
        if reference == self.protected_ref { self.protected_reads.fetch_add(1, Ordering::SeqCst); }
        self.publications.materialize(reference, maximum)
    }
    fn publish(&mut self, value: &extension::NativeCallbackValue, maximum: u64) -> std::result::Result<extension::ValuePublicationReceipt, extension::ValuePortFailure> {
        self.publications.publish(value, maximum)
    }
}

pub fn run(host: &Host, factory: &ExtensionHostFactory, original: &extension::HostedObservation, dir: &Path) -> Result<()> {
    for mode in 1..=4 {
        let flag = Arc::new(std::sync::atomic::AtomicU8::new(0));
        let protected_reads = Arc::new(AtomicUsize::new(0));
        let port = extension::shared_callback_value_port(ProtectedReadPort {
            publications: PublicationBoundaryPort { inner: host.executor().values().clone(), mode: flag.clone() },
            protected_ref: hash_value(&factory.authority.output)?, protected_reads: protected_reads.clone(),
        });
        let live_factory = |_: &extension::CallbackContext, actual: &extension::CallbackInvocation| {
            let request = factory.authority.request(actual.generation, actual.incarnation, 0)
                .map_err(|error| component::Denial::new(error.to_string()))?;
            // A real, distinct holder nonce for this independent execution.
            let nonce_sequence = actual.sequence.checked_add(u64::from(mode) * 100).ok_or_else(|| component::Denial::new("nonce sequence overflow"))?;
            let current = factory.authority.current(&request, actual.generation, actual.incarnation, nonce_sequence, false)
                .map_err(|error| component::Denial::new(error.to_string()))?;
            let (live, _) = Live::new(factory.authority.scope.clone(), actual.generation, actual.incarnation,
                current, SharedValuePort(port.clone()))?;
            Ok(extension::Binding::live(live))
        };
        let executor = extension::Executor::new(copy_installation(host.executor().installation()), port.clone(), live_factory).map_err(denial)?;
        let mut dispatcher = extension::Dispatcher::new(host.manifest().clone(), executor)?;
        dispatcher.activate(10)?;
        // Admission/request/intent succeed; the real protected read occurs;
        // then inject uncertainty or definite rejection at response publication.
        flag.store(48 + mode, Ordering::SeqCst);
        let payload = original.envelope.inputs.payload.as_ref().ok_or("request payload missing")?;
        let invocation = &original.envelope.invocation;
        let result = dispatcher.dispatch_request(&payload.value_ref, payload.bytes.len() as u64, invocation.logical_tick)?;
        check(matches!(result, extension::DispatchResult::Failed { .. }), "live Session publication failure was admitted")?;
        let observed = dispatcher.executor().observations().last().ok_or("live failure observation missing")?.clone();
        check(!observed.execution.is_pass() && !observed.is_committed && observed.materialized_outcome.is_none()
            && observed.publications.is_empty(), "failed hostcall created callback publication or pending state")?;
        let records = observed.host_records.as_ref().map_err(denial)?;
        check(records.effects.is_empty() && records.failure.is_some() && records.publications.len() == 4,
            "live Session lost failed publication boundary or fabricated completion")?;
        check(protected_reads.load(Ordering::SeqCst) == 1, "live host uncertainty did not follow an actual protected blob read")?;
        check(records.publications[..3].iter().all(|attempt| attempt.receipt.is_some() && attempt.failure.is_none()),
            "successful live admission/request/intent publications were not retained")?;
        let attempt = &records.publications[3];
        check(attempt.request_ref == payload.value_ref && attempt.failure.as_ref().ok_or("structured host failure missing")?.may_have_published() == (mode != 4),
            "live host publication uncertainty lost its exact request binding or certainty")?;
        check(attempt.receipt.is_some() == (mode == 2 || mode == 3), "invalid original live publication receipt was discarded")?;
        check(records.has_uncertain_publication() == (mode != 4) && observed.is_publication_uncertain == (mode != 4),
            "host uncertainty did not propagate to callback observation")?;
        if mode != 4 {
            let stored = host.executor().values().lock().map_err(|_| "value store lock")?
                .materialize(&attempt.value_ref, component::HOST_PAYLOAD_BYTES).map_err(denial)?;
            check(stored.value_ref == attempt.value_ref && stored.bytes.len() as u64 == attempt.byte_count,
                "unknown accepted live publication was not the real retained store value")?;
            check(dispatcher.state().phase == extension::LifecyclePhase::Quarantined, "unknown live host publication remained retryable")?;
            let before = dispatcher.executor().observations().len();
            let mut later = invocation.clone(); later.sequence += 1; later.incarnation += 1;
            check(dispatcher.executor_mut().invoke(&later).is_err() && dispatcher.executor().observations().len() == before,
                "fresh incarnation bypassed unresolved live publication fence")?;
            check(dispatcher.restart(50).is_err() && protected_reads.load(Ordering::SeqCst) == 1,
                "unknown live publication allowed restart or another protected read")?;
        } else {
            check(dispatcher.state().phase == extension::LifecyclePhase::Failed, "definite live rejection was treated as unknown acceptance")?;
        }
        component::validate_chain(&observed.execution.receipts).map_err(denial)?;
        for (index, receipt) in observed.execution.receipts.iter().enumerate() {
            save(dir, &format!("extension-live-publication-{mode}-runtime-{index}.preserves"), &component::value(receipt))?;
        }
        save(dir, &format!("extension-live-publication-{mode}.preserves"), &rail::record("extension-live-publication-failure-v1", vec![
            rail::string(&attempt.request_ref), rail::string(&attempt.value_ref), rail::u64_value(attempt.byte_count),
            rail::string(dispatcher.state().phase.as_str()), rail::u64_value(protected_reads.load(Ordering::SeqCst) as u64),
            rail::string(if mode == 4 { "rejected-before-acceptance" } else { "unknown-after-acceptance" }),
        ]))?;
    }
    Ok(())
}
