use std::path::PathBuf;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args = std::env::args().skip(1).collect::<Vec<_>>();
    match args.first().map(String::as_str) {
        Some("profile") if args.len() == 1 => {
            let profile = molten::wasm_component::hosted()?;
            println!("{}", molten::wasm_component::r#ref(&profile));
        }
        Some("structure") if args.len() == 2 => {
            let bytes = std::fs::read(&args[1])?;
            let report = mantle_wasm_consumer_verifier::verify_consumer_bundle(serde_json::from_slice(&bytes)?);
            println!("{}", serde_json::to_string_pretty(&report)?);
        }
        Some("runtime-source") if args.len() == 2 => {
            let value = molten::wasm_component::source_cohort();
            let bytes = molten::preserves_rail::canonical_bytes(&value)?;
            let mut file = std::fs::OpenOptions::new().write(true).create_new(true).open(&args[1])?;
            std::io::Write::write_all(&mut file, &bytes)?;
            println!("runtime-source={} output={}", molten::preserves_rail::canonical_hash(&value)?, args[1]);
        }
        Some("sidecar") if args.len() == 4 => {
            let export = std::fs::read_to_string(&args[1])?;
            let artifact = std::fs::read(&args[2])?;
            let digest = blake3::hash(&artifact).to_hex().to_string();
            let output = valence::stack_provenance_adapter::build_sidecar_json_from_octet_export_json(&export, &digest)
                .map_err(|report| format!("Valence sidecar denied: {report:?}"))?;
            let sidecar: valence::stack_provenance_adapter::StackProvenanceSidecar = serde_json::from_str(&output)?;
            let report = valence::stack_provenance_adapter::validate_stack_provenance_sidecar(&sidecar);
            if !report.valid { return Err(format!("Valence validation failed: {report:?}").into()); }
            let path = PathBuf::from(&args[3]);
            let mut file = std::fs::OpenOptions::new().write(true).create_new(true).open(&path)?;
            std::io::Write::write_all(&mut file, output.as_bytes())?;
            println!("Valence valid={} subject={} sidecar={} output={}", report.valid, digest, blake3::hash(output.as_bytes()).to_hex(), path.display());
        }
        _ => return Err("usage: evidence_helper profile | runtime-source NEW_OUTPUT | sidecar OCTET_EXPORT COMPONENT NEW_SIDECAR".into()),
    }
    Ok(())
}
