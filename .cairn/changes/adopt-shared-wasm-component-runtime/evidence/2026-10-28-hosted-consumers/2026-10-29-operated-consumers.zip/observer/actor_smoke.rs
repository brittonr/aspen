mod actor_authority;
mod actor_artifact;

use std::path::{Path, PathBuf};
use std::sync::{Arc, atomic::{AtomicUsize, Ordering}};
use molten::{preserves_rail as rail, system_extension as extension, wasm_component as wc};
use molten::system_extension::NativeCallbackValuePort;
use wc::consumer::{ActorInstallInput, ActorInvocationInput, Actor};
use actor_authority::{Authority, CountedValues, GENERATION, INCARNATION, Result, require};

// Disposable external consumer only. All authority/evidence paths are explicit
// inputs; nothing here constructs or rewrites a Mantle materialization bundle.
fn main() -> Result<()> {
    let args = std::env::args_os().skip(1).map(PathBuf::from).collect::<Vec<_>>();
    require((5..=6).contains(&args.len()),
        "usage: actor_smoke BUNDLE_JSON FRESH_OUTPUT_DIR VALENCE_SIDECAR CAIRN_ACCEPTANCE HOST_POLICY_JSON [MEMBER_ROOT]")?;
    let bundle_path = std::fs::canonicalize(&args[0])?;
    let output = &args[1];
    // Require a fresh destination so no prior run can be mistaken for this one.
    std::fs::create_dir(output)?;
    let output = std::fs::canonicalize(output)?;
    let root_path = args.get(5).map(PathBuf::as_path).unwrap_or_else(|| Path::new("/"));
    let root = cap_std::fs::Dir::open_ambient_dir(root_path, cap_std::ambient_authority())?;
    let staging = cap_std::fs::Dir::open_ambient_dir(&output, cap_std::ambient_authority())?;
    let bundle_json = std::fs::read(&bundle_path)?;
    std::fs::write(output.join("mantle-bundle-unchanged.json"), &bundle_json)?;
    let structural = mantle_wasm_consumer_verifier::verify_consumer_bundle(serde_json::from_slice(&bundle_json)?);
    std::fs::write(output.join("mantle-preflight-structural-report.json"), serde_json::to_vec_pretty(&structural)?)?;
    let profile = wc::hosted()?;
    std::fs::write(output.join("actual-runtime-profile.json"), serde_json::to_vec_pretty(&profile)?)?;
    let bundle = Arc::new(wc::VerifiedBundle::load(&root, &staging, "actor-private-verification", &bundle_json, &profile)?);
    std::fs::write(output.join("mantle-structural-report.json"), serde_json::to_vec_pretty(bundle.structural_report())?)?;
    std::fs::write(output.join("mantle-structural-bytes-report.json"), serde_json::to_vec_pretty(bundle.verification_report())?)?;
    std::fs::write(output.join("mantle-member-observations.json"), serde_json::to_vec_pretty(bundle.member_observations())?)?;
    let component_ref = rail::content_ref_from_bytes(bundle.component_bytes());
    let wit_ref = rail::content_ref_from_bytes(bundle.wit_bytes());
    let facts = actor_artifact::measure(&bundle, &profile)?;
    save_value(&output, "actual-artifact-facts", &actor_artifact::facts_value(&facts))?;
    println!("verified Structural+Bytes bundle={} component={} wit={} profile={} memories={} tables={} instances={} memory-bytes={} table-elements={} imports={:?} exports={:?}",
        bundle.bundle_ref(), component_ref, wit_ref, wc::r#ref(&profile), facts.memories, facts.tables, facts.instances,
        facts.memory.initial, facts.table.initial, facts.imports, facts.exports);
    require(facts.imports == [wc::HOST_REQUEST_IMPORT.to_string()], "neutral artifact must have exact real effect-request import")?;
    let policy_json = std::fs::read_to_string(&args[4])?;
    let authority = Authority::new(&component_ref, policy_json.clone(), false)?;
    std::fs::write(output.join("actual-host-policy.json"), policy_json.as_bytes())?;
    save_value(&output, "actual-host-policy", &rail::record("component-host-policy-v1", vec![rail::string(&policy_json)]))?;
    let credential = authority.public_credential();
    require(rail::canonical_hash(&credential)? == authority.grant.authority_ref, "actual issued credential identity differs from grant")?;
    save_value(&output, "actual-issued-smoke-credential", &credential)?;
    save_value(&output, "actual-handler-profile", &authority.profile)?;
    save_value(&output, "actual-effect-manifest", &authority.manifest)?;
    save_value(&output, "actual-blob", &authority.blob)?;
    std::fs::write(output.join("actual-host-request.preserves"), &authority.request)?;
    let envelope = wc::AdmissionEnvelope {
        schema_id: wc::COMPONENT_ADMISSION_ENVELOPE_SCHEMA.to_string(), bundle_ref: bundle.bundle_ref().to_string(),
        valence_sidecar_refs: vec![copy_evidence(&args[2], &output, "current-valence-sidecar")?],
        cairn_acceptance_refs: vec![copy_evidence(&args[3], &output, "current-cairn-acceptance")?],
        policy_refs: vec![authority.grant.policy_ref.clone()], authority_refs: vec![authority.grant.authority_ref.clone()],
        resource_refs: vec![authority.grant.resource_ref.clone()],
    };
    save_value(&output, "actual-admission-envelope", &actor_artifact::envelope_value(&envelope))?;
    let manifest = wc::build_manifest(wc::ManifestInput {
        profile_id: profile.profile_id.clone(), wit_package: profile.wit.package.clone(), world: profile.wit.world.clone(),
        imports: facts.imports.clone(), exports: facts.exports.clone(),
    })?;
    save_value(&output, "actual-import-manifest", &wc::manifest_value(&manifest))?;
    let grants = vec![authority.grant.clone()];
    let installation = || ActorInstallInput {
        profile: profile.clone(), materialization: bundle.clone(), envelope: envelope.clone(), facts: facts.clone(),
        import_manifest: manifest.clone(), import_grants: grants.clone(),
    };
    // Negative requests change only consumer admission assertions, never producer bytes.
    let mut wrong = installation();
    wrong.envelope.bundle_ref = component_ref.clone();
    install_denial(&output, "wrong-install-bundle-binding", Actor::install(wrong))?;
    let mut wrong = installation();
    wrong.profile = wc::supported()?;
    install_denial(&output, "wrong-install-runtime-profile", Actor::install(wrong))?;
    let mut wrong = installation();
    wrong.facts.instances = wrong.facts.instances.checked_add(1).ok_or("instance count overflow")?;
    install_denial(&output, "wrong-install-measured-facts", Actor::install(wrong))?;
    let mut wrong = installation();
    wrong.import_manifest = wc::build_manifest(wc::ManifestInput {
        profile_id: profile.profile_id.clone(), wit_package: profile.wit.package.clone(), world: profile.wit.world.clone(),
        imports: Vec::new(), exports: facts.exports.clone(),
    })?;
    install_denial(&output, "wrong-install-import-manifest", Actor::install(wrong))?;
    let mut wrong = installation();
    wrong.import_grants.clear();
    install_denial(&output, "wrong-install-missing-current-grant", Actor::install(wrong))?;
    let actor = Actor::install(installation())?;
    let pure_output = rail::record("actor-smoke-pure-return-v1", vec![rail::string(&component_ref)]);
    let pure_input = command(0, &rail::canonical_bytes(&pure_output)?)?;
    let pure_authority = Authority::new(&component_ref, policy_json.clone(), false)?;
    let (pure_values, pure_reads) = values(&output, "pure-values", &pure_authority.blob, None)?;
    let pure = actor.invoke_live(invocation(&pure_input, &grants), wc::consumer::host::LiveInput { scope: pure_authority.scope.clone(), generation: GENERATION, incarnation: INCARNATION, current: pure_authority, values: pure_values })?;
    retain(&output, "pure-return", &pure)?;
    require(pure.outcome.is_pass() && pure.outcome.output.as_ref() == Some(&pure_output), "pure return differs from exact canonical payload")?;
    require(pure.host_recording.snapshot()?.effects.is_empty(), "pure turn unexpectedly invoked a host effect")?;
    require(pure_reads.load(Ordering::SeqCst) == 0, "pure turn read protected blob storage")?;
    for (name, requested_profile) in [("wrong-requested-legacy-profile", wc::RequestedExecutionProfile::LegacyCoreV1),
        ("wrong-requested-sliced-profile", wc::RequestedExecutionProfile::TimeSlicedComponentV1)] {
        let denied = actor.invoke(ActorInvocationInput { input: &pure_input, requested_profile, import_grants: &grants });
        retain(&output, name, &denied)?;
        require(!denied.outcome.is_pass(), "wrong requested profile unexpectedly admitted")?;
    }
    let no_grant = actor.invoke(invocation(&pure_input, &[]));
    retain(&output, "wrong-turn-missing-current-grant", &no_grant)?;
    require(!no_grant.outcome.is_pass(), "turn ran without current import grant")?;

    let request_bytes = authority.request.clone();
    let effect_input = command(1, &request_bytes)?;
    let blob = authority.blob.clone();
    let scope = authority.scope.clone();
    let (live_values, reads) = values(&output, "admitted-values", &blob, None)?;
    let live = actor.invoke_live(invocation(&effect_input, &grants), wc::consumer::host::LiveInput { scope: scope.clone(), generation: GENERATION, incarnation: INCARNATION, current: authority, values: live_values })?;
    retain(&output, "signed-admitted-effect", &live)?;
    require(live.outcome.is_pass(), "genuine signed effect invocation failed")?;
    let records = live.host_recording.snapshot()?;
    require(records.effects.len() == 1 && records.failure.is_none(), "signed effect did not complete exactly one recorded boundary")?;
    let decoded_request = wc::decode_host_request(&request_bytes)?;
    let response = wc::decode_host_response(&records.effects[0].response_bytes, &decoded_request)?;
    require(response.response().decision == "pass" && response.output() == Some(&blob), "admitted host effect did not return the actual stored canonical blob")?;
    require(reads.load(Ordering::SeqCst) == 1, "admitted effect did not perform exactly one real protected blob read")?;
    require(live.outcome.output.as_ref() == Some(&rail::parse_canonical_bytes(&records.effects[0].response_bytes)?), "guest did not return exact actual host response")?;
    println!("signed-admitted-effect decision=pass protected-blob-materializations=1 output={}", rail::canonical_hash(&blob)?);

    // The host's genuine current grant and the guest agree, but the outer
    // admitted runtime grant differs. This must stop before host dispatch.
    let current = Authority::new(&component_ref, policy_json.clone(), false)?;
    let mut mismatched = grants.clone();
    mismatched[0].recorded_effect_ref = rail::content_ref_from_bytes(b"different-outer-grant");
    let (mismatch_values, mismatch_reads) = values(&output, "mismatched-grant-values", &blob, None)?;
    let mismatch = actor.invoke_live(invocation(&effect_input, &mismatched), wc::consumer::host::LiveInput { scope: scope.clone(), generation: GENERATION, incarnation: INCARNATION, current: current, values: mismatch_values })?;
    retain(&output, "mismatched-outer-guest-grant", &mismatch)?;
    require(!mismatch.outcome.is_pass() && mismatch.host_recording.snapshot()?.effects.is_empty()
        && mismatch_reads.load(Ordering::SeqCst) == 0, "outer grant mismatch reached protected host effects")?;

    let current = Authority::new(&component_ref, policy_json.clone(), true)?;
    require(current.request == request_bytes, "current authority denial changed guest request bytes instead of current verification time")?;
    let (denied_values, denied_reads) = values(&output, "authority-denied-values", &blob, None)?;
    let denied = actor.invoke_live(invocation(&effect_input, &grants), wc::consumer::host::LiveInput { scope: scope.clone(), generation: GENERATION, incarnation: INCARNATION, current: current, values: denied_values })?;
    retain(&output, "expired-current-authority-effect", &denied)?;
    require(denied.outcome.is_pass(), "neutral guest must return actual denied effect response without fabricating execution failure")?;
    let denied_records = denied.host_recording.snapshot()?;
    require(denied_records.effects.len() == 1 && denied_records.failure.is_none(), "authority denial did not retain actual completed deny boundary")?;
    let response = wc::decode_host_response(&denied_records.effects[0].response_bytes, &decoded_request)?;
    require(response.response().decision == "deny" && response.output().is_none(), "expired current UCAN authority did not deny effect")?;
    require(denied_reads.load(Ordering::SeqCst) == 0, "authority denial accessed protected blob storage")?;
    println!("expired-current-authority effect-decision=deny actor-execution=pass protected-blob-materializations=0");

    let replay = actor.replay(invocation(&effect_input, &grants), scope.clone(), GENERATION, INCARNATION, records.effects.clone())?;
    retain(&output, "offline-exact-replay", &replay)?;
    replay.host_recording.ensure_replay_complete()?;
    require(replay.outcome.is_pass() && replay.outcome.output == live.outcome.output, "offline replay output diverged")?;
    require(wc::replay_receipts_match(&live.outcome.receipts, &replay.outcome.receipts), "offline replay canonical receipt chain diverged")?;
    require(reads.load(Ordering::SeqCst) == 1, "offline replay contacted live value storage")?;
    println!("offline-exact-replay canonical-receipts=equal live-store-additional-reads=0");
    let mut altered = records.effects.clone();
    altered[0].response_bytes.push(0);
    replay_denial(&actor, &output, "offline-altered-response", &effect_input, &grants, scope.clone(), altered)?;
    let mut altered = records.effects.clone();
    altered[0].entry.turn_ref = component_ref.clone();
    replay_denial(&actor, &output, "offline-altered-effect-log", &effect_input, &grants, scope.clone(), altered)?;
    let mut trailing = records.effects.clone();
    trailing.extend(records.effects.clone());
    replay_denial(&actor, &output, "offline-trailing-boundary", &effect_input, &grants, scope.clone(), trailing)?;
    replay_denial(&actor, &output, "offline-missing-boundary", &effect_input, &grants, scope.clone(), Vec::new())?;
    for (name, opcode, expected) in [("actual-guest-trap", 2, "component-trap"),
        ("actual-malformed-result", 3, "invalid-preserves-payload"), ("actual-fuel-exhaustion", 4, "fuel-exhausted")] {
        let input = command(opcode, &[])?;
        let current = Authority::new(&component_ref, policy_json.clone(), false)?;
        let (actual_values, protected_reads) = values(&output, &format!("{name}-values"), &blob, None)?;
        let observed = actor.invoke_live(invocation(&input, &grants), wc::consumer::host::LiveInput { scope: current.scope.clone(), generation: GENERATION, incarnation: INCARNATION, current: current, values: actual_values })?;
        retain(&output, name, &observed)?;
        require_class(&observed, expected)?;
        require(protected_reads.load(Ordering::SeqCst) == 0 && observed.host_recording.snapshot()?.effects.is_empty(), "guest-only denial touched protected storage or completed a host effect")?;
    }
    // Separate adverse-latency scenario: no bundle/profile/fuel alteration.
    // Sleep is before the actual protected read, not a synthetic host response.
    // The epoch service cannot interrupt a synchronous hostcall; it must stop
    // guest work after the real completed host boundary returns.
    let authority = Authority::new(&component_ref, policy_json, false)?;
    let (slow_values, slow_reads) = values(&output, "deadline-values", &blob, Some(std::time::Duration::from_secs(2)))?;
    let started = std::time::Instant::now();
    let deadline = actor.invoke_live(invocation(&effect_input, &grants), wc::consumer::host::LiveInput { scope: scope, generation: GENERATION, incarnation: INCARNATION, current: authority, values: slow_values })?;
    let elapsed = started.elapsed();
    retain(&output, "actual-operated-deadline-after-host-latency", &deadline)?;
    let completed = deadline.host_recording.snapshot()?;
    save_value(&output, "deadline-host-latency-observation", &rail::record("actor-smoke-deadline-observation-v1", vec![
        rail::u64_value(2_000), rail::u64_value(u64::try_from(elapsed.as_millis())?),
        rail::u64_value(slow_reads.load(Ordering::SeqCst) as u64), rail::u64_value(completed.effects.len() as u64),
        rail::u64_value(profile.resources.fuel),
    ]))?;
    require(slow_reads.load(Ordering::SeqCst) == 1 && completed.effects.len() == 1 && completed.failure.is_none(),
        "deadline scenario did not complete actual protected host operation before guest interruption")?;
    let completed_response = wc::decode_host_response(&completed.effects[0].response_bytes, &decoded_request)?;
    require(completed_response.response().decision == "pass" && completed_response.output() == Some(&blob),
        "deadline boundary must retain actual successful signed host effect")?;
    require(elapsed >= std::time::Duration::from_secs(2), "epoch deadline incorrectly claimed to interrupt a blocked synchronous hostcall")?;
    require_class(&deadline, "deadline-exceeded")?;
    println!("operated-deadline protected-read=1 completed-host-effect=1 elapsed-ms={} synchronous-host-interruption=false unchanged-profile={} unchanged-fuel={}", elapsed.as_millis(), wc::r#ref(&profile), profile.resources.fuel);
    println!("ACTOR_SMOKE_COMPLETE output={}", output.display());
    Ok(())
}

fn command(opcode: u8, payload: &[u8]) -> Result<preserves::IOValue> {
    // Use the actual canonical parser for the neutral guest's closed bytestring
    // command envelope; length is canonical unsigned LEB128 as specified by guest.
    let mut bytes = vec![0xb2];
    let mut length = payload.len().checked_add(1).ok_or("command length overflow")?;
    loop { let byte = (length & 0x7f) as u8; length >>= 7; bytes.push(byte | if length != 0 { 0x80 } else { 0 }); if length == 0 { break; } }
    bytes.push(opcode); bytes.extend_from_slice(payload);
    Ok(rail::parse_canonical_bytes(&bytes)?)
}
fn invocation<'a>(input: &'a preserves::IOValue, grants: &'a [wc::ImportGrant]) -> ActorInvocationInput<'a> {
    ActorInvocationInput { input, requested_profile: wc::RequestedExecutionProfile::ComponentV1, import_grants: grants }
}
fn save_value(output: &Path, name: &str, value: &preserves::IOValue) -> Result<()> {
    std::fs::write(output.join(format!("{name}.preserves")), rail::canonical_bytes(value)?)?; Ok(())
}
fn copy_evidence(source: &Path, output: &Path, name: &str) -> Result<String> {
    let bytes = std::fs::read(source)?;
    require(!bytes.is_empty(), "supplied current evidence artifact is empty")?;
    let reference = rail::content_ref_from_bytes(&bytes);
    // These are caller-selected genuine current Valence/Cairn artifacts, not
    // converted success assertions. Their bytes are retained without rewriting.
    std::fs::write(output.join(format!("{name}.source-bytes")), &bytes)?;
    println!("current-evidence kind={name} source={} measured={reference}", source.display());
    Ok(reference)
}
fn values(output: &Path, leaf: &str, blob: &preserves::IOValue, delay_once: Option<std::time::Duration>) -> Result<(CountedValues, Arc<AtomicUsize>)> {
    let path = output.join(leaf); std::fs::create_dir(&path)?;
    let dir = cap_std::fs::Dir::open_ambient_dir(path, cap_std::ambient_authority())?;
    let namespace = molten::node_state::Scope::from_dir(molten::node_state::NamespaceKind::Ledger, dir)?;
    let mut actual = extension::CapabilityCallbackValuePort::new(namespace)?;
    let bytes = rail::canonical_bytes(blob)?;
    let published = actual.publish(&extension::NativeCallbackValue { value_ref: rail::content_ref_from_bytes(&bytes), bytes }, wc::HOST_PAYLOAD_BYTES)
        .map_err(|error| std::io::Error::other(format!("actual blob publication: {error:?}")))?;
    println!("actual-value-publication value={} receipt={} bytes={}", published.value_ref, published.publication_ref, published.byte_count);
    let materializations = Arc::new(AtomicUsize::new(0));
    Ok((CountedValues { actual, materializations: materializations.clone(), delay_once }, materializations))
}
fn install_denial(output: &Path, name: &str, result: wc::Result<Actor>) -> Result<()> {
    match result {
        Ok(_) => Err(std::io::Error::other(format!("{name}: wrong installation was admitted")).into()),
        Err(denial) => {
            save_value(output, name, &rail::record("actor-smoke-observed-install-denial-v1", vec![
                rail::string(denial.canonical_class()), rail::sequence(denial.blockers.iter().map(rail::string).collect()),
            ]))?;
            println!("{name} install=deny class={} blockers={:?}", denial.canonical_class(), denial.blockers); Ok(())
        },
    }
}
fn retain(output: &Path, name: &str, invocation: &wc::consumer::ActorInvocation) -> Result<()> {
    let path = output.join(name); std::fs::create_dir(&path)?;
    wc::validate_chain(&invocation.outcome.receipts)?;
    for (index, receipt) in invocation.outcome.receipts.iter().enumerate() {
        save_value(&path, &format!("stage-{index}-{}", receipt.input.stage.as_str()), &wc::value(receipt))?;
        println!("{name} stage={} decision={} class={:?} receipt={} diagnostics={:?}", receipt.input.stage.as_str(), receipt.input.decision.as_str(), receipt.input.trap_class, receipt.receipt_ref, receipt.input.diagnostics);
    }
    if let Some(value) = &invocation.outcome.output { save_value(&path, "actual-output", value)?; }
    let records = invocation.host_recording.snapshot()?;
    for (index, effect) in records.effects.iter().enumerate() {
        require(rail::content_ref_from_bytes(&effect.record.bytes) == effect.record.value_ref, "retained host record identity differs from actual bytes")?;
        std::fs::write(path.join(format!("host-{index}-record.preserves")), &effect.record.bytes)?;
        std::fs::write(path.join(format!("host-{index}-response.preserves")), &effect.response_bytes)?;
        save_value(&path, &format!("host-{index}-effect-entry"), &rail::record("actor-smoke-actual-effect-entry-v1", vec![
            rail::u64_value(effect.entry.sequence), rail::string(&effect.entry.request_ref), rail::string(&effect.entry.response_ref),
            rail::string(&effect.entry.effect_kind), rail::string(&effect.entry.run_identity_ref), rail::string(&effect.entry.handler_profile_ref),
            rail::string(&effect.entry.turn_ref), rail::string(&effect.entry.boundary_ref),
        ]))?;
    }
    if let Some(failure) = &records.failure {
        save_value(&path, "actual-host-failure", &rail::record("actor-smoke-observed-host-failure-v1", vec![
            rail::string(failure.canonical_class()), rail::sequence(failure.blockers.iter().map(rail::string).collect()),
        ]))?;
    }
    Ok(())
}
fn require_class(invocation: &wc::consumer::ActorInvocation, expected: &str) -> Result<()> {
    require(!invocation.outcome.is_pass(), "expected execution denial but actual execution passed")?;
    let receipt = invocation.outcome.receipts.last().ok_or("denial receipt missing")?;
    require(receipt.input.stage == wc::Stage::Denial && receipt.input.trap_class.as_deref() == Some(expected),
        &format!("expected actual canonical denial class {expected}; observed {:?}: {:?}", receipt.input.trap_class, receipt.input.diagnostics))
}
fn replay_denial(actor: &Actor, output: &Path, name: &str, input: &preserves::IOValue, grants: &[wc::ImportGrant], scope: wc::host::Scope,
    effects: Vec<wc::consumer::host::RecordedEffect>) -> Result<()> {
    let observed = actor.replay(invocation(input, grants), scope, GENERATION, INCARNATION, effects)?;
    retain(output, name, &observed)?;
    require(!observed.outcome.is_pass(), &format!("{name}: offline replay unexpectedly passed"))?;
    if name == "offline-trailing-boundary" {
        require(observed.outcome.receipts.iter().map(|receipt| receipt.input.stage).collect::<Vec<_>>() == vec![wc::Stage::Inspection, wc::Stage::Instantiation, wc::Stage::Execution, wc::Stage::Denial], "trailing actor replay replaced observed executed stages")?;
        wc::validate_chain(&observed.outcome.receipts)?;
        require(observed.outcome.output.is_none() && observed.outcome.receipts[2].input.fuel_remaining == observed.outcome.receipts[3].input.fuel_remaining, "trailing actor replay lost observed fuel or retained output")?;
    }
    println!("{name} offline-replay=deny no-live-services=true"); Ok(())
}
