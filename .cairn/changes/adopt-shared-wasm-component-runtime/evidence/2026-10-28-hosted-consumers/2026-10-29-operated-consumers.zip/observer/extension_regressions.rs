use super::*;
use component::consumer::host::Replay;
use extension::SystemExtensionExecutor;

#[path = "extension_live_publications.rs"]
mod live_host_publications;

fn copy_installation(input: &extension::Installation) -> extension::Installation {
    extension::Installation {
        admitted: input.admitted.clone(), profile: input.profile.clone(), materialization: input.materialization.clone(),
        envelope: input.envelope.clone(), facts: input.facts.clone(), import_manifest: input.import_manifest.clone(),
        import_grants: input.import_grants.clone(), instance_id: input.instance_id.clone(),
    }
}

struct PublicationBoundaryPort {
    inner: extension::SharedCallbackValuePort,
    mode: Arc<std::sync::atomic::AtomicU8>,
}

impl extension::NativeCallbackValuePort for PublicationBoundaryPort {
    fn materialize(&mut self, reference: &str, maximum: u64) -> std::result::Result<extension::NativeCallbackValue, extension::ValuePortFailure> {
        self.inner.lock().map_err(|_| extension::ValuePortFailure::new(extension::ValuePortFailureKind::RejectedBeforeAcceptance, "smoke store lock"))?.materialize(reference, maximum)
    }
    fn publish(&mut self, value: &extension::NativeCallbackValue, maximum: u64) -> std::result::Result<extension::ValuePublicationReceipt, extension::ValuePortFailure> {
        let encoded = self.mode.load(std::sync::atomic::Ordering::SeqCst);
        let mode = if encoded >= 16 {
            self.mode.fetch_sub(16, std::sync::atomic::Ordering::SeqCst);
            0
        } else { self.mode.swap(0, std::sync::atomic::Ordering::SeqCst) };
        if mode == 4 {
            return Err(extension::ValuePortFailure::new(extension::ValuePortFailureKind::RejectedBeforeAcceptance, "injected definite preacceptance rejection"));
        }
        let mut receipt = self.inner.lock().map_err(|_| extension::ValuePortFailure::new(extension::ValuePortFailureKind::RejectedBeforeAcceptance, "smoke store lock"))?.publish(value, maximum)?;
        match mode {
            1 => return Err(extension::ValuePortFailure::new(extension::ValuePortFailureKind::UnknownAfterAcceptance, "actual publication completed but completion unavailable")),
            2 => receipt.byte_count = receipt.byte_count.checked_add(1).ok_or_else(||
                extension::ValuePortFailure::new(extension::ValuePortFailureKind::UnknownAfterAcceptance, "injected receipt byte count overflow"))?,
            3 => receipt.publication_ref = "invalid-publication-reference".to_string(),
            _ => {},
        }
        Ok(receipt)
    }
}

pub fn run(host: &Host, factory: &ExtensionHostFactory, dir: &Path) -> Result<()> {
    let original = host.executor().observations().iter().find(|observation|
        observation.envelope.invocation.callback == extension::CallbackKind::Request && observation.is_committed)
        .ok_or("admitted request observation missing")?;
    let invocation = &original.envelope.invocation;
    let effects = factory.recordings.borrow().iter().find(|(sequence, _)| *sequence == invocation.sequence)
        .ok_or("admitted host recording missing")?.1.snapshot().map_err(denial)?.effects;
    let grant = factory.authority.grant(invocation.generation, invocation.incarnation)?;
    let scope = factory.authority.scope.clone();
    let values = host.executor().values();
    // A fresh host-owned lifecycle grant must replace installation grants. A
    // guest using the old grant in a new incarnation must stop before Session.
    let mut refreshed = invocation.clone();
    refreshed.incarnation = refreshed.incarnation.checked_add(1).ok_or("incarnation overflow")?;
    let old_request = component::decode_host_request(&original.envelope.inputs.payload.as_ref().ok_or("request payload missing")?.bytes).map_err(denial)?;
    let stale_bytes = component::encode_host_request(component::HostRequestInput {
        generation: refreshed.generation, incarnation: refreshed.incarnation, sequence: 0, grant: &grant,
        effect: &old_request.effect().value, payload: old_request.payload(),
    }).map_err(denial)?;
    let stale_payload = publish(values, stale_bytes)?;
    refreshed.payload_ref = Some(stale_payload.value_ref);
    let stale_factory = ExtensionHostFactory {
        authority: factory.authority.clone(), values: values.clone(), deny: Rc::new(Cell::new(false)),
        recordings: Rc::new(RefCell::new(Vec::new())),
    };
    let mut stale = extension::Executor::new(copy_installation(host.executor().installation()), values.clone(), stale_factory.clone()).map_err(denial)?;
    check(stale.invoke(&refreshed).is_err(), "stale guest grant was admitted against refreshed host grant")?;
    check(stale_factory.recordings.borrow().iter().all(|(_, recording)| recording.snapshot().is_ok_and(|recorded| recorded.effects.is_empty())), "stale grant reached host effects")?;
    check(stale.observations().last().is_some_and(|observed| !observed.execution.is_pass() && !observed.is_committed && observed.publications.is_empty()), "stale grant produced admitted execution or publication")?;

    for trailing in [false, true] {
        let mut selected = effects.clone();
        if trailing { selected.extend(effects.clone()); }
        let replay_factory = |_: &extension::CallbackContext, actual: &extension::CallbackInvocation| {
            let (replay, _) = Replay::new(scope.clone(), actual.generation, actual.incarnation, selected.clone())?;
            Ok(extension::Binding::replay(replay, grant.clone()))
        };
        let mut replay = extension::Executor::new(copy_installation(host.executor().installation()), values.clone(), replay_factory).map_err(denial)?;
        let result = replay.invoke(invocation);
        let observed = replay.observations().last().ok_or("replay observation missing")?.clone();
        check(result.is_ok() != trailing && observed.execution.is_pass() != trailing, "extension replay completion admitted trailing effects or denied exact replay")?;
        if trailing {
            check(observed.execution.receipts.iter().map(|receipt| receipt.input.stage).collect::<Vec<_>>() == vec![component::Stage::Inspection, component::Stage::Instantiation, component::Stage::Execution, component::Stage::Denial], "trailing extension replay replaced observed executed stages")?;
            component::validate_chain(&observed.execution.receipts).map_err(denial)?;
            check(observed.execution.output.is_none() && observed.execution.receipts[2].input.fuel_remaining == observed.execution.receipts[3].input.fuel_remaining, "trailing replay lost observed fuel or retained output")?;
            check(observed.materialized_outcome.is_none() && observed.publications.is_empty() && !observed.is_committed, "trailing replay created a pending/publication outcome")?;
            check(replay.commit_admitted_outcome(invocation, &original.materialized_outcome.as_ref().ok_or("materialized original missing")?.project()).is_err(), "trailing replay became committable")?;
        }
        for (index, receipt) in observed.execution.receipts.iter().enumerate() {
            save(dir, &format!("extension-replay-trailing-{trailing}-receipt-{index}.preserves"), &component::value(receipt))?;
        }
    }
    publication_boundaries(host, factory, original, &effects, dir)?;
    live_host_publications::run(host, factory, original, dir)?;
    Ok(())
}

fn publication_boundaries(
    host: &Host,
    factory: &ExtensionHostFactory,
    original: &extension::HostedObservation,
    effects: &[component::consumer::host::RecordedEffect],
    dir: &Path,
) -> Result<()> {
    let invocation = &original.envelope.invocation;
    let values = host.executor().values();
    let scope = factory.authority.scope.clone();
    for mode in 1..=4 {
        let flag = Arc::new(std::sync::atomic::AtomicU8::new(0));
        let port = extension::shared_callback_value_port(PublicationBoundaryPort { inner: values.clone(), mode: flag.clone() });
        let replay_factory = |_: &extension::CallbackContext, actual: &extension::CallbackInvocation| {
            let selected = if actual.callback == extension::CallbackKind::Request { effects.to_vec() } else { Vec::new() };
            let current_grant = factory.authority.grant(actual.generation, actual.incarnation)
                .map_err(|error| component::Denial::new(error.to_string()))?;
            let (replay, _) = Replay::new(scope.clone(), actual.generation, actual.incarnation, selected)?;
            Ok(extension::Binding::replay(replay, current_grant))
        };
        let executor = extension::Executor::new(copy_installation(host.executor().installation()), port, replay_factory).map_err(denial)?;
        let mut dispatcher = extension::Dispatcher::new(host.manifest().clone(), executor)?;
        dispatcher.activate(10)?;
        let initial_state = dispatcher.semantic_state_ref().map(str::to_owned);
        check(dispatcher.executor().state_ref() == initial_state.as_deref(), "activation state references disagree")?;
        flag.store(mode, std::sync::atomic::Ordering::SeqCst);
        let payload = original.envelope.inputs.payload.as_ref().ok_or("original request payload missing")?;
        let result = dispatcher.dispatch_request(&payload.value_ref, payload.bytes.len() as u64, invocation.logical_tick)?;
        check(matches!(result, extension::DispatchResult::Failed { .. }), "publication failure unexpectedly committed")?;
        let observed = dispatcher.executor().observations().last().ok_or("publication observation missing")?.clone();
        check(observed.execution.is_pass() && !observed.is_committed && observed.publications.len() == 1, "publication boundary was not retained")?;
        let attempt = &observed.publications[0];
        check(attempt.value_ref == original.materialized_outcome.as_ref().ok_or("original outcome missing")?.outputs[0].value_ref, "attempted publication value was lost")?;
        check(attempt.failure.as_ref().ok_or("structured publication failure missing")?.may_have_published() == (mode != 4), "publication certainty was lost")?;
        check(attempt.receipt.is_some() == (mode == 2 || mode == 3), "invalid accepted receipt was discarded")?;
        check(dispatcher.semantic_state_ref() == initial_state.as_deref() && dispatcher.executor().state_ref() == initial_state.as_deref(), "failed publication adopted semantic state")?;
        if mode != 4 {
            check(dispatcher.state().phase == extension::LifecyclePhase::Quarantined, "unresolved accepted publication was classified retryable")?;
            let before = dispatcher.executor().observations().len();
            let mut later = invocation.clone();
            later.sequence += 1;
            later.incarnation += 1;
            check(dispatcher.executor_mut().invoke(&later).is_err(), "new incarnation bypassed unresolved publication fence")?;
            check(dispatcher.executor().observations().len() == before, "fenced invocation reached guest execution")?;
            check(dispatcher.restart(50).is_err(), "unknown publication permitted restart")?;
        } else {
            check(dispatcher.state().phase == extension::LifecyclePhase::Failed, "definite rejection was incorrectly quarantined as uncertain")?;
        }
        save(dir, &format!("extension-publication-failure-{mode}.preserves"), &rail::record("extension-publication-failure-observation-v1", vec![
            rail::u64_value(u64::from(mode)), rail::string(&attempt.value_ref), rail::string(dispatcher.state().phase.as_str()),
            rail::string(if mode == 4 { "rejected-before-acceptance" } else { "unknown-after-acceptance" }),
        ]))?;
    }
    Ok(())
}
