import { createEnvironment } from "./environment";
import {
  createFingerprintTable,
  insertSharedFingerprint,
  isSharedFingerprintsFull,
  writeStateFingerprint,
} from "./fingerprints";
import type { CoordinatorMessage, StartMessage, WorkerMessage } from "./parallel";
import { createSearch } from "./search";
import { getSuccessors, type Successor } from "./successors";
import { setFingerprintPolynomial } from "./tlc/fingerprint";
import { createTlcOrder } from "./tlc/order";
import { OUT_DEGREE_BUCKETS } from "./tlc/summary";
import { createStateDecoder, createStateEncoder, type EncodedStates } from "./transfer";
import {
  createCanonicalizer,
  freezeStringOrder,
  getUnorderedString,
  setStringOrder,
  setValueOptions,
  type Value,
} from "./values";
import { createBreak, getParentPort, type Port } from "./worker";

const LOCKED = -1;
const BREAK_INTERVAL = 100;

interface Expansion {
  states: Value[][];
  origin: number;
  end: number;
  successors: Successor[] | undefined;
  index: number;
  added: number;
  generated: number;
  outDegrees: number[];
  next: Value[][];
  fingerprintStates: Value[][];
  breakAt: number;
}

const runWorker = (start: StartMessage, parent: Port) => {
  const modules = new Map(start.modules);
  const loadModule = (name: string) => modules.get(name);
  const classes = new Map(start.classes);
  const order = createTlcOrder(start.source, loadModule);
  setStringOrder(order.getStringOrder(start.config));
  setValueOptions(start);
  setFingerprintPolynomial(start.fingerprintPolynomial ?? 0);
  freezeStringOrder();
  const specification = createEnvironment(start.config, {
    source: start.source,
    loadModule,
    order,
    loadClass: (name) => classes.get(name),
    print: () => {},
    files: { readFile: undefined, writeFile: undefined, makeDirectory: undefined },
    isTool: start.isTool,
    traceFile: start.traceFile,
    isWarningEnabled: start.isWarningEnabled,
    version: start.version,
  });
  const environment = specification.environment;
  const search = createSearch(start.config, environment, specification.variableLocations, () =>
    order.getDeclarationOrder("variable"),
  );
  const nextAction = search?.spec.next;
  if (!search || nextAction === undefined)
    return parent.postMessage({ type: "abort" } satisfies WorkerMessage);
  const workerIndex = start.index;
  const canonicalize = createCanonicalizer();
  const decode = createStateDecoder(environment.variables.length);
  let sharedFingerprints = start.fingerprints;
  const requests = start.requests;
  const remaining = start.remaining;
  const generatedStates = search.isSymmetric ? createFingerprintTable() : undefined;
  const fingerprint = new Int32Array(2);
  let resumeLevel = () => {};
  let receiveLoot = (_states: EncodedStates) => {};
  start.ports.forEach((port) => {
    port?.addEventListener("message", (event) => receiveLoot(event.data as EncodedStates));
    port?.start?.();
  });
  let frontier = decode(start.seed).map(canonicalize);
  const takeBreak = createBreak();

  const answerRequest = (expansion: Expansion, request: number) => {
    const thief = Atomics.load(requests, workerIndex) - 1;
    const given = Math.floor((expansion.end - expansion.origin - 1) / 2);
    const encoder = createStateEncoder();
    const states = expansion.states.slice(expansion.end - given, expansion.end);
    const isEncoded = given > 0 && states.every(encoder.encode);
    if (isEncoded) expansion.end -= given;
    const loot = isEncoded ? encoder.finish() : createStateEncoder().finish();
    start.ports[thief]?.postMessage(loot, [loot.words.buffer]);
    Atomics.store(requests, workerIndex, request);
    Atomics.notify(requests, workerIndex);
  };

  const lockRequests = (expansion: Expansion) => {
    Atomics.store(remaining, workerIndex, 0);
    if (Atomics.compareExchange(requests, workerIndex, 0, LOCKED) === 0) return;
    answerRequest(expansion, LOCKED);
  };

  const unlockRequests = (expansion: Expansion) => {
    Atomics.store(remaining, workerIndex, expansion.end - expansion.origin);
    Atomics.store(requests, workerIndex, 0);
  };

  const expand = (expansion: Expansion) => {
    for (; expansion.origin < expansion.end; expansion.origin++) {
      const state = expansion.states[expansion.origin];
      if (!expansion.successors) {
        if (performance.now() >= expansion.breakAt) return "break";
        if (Atomics.load(requests, workerIndex) > 0) answerRequest(expansion, 0);
        Atomics.store(remaining, workerIndex, expansion.end - expansion.origin - 1);
        expansion.successors = getSuccessors(nextAction, state, environment, search.spec.scope);
        expansion.generated += expansion.successors.length;
        if (expansion.successors.length === 0 && start.config.checkDeadlock) return undefined;
      }
      const successors = expansion.successors;
      for (; expansion.index < successors.length; expansion.index++) {
        if (isSharedFingerprintsFull(sharedFingerprints)) return "paused";
        const successor = successors[expansion.index];
        if (search.findViolatedActionProperty(state, successor.state)) return undefined;
        if (!search.satisfiesActionConstraints(state, successor.state)) {
          // TLC checks the invariants of every successor it has not seen, even outside the model.
          if (search.findViolatedInvariant(successor.state, state)) return undefined;
          continue;
        }
        if (generatedStates) {
          writeStateFingerprint(successor.state, fingerprint);
          if (!generatedStates.insert(fingerprint[0], fingerprint[1])) continue;
        }
        canonicalize(successor.state);
        const fingerprintState = search.getFingerprintState(successor.state);
        writeStateFingerprint(fingerprintState, fingerprint);
        if (!insertSharedFingerprint(sharedFingerprints, fingerprint[0], fingerprint[1])) continue;
        if (search.findViolatedInvariant(successor.state, state)) return undefined;
        if (!search.satisfiesConstraints(successor.state, state)) continue;
        expansion.next.push(successor.state);
        expansion.fingerprintStates.push(fingerprintState);
        expansion.added++;
      }
      expansion.outDegrees[Math.min(expansion.added, OUT_DEGREE_BUCKETS - 1)]++;
      expansion.successors = undefined;
      expansion.index = 0;
      expansion.added = 0;
    }
    return "done";
  };

  const steal = async (expansion: Expansion) => {
    const skipped = new Set<number>();
    for (;;) {
      const victim = start.ports.reduce<number | undefined>((best, port, index) => {
        if (!port || skipped.has(index) || Atomics.load(remaining, index) < 2) return best;
        return best === undefined || Atomics.load(remaining, index) > Atomics.load(remaining, best)
          ? index
          : best;
      }, undefined);
      if (victim === undefined) return false;
      const request = Atomics.compareExchange(requests, victim, 0, workerIndex + 1);
      if (request === LOCKED) skipped.add(victim);
      if (request > 0) Atomics.wait(requests, victim, request);
      if (request !== 0) continue;
      const loot = await new Promise<EncodedStates>((resolve) => (receiveLoot = resolve));
      if (loot.count === 0) {
        skipped.add(victim);
        continue;
      }
      expansion.states = decode(loot).map(canonicalize);
      expansion.origin = 0;
      expansion.end = expansion.states.length;
      unlockRequests(expansion);
      return true;
    }
  };

  const report = (message: WorkerMessage) =>
    parent.postMessage(message, message.type === "level" ? [message.fingerprints.buffer] : []);

  const runLevel = async (): Promise<WorkerMessage | undefined> => {
    const expansion: Expansion = {
      states: frontier,
      origin: 0,
      end: frontier.length,
      successors: undefined,
      index: 0,
      added: 0,
      generated: 0,
      outDegrees: Array.from({ length: OUT_DEGREE_BUCKETS }, () => 0),
      next: [],
      fingerprintStates: [],
      breakAt: performance.now() + BREAK_INTERVAL,
    };
    for (;;) {
      const status = expand(expansion);
      if (status === undefined) return undefined;
      // HACK: Bun frees memory on event loop timers, so a long level returns to the loop.
      if (status === "break") {
        await takeBreak();
        expansion.breakAt = performance.now() + BREAK_INTERVAL;
        continue;
      }
      lockRequests(expansion);
      if (status === "paused") {
        const resumed = new Promise<void>((resolve) => (resumeLevel = resolve));
        report({ type: "paused" });
        await resumed;
        unlockRequests(expansion);
        continue;
      }
      if (!(await steal(expansion))) break;
    }
    const unorderedString = getUnorderedString();
    if (unorderedString !== undefined) return { type: "abort", string: unorderedString };
    frontier = expansion.next;
    Atomics.store(remaining, workerIndex, frontier.length);
    return {
      type: "level",
      generated: expansion.generated,
      added: expansion.next.length,
      outDegrees: expansion.outDegrees,
      fingerprints: search.getStoredFingerprints(expansion.next, expansion.fingerprintStates),
    };
  };

  const startLevel = () => {
    runLevel().then(
      (message) => report(message ?? { type: "abort" }),
      () => report({ type: "abort" }),
    );
  };
  parent.addEventListener("message", (event) => {
    const message = event.data as CoordinatorMessage;
    if (message.type === "level") startLevel();
    if (message.type === "resize") {
      sharedFingerprints = message.fingerprints;
      resumeLevel();
    }
  });
  Atomics.store(remaining, workerIndex, frontier.length);
  report({ type: "ready" });
};

void getParentPort().then((parent) => {
  const onStart = (event: { data: unknown }) => {
    const message = event.data as StartMessage;
    if (message.type !== "start") return;
    parent.removeEventListener?.("message", onStart);
    try {
      runWorker(message, parent);
    } catch {
      parent.postMessage({ type: "abort" } satisfies WorkerMessage);
    }
  };
  parent.addEventListener("message", onStart);
  parent.start?.();
});
