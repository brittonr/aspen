// A port of OCaml's Format module, which tlapm uses to lay out obligations.

type BoxKind = "h" | "v" | "hv" | "hov" | "b" | "fits";

type Token =
  | { kind: "Text"; text: string }
  | { kind: "Break"; width: number; offset: number }
  | { kind: "Begin"; indent: number; box: BoxKind }
  | { kind: "End" }
  | { kind: "Newline" };

interface QueueElement {
  size: number;
  token: Token;
  length: number;
}

interface ScanElement {
  leftTotal: number;
  element: QueueElement;
}

interface FormatElement {
  box: BoxKind;
  width: number;
}

interface Formatter {
  queue: QueueElement[];
  queueStart: number;
  scanStack: ScanElement[];
  formatStack: FormatElement[];
  margin: number;
  maxIndent: number;
  spaceLeft: number;
  currentIndent: number;
  isNewLine: boolean;
  leftTotal: number;
  rightTotal: number;
  depth: number;
  output: string[];
}

const INFINITY = 1000000010;

const UNKNOWN = -1;

const ENCODER = new TextEncoder();

const getLength = (text: string) => {
  for (let index = 0; index < text.length; index++) {
    if (text.charCodeAt(index) > 0x7f) return ENCODER.encode(text).length;
  }
  return text.length;
};

const getSentinel = (): ScanElement => ({
  leftTotal: -1,
  element: { size: UNKNOWN, token: { kind: "Text", text: "" }, length: 0 },
});

const createFormatter = (maxIndent: number): Formatter => {
  const systemBox: QueueElement = {
    size: UNKNOWN,
    token: { kind: "Begin", indent: 0, box: "hov" },
    length: 0,
  };
  return {
    queue: [systemBox],
    queueStart: 0,
    scanStack: [getSentinel(), { leftTotal: 1, element: systemBox }],
    formatStack: [],
    margin: 78,
    maxIndent,
    spaceLeft: 78,
    currentIndent: 0,
    isNewLine: true,
    leftTotal: 1,
    rightTotal: 1,
    depth: 1,
    output: [],
  };
};

const enqueue = (formatter: Formatter, element: QueueElement) => {
  formatter.rightTotal += element.length;
  formatter.queue.push(element);
};

const breakNewLine = (formatter: Formatter, offset: number, width: number) => {
  formatter.output.push("\n");
  formatter.isNewLine = true;
  formatter.currentIndent = Math.min(formatter.maxIndent, formatter.margin - width + offset);
  formatter.spaceLeft = formatter.margin - formatter.currentIndent;
  formatter.output.push(" ".repeat(formatter.currentIndent));
};

const breakSameLine = (formatter: Formatter, width: number) => {
  formatter.spaceLeft -= width;
  formatter.output.push(" ".repeat(width));
};

const forceBreakLine = (formatter: Formatter) => {
  const top = formatter.formatStack.at(-1);
  if (!top) {
    formatter.output.push("\n");
    return;
  }
  if (top.width > formatter.spaceLeft && top.box !== "fits" && top.box !== "h") {
    breakNewLine(formatter, 0, top.width);
  }
};

const formatToken = (formatter: Formatter, size: number, token: Token) => {
  switch (token.kind) {
    case "Text":
      formatter.spaceLeft -= size;
      formatter.output.push(token.text);
      formatter.isNewLine = false;
      return;
    case "Begin": {
      if (formatter.margin - formatter.spaceLeft > formatter.maxIndent) forceBreakLine(formatter);
      const width = formatter.spaceLeft - token.indent;
      const box = token.box === "v" || size > formatter.spaceLeft ? token.box : "fits";
      formatter.formatStack.push({ box, width });
      return;
    }
    case "End":
      formatter.formatStack.pop();
      return;
    case "Newline": {
      const top = formatter.formatStack.at(-1);
      if (top) breakNewLine(formatter, 0, top.width);
      else formatter.output.push("\n");
      return;
    }
    case "Break": {
      const top = formatter.formatStack.at(-1);
      if (!top) return;
      const width = top.width;
      switch (top.box) {
        case "hov":
          if (size > formatter.spaceLeft) breakNewLine(formatter, token.offset, width);
          else breakSameLine(formatter, token.width);
          return;
        case "b":
          if (formatter.isNewLine) breakSameLine(formatter, token.width);
          else if (size > formatter.spaceLeft) breakNewLine(formatter, token.offset, width);
          else if (formatter.currentIndent > formatter.margin - width + token.offset) {
            breakNewLine(formatter, token.offset, width);
          } else breakSameLine(formatter, token.width);
          return;
        case "hv":
        case "v":
          breakNewLine(formatter, token.offset, width);
          return;
        case "fits":
        case "h":
          breakSameLine(formatter, token.width);
          return;
      }
    }
  }
};

const advanceLeft = (formatter: Formatter) => {
  while (formatter.queueStart < formatter.queue.length) {
    const element = formatter.queue[formatter.queueStart];
    const isKnown = element.size >= 0;
    if (!isKnown && formatter.rightTotal - formatter.leftTotal < formatter.spaceLeft) return;
    formatter.queueStart++;
    formatToken(formatter, isKnown ? element.size : INFINITY, element.token);
    formatter.leftTotal += element.length;
  }
  formatter.queue.length = 0;
  formatter.queueStart = 0;
};

const enqueueAdvance = (formatter: Formatter, element: QueueElement) => {
  enqueue(formatter, element);
  advanceLeft(formatter);
};

const setSize = (formatter: Formatter, isBreak: boolean) => {
  const top = formatter.scanStack.at(-1);
  if (!top) return;
  if (top.leftTotal < formatter.leftTotal) {
    formatter.scanStack = [getSentinel()];
    return;
  }
  if (top.element.token.kind === (isBreak ? "Break" : "Begin")) {
    top.element.size = formatter.rightTotal + top.element.size;
    formatter.scanStack.pop();
  }
};

const scanPush = (formatter: Formatter, isBreak: boolean, element: QueueElement) => {
  enqueue(formatter, element);
  if (isBreak) setSize(formatter, true);
  formatter.scanStack.push({ leftTotal: formatter.rightTotal, element });
};

const openBox = (formatter: Formatter, box: BoxKind, indent: number) => {
  formatter.depth++;
  scanPush(formatter, false, {
    size: -formatter.rightTotal,
    token: { kind: "Begin", indent, box },
    length: 0,
  });
};

const closeBox = (formatter: Formatter) => {
  if (formatter.depth <= 1) return;
  enqueue(formatter, { size: 0, token: { kind: "End" }, length: 0 });
  setSize(formatter, true);
  setSize(formatter, false);
  formatter.depth--;
};

const printAs = (formatter: Formatter, size: number, text: string) =>
  enqueueAdvance(formatter, { size, token: { kind: "Text", text }, length: size });

const printBreak = (formatter: Formatter, width: number, offset: number) =>
  scanPush(formatter, true, {
    size: -formatter.rightTotal,
    token: { kind: "Break", width, offset },
    length: width,
  });

const forceNewline = (formatter: Formatter) =>
  enqueueAdvance(formatter, { size: 0, token: { kind: "Newline" }, length: 0 });

const flush = (formatter: Formatter) => {
  while (formatter.depth > 1) closeBox(formatter);
  formatter.rightTotal = INFINITY;
  advanceLeft(formatter);
  return formatter.output.join("");
};

const flushNewline = (formatter: Formatter) => {
  flush(formatter);
  const output = [...formatter.output, "\n"];
  Object.assign(formatter, createFormatter(formatter.maxIndent));
  formatter.output = output;
};

type Command =
  | { kind: "Open"; box: BoxKind; indent: number }
  | { kind: "Close" }
  | { kind: "Text"; text: string; size: number }
  | { kind: "Break"; width: number; offset: number }
  | { kind: "Newline" }
  | { kind: "Flush" };

export type Doc = (Command | Doc)[];

const BOX_KINDS: Record<string, BoxKind> = { h: "h", v: "v", hv: "hv", hov: "hov", b: "b" };

const getText = (value: string): Command => ({ kind: "Text", text: value, size: getLength(value) });

export const text = (value: string): Doc => (value === "" ? [] : [getText(value)]);

const SPACE: Command = { kind: "Break", width: 1, offset: 0 };

const CUT: Command = { kind: "Break", width: 0, offset: 0 };

const parseOpen = (directive: string): Command => {
  const split = directive.search(/\d|$/);
  return {
    kind: "Open",
    box: BOX_KINDS[directive.slice(0, split)],
    indent: Number(directive.slice(split) || 0),
  };
};

export const format = (pattern: string, ...args: (string | Doc)[]): Doc => {
  const doc: Doc = [];
  let argumentIndex = 0;
  let pending = "";
  const flushText = () => {
    if (pending === "") return;
    doc.push(getText(pending));
    pending = "";
  };
  for (let index = 0; index < pattern.length; index++) {
    const character = pattern[index];
    if (character === "%") {
      flushText();
      const argument = args[argumentIndex++];
      if (typeof argument !== "string") doc.push(argument);
      else if (argument !== "") doc.push(getText(argument));
      index++;
      continue;
    }
    if (character !== "@") {
      pending += character;
      continue;
    }
    flushText();
    switch (pattern[index + 1]) {
      case "[": {
        if (pattern[index + 2] !== "<") {
          doc.push({ kind: "Open", box: "b", indent: 0 });
          index++;
          break;
        }
        const end = pattern.indexOf(">", index);
        doc.push(parseOpen(pattern.slice(index + 3, end)));
        index = end;
        break;
      }
      case "]":
        doc.push({ kind: "Close" });
        index++;
        break;
      case " ":
        doc.push(SPACE);
        index++;
        break;
      case ",":
        doc.push(CUT);
        index++;
        break;
      case "\n":
        doc.push({ kind: "Newline" });
        index++;
        break;
      case ".":
        doc.push({ kind: "Flush" });
        index++;
        break;
      case ";": {
        const end = pattern.indexOf(">", index);
        const values = pattern.slice(index + 3, end).split(" ");
        doc.push({ kind: "Break", width: Number(values[0]), offset: Number(values[1]) });
        index = end;
        break;
      }
      case "<": {
        const end = pattern.indexOf(">", index);
        doc.push({
          kind: "Text",
          text: String(args[argumentIndex++]),
          size: Number(pattern.slice(index + 2, end)),
        });
        index = end + 2;
        break;
      }
    }
  }
  flushText();
  return doc;
};

export const formatDelimited = <Item>(
  items: Item[],
  formatItem: (item: Item) => Doc,
  separator: Doc = [getText(","), SPACE],
): Doc =>
  items.flatMap((item, index) =>
    index === 0 ? [formatItem(item)] : [separator, formatItem(item)],
  );

const renderInto = (formatter: Formatter, doc: Doc) => {
  for (const entry of doc) {
    if (Array.isArray(entry)) {
      renderInto(formatter, entry);
      continue;
    }
    switch (entry.kind) {
      case "Open":
        openBox(formatter, entry.box, entry.indent);
        break;
      case "Close":
        closeBox(formatter);
        break;
      case "Text":
        printAs(formatter, entry.size, entry.text);
        break;
      case "Break":
        printBreak(formatter, entry.width, entry.offset);
        break;
      case "Newline":
        forceNewline(formatter);
        break;
      case "Flush":
        flushNewline(formatter);
        break;
    }
  }
};

export const renderDoc = (doc: Doc, maxIndent = 68) => {
  const formatter = createFormatter(maxIndent);
  renderInto(formatter, doc);
  return flush(formatter);
};
