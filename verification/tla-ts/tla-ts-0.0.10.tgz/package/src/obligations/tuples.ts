// A port of tlapm's E_tuply_declarations.

import type { Bound, BoundDomain, Defn, Expr } from "./expression";

export type TuplyBound =
  | { kind: "Name"; name: string; domain: BoundDomain }
  | { kind: "Tuple"; names: string[]; domain: Expr };

const getOpaque = (name: string): Expr => ({ kind: "Opaque", name });

const getNamesTuple = (names: string[]): Expr => ({
  kind: "Tuple",
  elements: names.map(getOpaque),
});

const getEquality = (left: Expr, right: Expr): Expr => ({
  kind: "Apply",
  operator: { kind: "Internal", builtin: "Eq" },
  args: [left, right],
});

export const getUnbounded = (names: string[]): Bound[] =>
  names.map((name) => ({ name, level: "Constant", domain: { kind: "NoDomain" } }));

const getFactors = (domain: Expr | undefined, names: string[]) =>
  domain?.kind === "Product" && domain.factors.length === names.length ? domain.factors : undefined;

const getItemDefinitions = (tuple: string, names: string[]): Defn[] =>
  names.map((name, index) => ({
    kind: "Operator",
    name,
    body: {
      kind: "FcnApp",
      function: getOpaque(tuple),
      args: [{ kind: "Num", integer: String(index + 1), fraction: "" }],
    },
  }));

const getFactorBounds = (names: string[], factors: Expr[]): Bound[] =>
  names.map((name, index) => ({
    name,
    level: "Constant",
    domain: { kind: "Domain", expression: factors[index] },
  }));

const getNamedBound = (bound: Extract<TuplyBound, { kind: "Name" }>): Bound => ({
  name: bound.name,
  level: "Constant",
  domain: bound.domain,
});

export const expandQuant = (
  quantifier: "Forall" | "Exists",
  bounds: TuplyBound[],
  body: Expr,
): Expr => {
  const groups: TuplyBound[][] = [];
  bounds.forEach((bound) => {
    if (bound.kind === "Name" && bound.domain.kind === "Ditto") groups.at(-1)?.push(bound);
    else groups.push([bound]);
  });
  return groups.reduceRight((inner: Expr, group): Expr => {
    const quantify = (quantified: Bound[], quantifiedBody = inner): Expr => ({
      kind: "Quant",
      quantifier,
      bounds: quantified,
      body: quantifiedBody,
      location: inner.location,
    });
    const first = group[0];
    if (first.kind === "Name") {
      return quantify(
        group.flatMap((bound) => (bound.kind === "Name" ? [getNamedBound(bound)] : [])),
      );
    }
    const factors = getFactors(first.domain, first.names);
    if (factors) return quantify(getFactorBounds(first.names, factors));
    const membership: Expr = {
      kind: "Apply",
      operator: { kind: "Internal", builtin: quantifier === "Exists" ? "Mem" : "Notmem" },
      args: [getNamesTuple(first.names), first.domain],
    };
    return quantify(getUnbounded(first.names), {
      kind: "List",
      bullet: quantifier === "Exists" ? "And" : "Or",
      items: [membership, inner],
    });
  }, body);
};

export const expandChoose = (
  binder: { kind: "Choose"; domain: Expr | undefined } | { kind: "SetSt"; domain: Expr },
  names: string[],
  body: Expr,
): Expr => {
  const name = `${binder.kind.toLowerCase()}#${names[0]}`;
  return {
    ...binder,
    name,
    body: getFactors(binder.domain, names)
      ? { kind: "Let", definitions: getItemDefinitions(name, names), body }
      : {
          kind: "Quant",
          quantifier: "Exists",
          bounds: getUnbounded(names),
          body: {
            kind: "List",
            bullet: "And",
            items: [getEquality(getOpaque(name), getNamesTuple(names)), body],
          },
        },
  };
};

const expandConstructorBounds = (bounds: TuplyBound[], value: Expr, isSetOf: boolean) => {
  const expanded = bounds.map((bound): { bounds: Bound[]; definitions: Defn[] } => {
    if (bound.kind === "Name") return { bounds: [getNamedBound(bound)], definitions: [] };
    const factors = getFactors(bound.domain, bound.names);
    if (factors && isSetOf) {
      return { bounds: getFactorBounds(bound.names, factors), definitions: [] };
    }
    const name = `fcn#${bound.names[0]}`;
    const fcnBound: Bound = {
      name,
      level: "Constant",
      domain: { kind: "Domain", expression: bound.domain },
    };
    if (factors) return { bounds: [fcnBound], definitions: getItemDefinitions(name, bound.names) };
    const choice = `choose#${name}`;
    return {
      bounds: [fcnBound],
      definitions: [
        {
          kind: "Operator",
          name: choice,
          body: expandChoose(
            { kind: "Choose", domain: undefined },
            bound.names,
            getEquality(getOpaque(name), getNamesTuple(bound.names)),
          ),
        },
        ...getItemDefinitions(choice, bound.names),
      ],
    };
  });
  const definitions = expanded.flatMap((item) => item.definitions);
  return {
    bounds: expanded.flatMap((item) => item.bounds),
    value:
      definitions.length === 0 ? value : ({ kind: "Let", definitions, body: value } satisfies Expr),
  };
};

export const expandSetOf = (element: Expr, bounds: TuplyBound[]): Expr => {
  const expanded = expandConstructorBounds(bounds, element, true);
  return { kind: "SetOf", element: expanded.value, bounds: expanded.bounds };
};

export const expandFcn = (bounds: TuplyBound[], body: Expr): Expr => {
  const expanded = expandConstructorBounds(bounds, body, false);
  return { kind: "Fcn", bounds: expanded.bounds, body: expanded.value };
};
