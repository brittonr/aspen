// Ported from Z3 (src/ast/ast_lt.cpp, src/util/symbol.cpp), MIT license, see z3-license.txt.
import {
  FAMILY_MODEL_VALUE,
  FAMILY_USER,
  KIND_APP,
  KIND_QUANTIFIER,
  KIND_VAR,
  OP_ITE,
  OP_NUM,
  OP_PATTERN,
  SORT_INT,
  type AstManager,
  type SmtSymbol,
} from "./ast";
import { Rational } from "./rational";

interface DeclKey {
  name: SmtSymbol;
  parameters: (number | Rational)[];
  domain: number[];
  range: number;
}

const PARAM_INT = 0;
const PARAM_RATIONAL = 3;

const compareValues = (first: number, second: number) =>
  first === second ? 0 : first < second ? -1 : 1;

const compareParameters = (first: number | Rational, second: number | Rational) =>
  first instanceof Rational && second instanceof Rational
    ? first.compare(second)
    : typeof first === "number" && typeof second === "number"
      ? compareValues(first, second)
      : 0;

const compareNames = (first: SmtSymbol, second: SmtSymbol) => {
  if (first === second) return 0;
  if (typeof first === "number")
    return typeof second === "number" ? compareValues(first, second) : -1;
  if (typeof second === "number") return 1;
  return first < second ? -1 : 1;
};

const getDeclKey = (manager: AstManager, expr: number): DeclKey => {
  const decl = manager.funcDecls[manager.decls[expr]];
  const range = manager.sorts[expr];
  if (decl.family === FAMILY_USER)
    return { name: decl.name, parameters: [], domain: decl.domain, range };
  if (decl.op === OP_NUM) {
    const isInt = range === SORT_INT;
    return {
      name: isInt ? "Int" : "Real",
      parameters: [PARAM_RATIONAL, manager.getRationalValue(expr), PARAM_INT, isInt ? 1 : 0],
      domain: [],
      range,
    };
  }
  if (decl.family === FAMILY_MODEL_VALUE)
    return { name: decl.name, parameters: [PARAM_INT, manager.values[expr]], domain: [], range };
  const builtin = manager.getBuiltinSignature(decl.op, manager.getArgs(expr));
  return { name: builtin.name, parameters: [], domain: builtin.domain, range };
};

const compareSorts = (manager: AstManager, first: number, second: number) =>
  first === second ? 0 : compareNames(manager.sortNames[first], manager.sortNames[second]);

const isSameDeclKey = (manager: AstManager, first: number, second: number) => {
  const decl = manager.funcDecls[manager.decls[first]];
  if (decl.family === FAMILY_USER) return true;
  if (decl.op === OP_NUM || decl.op === OP_PATTERN || decl.family === FAMILY_MODEL_VALUE)
    return false;
  const index = decl.op === OP_ITE ? 1 : 0;
  return (
    manager.sorts[first] === manager.sorts[second] &&
    manager.sorts[manager.getArg(first, index)] === manager.sorts[manager.getArg(second, index)]
  );
};

const compareDecls = (manager: AstManager, first: number, second: number) => {
  if (manager.decls[first] === manager.decls[second] && isSameDeclKey(manager, first, second))
    return 0;
  const firstKey = getDeclKey(manager, first);
  const secondKey = getDeclKey(manager, second);
  const byName = compareNames(firstKey.name, secondKey.name);
  if (byName !== 0) return byName;
  const byArity = compareValues(firstKey.domain.length, secondKey.domain.length);
  if (byArity !== 0) return byArity;
  const byParameterCount = compareValues(firstKey.parameters.length, secondKey.parameters.length);
  if (byParameterCount !== 0) return byParameterCount;
  for (let index = 0; index < firstKey.parameters.length; index++) {
    const byParameter = compareParameters(firstKey.parameters[index], secondKey.parameters[index]);
    if (byParameter !== 0) return byParameter;
  }
  for (let index = 0; index < firstKey.domain.length; index++) {
    const byDomain = compareSorts(manager, firstKey.domain[index], secondKey.domain[index]);
    if (byDomain !== 0) return byDomain;
  }
  return compareSorts(manager, firstKey.range, secondKey.range);
};

const compareAsts = (manager: AstManager, first: number, second: number): number => {
  if (first === second) return 0;
  const byKind = compareValues(manager.kinds[first], manager.kinds[second]);
  if (byKind !== 0) return byKind;
  if (manager.kinds[first] === KIND_VAR) {
    const byIndex = compareValues(manager.values[first], manager.values[second]);
    return byIndex !== 0
      ? byIndex
      : compareSorts(manager, manager.sorts[first], manager.sorts[second]);
  }
  if (manager.kinds[first] === KIND_QUANTIFIER) {
    const firstData = manager.getQuantifier(first);
    const secondData = manager.getQuantifier(second);
    const byHeader =
      compareValues(firstData.isForall ? 0 : 1, secondData.isForall ? 0 : 1) ||
      compareValues(firstData.sorts.length, secondData.sorts.length) ||
      compareValues(firstData.patterns.length, secondData.patterns.length) ||
      compareValues(firstData.weight, secondData.weight);
    if (byHeader !== 0) return byHeader;
    for (let index = 0; index < firstData.sorts.length; index++) {
      const byDecl =
        compareNames(firstData.names[index], secondData.names[index]) ||
        compareSorts(manager, firstData.sorts[index], secondData.sorts[index]);
      if (byDecl !== 0) return byDecl;
    }
    for (let index = 0; index < firstData.patterns.length; index++) {
      const byPattern = compareAsts(manager, firstData.patterns[index], secondData.patterns[index]);
      if (byPattern !== 0) return byPattern;
    }
    return compareAsts(manager, firstData.body, secondData.body);
  }
  if (manager.kinds[first] !== KIND_APP) return 0;
  const byHeader =
    compareValues(manager.getNumArgs(first), manager.getNumArgs(second)) ||
    compareValues(manager.depths[first], manager.depths[second]) ||
    compareDecls(manager, first, second);
  if (byHeader !== 0) return byHeader;
  for (let index = 0; index < manager.getNumArgs(first); index++) {
    const byArg = compareAsts(manager, manager.getArg(first, index), manager.getArg(second, index));
    if (byArg !== 0) return byArg;
  }
  return 0;
};

export const isAstLess = (manager: AstManager, first: number, second: number) =>
  compareAsts(manager, first, second) < 0;
