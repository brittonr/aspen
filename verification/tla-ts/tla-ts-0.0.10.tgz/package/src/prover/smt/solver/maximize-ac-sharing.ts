// Ported from Z3 (src/ast/rewriter/maximize_ac_sharing.cpp), MIT license, see z3-license.txt.
import { OP_ADD, OP_OR } from "./ast";
import { RewriterTpl } from "./rewriter-tpl";
import { shrink } from "./array";

interface SharingEntry {
  decl: number;
  first: number;
  second: number;
}

const MAX_NUM_ARGS_FOR_OPT = 128;

export class MaxBvSharing extends RewriterTpl {
  // Z3 compares the kind without the family, and bvmul has the kind of or and of +, so those are shared.
  private isInit = false;
  private entries: SharingEntry[] = [];
  private pairCache = new Map<number, Map<number, Set<number>>>();
  private pairScopes: number[] = [];

  reduceApp(decl: number, args: number[], sort: number) {
    const manager = this.manager;
    const op = manager.funcDecls[decl].op;
    if (!this.isInit || (op !== OP_OR && op !== OP_ADD) || args.length <= 2) return -1;
    return manager.withTemporaries(() => {
      const pending = [...args];
      for (let merged = 0; pending.length > 1 && pending.length < MAX_NUM_ARGS_FOR_OPT;) {
        let pairFirst = -1;
        let pairSecond = -1;
        for (let first = 0; first < merged && pairFirst === -1; first++)
          if (this.hasPair(decl, pending[first], pending[merged])) {
            pairFirst = first;
            pairSecond = merged;
          }
        for (let first = merged; first + 1 < pending.length && pairFirst === -1; first++)
          for (let second = first + 1; second < pending.length && pairFirst === -1; second++)
            if (this.hasPair(decl, pending[first], pending[second])) {
              pairFirst = first;
              pairSecond = second;
            }
        if (pairFirst === -1) break;
        pending[pairFirst] = manager.mkApp(decl, [pending[pairFirst], pending[pairSecond]], sort);
        pending.splice(pairSecond, 1);
        merged = pairFirst;
      }
      while (pending.length > 1) {
        const next: number[] = [];
        for (let index = 0; index < pending.length; index += 2) {
          if (index === pending.length - 1) {
            next.push(pending[index]);
            continue;
          }
          this.insert(decl, pending[index], pending[index + 1]);
          next.push(manager.mkApp(decl, [pending[index], pending[index + 1]], sort));
        }
        pending.splice(0, pending.length, ...next);
      }
      return pending[0];
    });
  }

  private insert(decl: number, first: number, second: number) {
    const isOrdered = this.manager.ids[first] <= this.manager.ids[second];
    this.entries.push({
      decl,
      first: isOrdered ? first : second,
      second: isOrdered ? second : first,
    });
    const byDecl = this.pairCache.get(decl) ?? new Map<number, Set<number>>();
    this.pairCache.set(decl, byDecl);
    const low = Math.min(first, second);
    const highs = byDecl.get(low) ?? new Set<number>();
    byDecl.set(low, highs);
    highs.add(Math.max(first, second));
    this.manager.incRef(first);
    this.manager.incRef(second);
  }

  private hasPair(decl: number, first: number, second: number) {
    return (
      this.pairCache.get(decl)?.get(Math.min(first, second))?.has(Math.max(first, second)) === true
    );
  }

  pushScope() {
    this.isInit = true;
    this.pairScopes.push(this.entries.length);
  }

  popScope() {
    const size = this.pairScopes.pop() as number;
    for (let index = this.entries.length - 1; index >= size; index--) {
      const entry = this.entries[index];
      this.pairCache
        .get(entry.decl)
        ?.get(Math.min(entry.first, entry.second))
        ?.delete(Math.max(entry.first, entry.second));
      this.manager.decRef(entry.first);
      this.manager.decRef(entry.second);
    }
    shrink(this.entries, size);
  }
}
