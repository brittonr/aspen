// Ported from Z3 (src/tactic/core/propagate_values_tactic.cpp, src/ast/shared_occs.cpp), MIT license, see z3-license.txt.
import { KIND_APP, KIND_QUANTIFIER, OP_EQ, type AstManager } from "./ast";
import type { Goal } from "./goal";
import { Rewriter, TACTIC_REWRITER_OPTIONS } from "./rewriter";

const MAX_ROUNDS = 4;

const getSharedOccs = (manager: AstManager, forms: number[]) => {
  const visited = new Set<number>();
  const shared = new Set<number>();
  const todo = [...forms];
  for (let expr = todo.pop(); expr !== undefined; expr = todo.pop()) {
    if (visited.has(expr)) {
      shared.add(expr);
      continue;
    }
    visited.add(expr);
    if (manager.kinds[expr] === KIND_APP) manager.pushArgs(expr, todo);
    else if (manager.kinds[expr] === KIND_QUANTIFIER) todo.push(manager.getQuantifier(expr).body);
  }
  return shared;
};

export const propagateValues = (manager: AstManager, goal: Goal) => {
  if (goal.isInconsistent) return;
  const rewriter = new Rewriter(manager, TACTIC_REWRITER_OPTIONS);
  const substitution = new Map<number, number>();
  rewriter.setSubstitution(substitution);
  let occs = getSharedOccs(manager, goal.forms.items);
  let isModified = false;
  const process = (index: number) => {
    const current = goal.forms.items[index];
    const isRewriting = substitution.size !== 0;
    const rewritten = isRewriting ? rewriter.rewrite(current) : current;
    if (rewritten !== current) isModified = true;
    goal.update(index, rewritten);
    if (isRewriting) manager.decRef(rewritten);
    if (occs.has(rewritten)) substitution.set(rewritten, manager.trueExpr);
    if (manager.isNot(rewritten) && occs.has(manager.getArg(rewritten, 0)))
      substitution.set(manager.getArg(rewritten, 0), manager.falseExpr);
    if (manager.getOp(rewritten) !== OP_EQ) return;
    if (
      manager.isUniqueValue(manager.getArg(rewritten, 0)) &&
      occs.has(manager.getArg(rewritten, 1))
    )
      substitution.set(manager.getArg(rewritten, 1), manager.getArg(rewritten, 0));
    else if (
      manager.isUniqueValue(manager.getArg(rewritten, 1)) &&
      occs.has(manager.getArg(rewritten, 0))
    )
      substitution.set(manager.getArg(rewritten, 0), manager.getArg(rewritten, 1));
  };
  for (let round = 0; round < MAX_ROUNDS; round += 2) {
    const size = goal.forms.size;
    for (let index = 0; index < size; index++) {
      process(index);
      if (goal.isInconsistent) return;
    }
    if (substitution.size === 0 && !isModified) break;
    occs = getSharedOccs(manager, goal.forms.items);
    substitution.clear();
    rewriter.setSubstitution(substitution);
    for (let index = goal.forms.size - 1; index >= 0; index--) {
      process(index);
      if (goal.isInconsistent) return;
    }
    if (!isModified) break;
    substitution.clear();
    rewriter.setSubstitution(substitution);
    isModified = false;
    occs = getSharedOccs(manager, goal.forms.items);
  }
  goal.elimRedundancies();
};
