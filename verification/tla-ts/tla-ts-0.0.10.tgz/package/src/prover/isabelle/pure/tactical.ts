// Ported from Isabelle2025's Pure/tactical.ML and Pure/search.ML. Copyright (c) 1986-2025 University of Cambridge, Technische Universitaet Muenchen, and contributors, see LICENSE.

import { TlaIsabelleError } from "../../../errors";
import {
  appendSeq,
  emptySeq,
  filterSeq,
  deferSeq,
  makeSeq,
  mapsSeq,
  ofCell,
  singleSeq,
  type Cell,
  type Seq,
} from "./seq";
import { cons, type List } from "./list";
import { aconv, type Term } from "./term";
import { nprems, premOf, type Thm } from "./thm";

export type Tactic = (state: Thm) => Seq<Thm>;
export type GoalTactic = (index: number) => Tactic;

export const allTac: Tactic = (state) => singleSeq(state);
export const noTac: Tactic = () => emptySeq;

export const thenTac =
  (first: Tactic, second: Tactic): Tactic =>
  (state) =>
    mapsSeq(second, first(state));

export const orElse =
  (first: Tactic, second: Tactic): Tactic =>
  (state) => {
    const cell = first(state).pull();
    return cell === undefined ? second(state) : ofCell(cell);
  };

export const appendTac =
  (first: Tactic, second: Tactic): Tactic =>
  (state) =>
    appendSeq(
      first(state),
      deferSeq(() => second(state)),
    );

export const thenElse =
  (test: Tactic, onSuccess: Tactic, onFailure: Tactic): Tactic =>
  (state) => {
    const cell = test(state).pull();
    return cell === undefined ? onFailure(state) : mapsSeq(onSuccess, ofCell(cell));
  };

export const thenGoal =
  (first: GoalTactic, second: GoalTactic): GoalTactic =>
  (index) =>
    thenTac(first(index), second(index));

export const orElseGoal =
  (first: GoalTactic, second: GoalTactic): GoalTactic =>
  (index) =>
    orElse(first(index), second(index));

export const appendGoal =
  (first: GoalTactic, second: GoalTactic): GoalTactic =>
  (index) =>
    appendTac(first(index), second(index));

export const determ =
  (tactic: Tactic): Tactic =>
  (state) =>
    makeSeq(() => {
      const cell = tactic(state).pull();
      return cell === undefined ? undefined : [cell[0], emptySeq];
    });

export const tryTac = (tactic: Tactic) => orElse(tactic, allTac);

export const eqThm = (left: Thm, right: Thm) =>
  left === right ||
  (aconv(left.prop, right.prop) &&
    left.hyps.length === right.hyps.length &&
    left.hyps.every((hyp) => right.hyps.some((other) => aconv(hyp, other))) &&
    left.tpairs.length === right.tpairs.length &&
    left.tpairs.every(
      (pair, index) =>
        aconv(pair[0], right.tpairs[index][0]) && aconv(pair[1], right.tpairs[index][1]),
    ));

export const distinctThms = (thms: readonly Thm[]) =>
  thms.filter((thm, position) => thms.findIndex((other) => eqThm(other, thm)) === position);

export const eqThmProp = (left: Thm, right: Thm) => aconv(left.prop, right.prop);

interface Trail {
  readonly state: Thm;
  readonly rest: Seq<Thm>;
  readonly tactics: readonly Tactic[];
}

export const every = (tactics: readonly Tactic[]): Tactic => {
  const evy = (trail: readonly Trail[], remaining: readonly Tactic[], state: Thm): Seq<Thm> => {
    if (remaining.length === 0) return makeSeq(() => [state, makeSeq(() => evyBack(trail).pull())]);
    const cell = remaining[0](state).pull();
    if (cell === undefined) return evyBack(trail);
    return evy(
      [{ state: cell[0], rest: cell[1], tactics: remaining.slice(1) }, ...trail],
      remaining.slice(1),
      cell[0],
    );
  };
  const evyBack = (trail: readonly Trail[]): Seq<Thm> => {
    let current = trail;
    while (current.length > 0) {
      const top = current[0];
      const cell = top.rest.pull();
      if (cell === undefined) current = current.slice(1);
      else if (eqThm(top.state, cell[0]))
        current = [{ ...top, rest: cell[1] }, ...current.slice(1)];
      else
        return evy(
          [{ state: cell[0], rest: cell[1], tactics: top.tactics }, ...current.slice(1)],
          top.tactics,
          cell[0],
        );
    }
    return emptySeq;
  };
  return (state) => evy([], tactics, state);
};

export const first = (tactics: readonly Tactic[]): Tactic =>
  tactics.reduceRight((rest, tactic) => orElse(tactic, rest), noTac);

export const firstGoal =
  (tactics: readonly GoalTactic[]): GoalTactic =>
  (index) =>
    first(tactics.map((tactic) => tactic(index)));

export const repeatDetermN =
  (count: number, tactic: Tactic): Tactic =>
  (state) =>
    makeSeq(() => {
      let current = state;
      let remaining = count;
      while (remaining !== 0) {
        const cell = tactic(current).pull();
        if (cell === undefined) break;
        current = cell[0];
        remaining -= 1;
      }
      return [current, emptySeq];
    });

export const repeatDeterm = (tactic: Tactic) => repeatDetermN(-1, tactic);

export const repeatDeterm1 = (tactic: Tactic) => thenTac(determ(tactic), repeatDeterm(tactic));

export const changed =
  (tactic: Tactic): Tactic =>
  (state) =>
    filterSeq((result) => !eqThm(state, result), tactic(state));

export const changedProp =
  (tactic: Tactic): Tactic =>
  (state) =>
    filterSeq((result) => !eqThmProp(state, result), tactic(state));

export const allGoals =
  (tactic: GoalTactic): Tactic =>
  (state) => {
    const doall = (index: number): Tactic =>
      index === 0 ? allTac : thenTac(tactic(index), doall(index - 1));
    return doall(nprems(state))(state);
  };

export const firstGoalTac =
  (tactic: GoalTactic): Tactic =>
  (state) => {
    const count = nprems(state);
    const find = (index: number): Tactic =>
      index > count ? noTac : orElse(tactic(index), find(index + 1));
    return find(1)(state);
  };

const isThmError = (error: unknown) =>
  error instanceof TlaIsabelleError && error.exception === "THM";

export const subgoal =
  (build: (goal: Term, index: number) => Tactic): GoalTactic =>
  (index) =>
  (state) => {
    if (index < 1 || index > nprems(state)) return emptySeq;
    return build(premOf(state, index), index)(state);
  };

const interval = (tactic: GoalTactic, firstIndex: number, lastIndex: number): Tactic =>
  lastIndex < firstIndex
    ? allTac
    : thenTac(tactic(lastIndex), interval(tactic, firstIndex, lastIndex - 1));

export const thenAllNew =
  (first: GoalTactic, second: GoalTactic): GoalTactic =>
  (index) =>
  (state) =>
    thenTac(first(index), (result) =>
      interval(second, index, index + nprems(result) - nprems(state))(result),
    )(state);

export const repeatAllNew = (tactic: GoalTactic): GoalTactic =>
  thenAllNew(tactic, (index) => tryTac(repeatAllNew(tactic)(index)));

export const primSeq =
  (apply: (state: Thm) => Seq<Thm>): Tactic =>
  (state) => {
    try {
      return apply(state);
    } catch (error) {
      if (isThmError(error)) return emptySeq;
      throw error;
    }
  };

export const primitive = (apply: (state: Thm) => Thm): Tactic =>
  primSeq((state) => singleSeq(apply(state)));

export const condTac =
  (test: (state: Thm) => boolean, onTrue: Tactic, onFalse: Tactic): Tactic =>
  (state) =>
    test(state) ? onTrue(state) : onFalse(state);

const depthFirst = (test: (state: Thm) => boolean, tactic: Tactic): Tactic => {
  const isUsed = (used: List<Thm> | undefined, state: Thm) => {
    for (let current = used; current !== undefined; current = current.tail)
      if (eqThm(current.head, state)) return true;
    return false;
  };
  const depth = (used: List<Thm> | undefined, stack: List<Seq<Thm>> | undefined): Cell<Thm> => {
    let current = stack;
    while (current !== undefined) {
      const cell = current.head.pull();
      if (cell === undefined) {
        current = current.tail;
        continue;
      }
      const state = cell[0];
      const rest = cons(cell[1], current.tail);
      if (test(state) && !isUsed(used, state))
        return [state, makeSeq(() => depth(cons(state, used), rest))];
      current = cons(tactic(state), rest);
    }
    return undefined;
  };
  return (state) => makeSeq(() => depth(undefined, cons(singleSeq(state), undefined)));
};

export const hasFewerPrems = (count: number) => (state: Thm) => nprems(state) < count;

export const depthSolve = (tactic: Tactic) => depthFirst(hasFewerPrems(1), tactic);
