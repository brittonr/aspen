// Ported from Isabelle2025's Pure/term_ord.ML. Copyright (c) 1986-2025 University of Cambridge, Technische Universitaet Muenchen, and contributors, see LICENSE.

import { fastIndexnameOrd, fastStringOrd, indexnameOrd } from "./table";
import { dummyT, sizeOfTerm, type Term, type Typ } from "./term";

const intOrd = (left: number, right: number) => (left < right ? -1 : left > right ? 1 : 0);

const dictOrd = <Item>(
  ord: (left: Item, right: Item) => number,
  left: readonly Item[],
  right: readonly Item[],
) => {
  for (let index = 0; ; index += 1) {
    if (index === left.length) return index === right.length ? 0 : -1;
    if (index === right.length) return 1;
    const order = ord(left[index], right[index]);
    if (order !== 0) return order;
  }
};

const sortOrd = (left: readonly string[], right: readonly string[]) =>
  dictOrd(fastStringOrd, left, right);

const typConsNr = (type: Typ) => (type.kind === "TVar" ? 0 : type.kind === "TFree" ? 1 : 2);

const typOrd = (left: Typ, right: Typ): number => {
  if (left === right) return 0;
  if (left.kind === "Type" && right.kind === "Type") {
    const order = fastStringOrd(left.name, right.name);
    return order !== 0 ? order : dictOrd(typOrd, left.args, right.args);
  }
  if (left.kind === "TFree" && right.kind === "TFree") {
    const order = fastStringOrd(left.name, right.name);
    return order !== 0 ? order : sortOrd(left.sort, right.sort);
  }
  if (left.kind === "TVar" && right.kind === "TVar") {
    const order = fastIndexnameOrd(left, right);
    return order !== 0 ? order : sortOrd(left.sort, right.sort);
  }
  return intOrd(typConsNr(left), typConsNr(right));
};

const hdDepth = (term: Term): [Term, number] => {
  let current = term;
  let depth = 0;
  while (current.kind === "App") {
    current = current.fun;
    depth += 1;
  }
  return [current, depth];
};

const destHd = (term: Term): [{ name: string; index: number }, Typ, number] => {
  switch (term.kind) {
    case "Const":
      return [{ name: term.name, index: 0 }, term.type, 0];
    case "Free":
      return [{ name: term.name, index: 0 }, term.type, 1];
    case "Var":
      return [{ name: term.name, index: term.index }, term.type, 2];
    case "Bound":
      return [{ name: "", index: term.index }, dummyT, 3];
    case "Abs":
      return [{ name: "", index: 0 }, term.type, 4];
    case "App":
      return [{ name: "", index: 0 }, dummyT, 5];
  }
};

const hdOrd = (left: Term, right: Term) => {
  const [leftName, leftType, leftNr] = destHd(left);
  const [rightName, rightType, rightNr] = destHd(right);
  const name = indexnameOrd(leftName, rightName);
  if (name !== 0) return name;
  const type = typOrd(leftType, rightType);
  return type !== 0 ? type : intOrd(leftNr, rightNr);
};

const argsOrd = (left: Term, right: Term): number => {
  if (left.kind === "App" && right.kind === "App") {
    const order = argsOrd(left.fun, right.fun);
    return order !== 0 ? order : termOrd(left.arg, right.arg);
  }
  return 0;
};

export const termOrd = (left: Term, right: Term): number => {
  if (left === right) return 0;
  if (left.kind === "Abs" && right.kind === "Abs") {
    const order = termOrd(left.body, right.body);
    return order !== 0 ? order : typOrd(left.type, right.type);
  }
  const size = intOrd(sizeOfTerm(left), sizeOfTerm(right));
  if (size !== 0) return size;
  const [leftHead, leftDepth] = hdDepth(left);
  const [rightHead, rightDepth] = hdDepth(right);
  const head = hdOrd(leftHead, rightHead);
  if (head !== 0) return head;
  const depth = intOrd(leftDepth, rightDepth);
  return depth !== 0 ? depth : argsOrd(left, right);
};
