// Ported from Isabelle2025's Pure/thm.ML. Copyright (c) 1986-2025 University of Cambridge, Technische Universitaet Muenchen, and contributors, see LICENSE.

import { TlaIsabelleError } from "../../../errors";
import {
  betaNorm,
  emptyEnvir,
  etaContract,
  isEmptyEnvir,
  above,
  normTerm,
  type Envir,
} from "./envir";
import {
  allConst,
  assumProblems,
  countPrems,
  flattenParams,
  incrIndexes,
  liftAbs,
  liftAll,
  listAll,
  listImplies,
  mkEquals,
  mkImplies,
  occs,
  stripImpConcl,
  stripImpPrems,
  stripPrems,
  stripAssumsConcl,
  stripAssumsHyp,
} from "./logic";
import {
  emptySeq,
  flatSeq,
  itRightSeq,
  deferSeq,
  makeSeq,
  mappSeq,
  chopSeq,
  consSeq,
  mapSeq,
  type Seq,
} from "./seq";
import { substType, type TyEnv } from "./type";
import {
  abstractOver,
  aconv,
  betapply,
  couldUnify,
  eqTyp,
  existsSubterm,
  fastypeOf,
  maxidxOfTerm,
  mkAbs,
  mkApp,
  mkConst,
  mkFree,
  mkVar,
  propT,
  stripAllBody,
  stripAllVars,
  substBound,
  type Term,
  type Var,
} from "./term";
import type { Limits } from "./interrupt";
import { smashUnifiers, unifiers, type Tpair, type Unifier } from "./unify";
import { normTermSkip, renameBvars, stripApply, stripAssums2, unifyVarTypes } from "./bicompose";

declare const kernel: unique symbol;

export interface Thm {
  readonly maxidx: number;
  readonly hyps: readonly Term[];
  readonly tpairs: readonly Tpair[];
  readonly prop: Term;
  readonly [kernel]: true;
}

const makeThm = (
  maxidx: number,
  hyps: readonly Term[],
  tpairs: readonly Tpair[],
  prop: Term,
): Thm => ({ maxidx, hyps, tpairs, prop }) as Thm;

const unionHyps = (left: readonly Term[], right: readonly Term[]) =>
  right.length === 0
    ? left
    : left.length === 0
      ? right
      : [...left, ...right.filter((hyp) => !left.some((other) => aconv(hyp, other)))];

const unionTpairs = (left: readonly Tpair[], right: readonly Tpair[]) =>
  right.length === 0
    ? left
    : [
        ...left,
        ...right.filter(
          (pair) => !left.some((other) => aconv(pair[0], other[0]) && aconv(pair[1], other[1])),
        ),
      ];

const maxidxTpairs = (tpairs: readonly Tpair[], maxidx: number) =>
  tpairs.reduce((result, pair) => maxidxOfTerm(pair[1], maxidxOfTerm(pair[0], result)), maxidx);

export const axiomThm = (prop: Term): Thm => makeThm(maxidxOfTerm(prop), [], [], prop);

export const nprems = (thm: Thm) => countPrems(thm.prop);
export const premsOf = (thm: Thm) => stripImpPrems(thm.prop);
export const conclOf = (thm: Thm) => stripImpConcl(thm.prop);

export const majorPremOf = (thm: Thm) => {
  const premise = premsOf(thm)[0];
  if (premise === undefined)
    throw new TlaIsabelleError("THM", "major_prem_of: rule with no premises");
  return stripAssumsConcl(premise);
};

export const premOf = (thm: Thm, index: number) => {
  const premise = premsOf(thm)[index - 1];
  if (premise === undefined) throw new TlaIsabelleError("THM", `No subgoal ${index}`);
  return premise;
};

export const assume = (prop: Term): Thm => {
  if (!eqTyp(fastypeOf(prop), propT)) throw new TlaIsabelleError("THM", "assume: prop");
  if (maxidxOfTerm(prop) !== -1) throw new TlaIsabelleError("THM", "assume: variables");
  return makeThm(-1, [prop], [], prop);
};

export const impliesIntr = (premise: Term, thm: Thm): Thm => {
  if (!eqTyp(fastypeOf(premise), propT))
    throw new TlaIsabelleError("THM", "implies_intr: assumptions must have type prop");
  return makeThm(
    Math.max(maxidxOfTerm(premise), thm.maxidx),
    thm.hyps.filter((hyp) => !aconv(hyp, premise)),
    thm.tpairs,
    mkImplies(premise, thm.prop),
  );
};

export const impliesElim = (major: Thm, minor: Thm): Thm => {
  const prop = major.prop;
  if (
    prop.kind !== "App" ||
    prop.fun.kind !== "App" ||
    prop.fun.fun.kind !== "Const" ||
    prop.fun.fun.name !== "Pure.imp" ||
    !aconv(prop.fun.arg, minor.prop)
  )
    throw new TlaIsabelleError("THM", "implies_elim: major premise");
  return makeThm(
    Math.max(major.maxidx, minor.maxidx),
    unionHyps(minor.hyps, major.hyps),
    unionTpairs(minor.tpairs, major.tpairs),
    prop.arg,
  );
};

const occursIn = (variable: Term, terms: readonly Term[], tpairs: readonly Tpair[]) => {
  const occurs = (term: Term) => occs(variable, term);
  return terms.some(occurs) || tpairs.some((pair) => occurs(pair[0]) || occurs(pair[1]));
};

export const forallIntr = (variable: Term, thm: Thm): Thm => {
  if (variable.kind !== "Free" && variable.kind !== "Var")
    throw new TlaIsabelleError("THM", "forall_intr: not a variable");
  if (occursIn(variable, variable.kind === "Free" ? thm.hyps : [], thm.tpairs))
    throw new TlaIsabelleError(
      "THM",
      `forall_intr: variable "${variable.name}" free in assumptions`,
    );
  return makeThm(
    Math.max(maxidxOfTerm(variable), thm.maxidx),
    thm.hyps,
    thm.tpairs,
    mkApp(
      allConst(variable.type),
      mkAbs(variable.name, variable.type, abstractOver(variable, thm.prop)),
    ),
  );
};

export const forallElim = (term: Term, thm: Thm): Thm => {
  const prop = thm.prop;
  if (
    prop.kind !== "App" ||
    prop.fun.kind !== "Const" ||
    prop.fun.name !== "Pure.all" ||
    prop.fun.type.kind !== "Type" ||
    prop.fun.type.args[0].kind !== "Type"
  )
    throw new TlaIsabelleError("THM", "forall_elim: not quantified");
  if (!eqTyp(fastypeOf(term), prop.fun.type.args[0].args[0]))
    throw new TlaIsabelleError("THM", "forall_elim: type mismatch");
  return makeThm(
    Math.max(maxidxOfTerm(term), thm.maxidx),
    thm.hyps,
    thm.tpairs,
    betapply(prop.arg, term),
  );
};

export const reflexive = (term: Term) => makeThm(maxidxOfTerm(term), [], [], mkEquals(term, term));

const destEq = (thm: Thm): [Term, Term, Term] | undefined => {
  const prop = thm.prop;
  return prop.kind === "App" &&
    prop.fun.kind === "App" &&
    prop.fun.fun.kind === "Const" &&
    prop.fun.fun.name === "Pure.eq"
    ? [prop.fun.fun, prop.fun.arg, prop.arg]
    : undefined;
};

export const symmetric = (thm: Thm): Thm => {
  const parts = destEq(thm);
  if (parts === undefined) throw new TlaIsabelleError("THM", "symmetric");
  return makeThm(thm.maxidx, thm.hyps, thm.tpairs, mkApp(mkApp(parts[0], parts[2]), parts[1]));
};

export const transitive = (first: Thm, second: Thm): Thm => {
  const left = destEq(first);
  const right = destEq(second);
  if (left === undefined || right === undefined)
    throw new TlaIsabelleError("THM", "transitive: premises");
  if (!aconv(left[2], right[1])) throw new TlaIsabelleError("THM", "transitive: middle term");
  return makeThm(
    Math.max(first.maxidx, second.maxidx),
    unionHyps(first.hyps, second.hyps),
    unionTpairs(first.tpairs, second.tpairs),
    mkApp(mkApp(left[0], left[1]), right[2]),
  );
};

export const betaConversion = (isFull: boolean, term: Term): Thm => {
  if (!isFull && (term.kind !== "App" || term.fun.kind !== "Abs"))
    throw new TlaIsabelleError("THM", "beta_conversion: not a redex");
  const reduced =
    isFull || term.kind !== "App" || term.fun.kind !== "Abs"
      ? betaNorm(term)
      : substBound(term.arg, term.fun.body);
  return makeThm(maxidxOfTerm(term), [], [], mkEquals(term, reduced));
};

export const etaConversion = (term: Term) =>
  makeThm(maxidxOfTerm(term), [], [], mkEquals(term, etaContract(term)));

export const abstractRule = (name: string, variable: Term, thm: Thm): Thm => {
  const parts = destEq(thm);
  if (parts === undefined)
    throw new TlaIsabelleError("THM", "abstract_rule: premise not an equality");
  if (variable.kind !== "Free" && variable.kind !== "Var")
    throw new TlaIsabelleError("THM", "abstract_rule: not a variable");
  if (occursIn(variable, variable.kind === "Free" ? thm.hyps : [], thm.tpairs))
    throw new TlaIsabelleError(
      "THM",
      `abstract_rule: variable "${variable.name}" free in assumptions`,
    );
  return makeThm(
    thm.maxidx,
    thm.hyps,
    thm.tpairs,
    mkEquals(
      mkAbs(name, variable.type, abstractOver(variable, parts[1])),
      mkAbs(name, variable.type, abstractOver(variable, parts[2])),
    ),
  );
};

export const combination = (first: Thm, second: Thm): Thm => {
  const left = destEq(first);
  const right = destEq(second);
  if (left === undefined || right === undefined)
    throw new TlaIsabelleError("THM", "combination: premises");
  const funType = fastypeOf(left[1]);
  if (funType.kind !== "Type" || funType.name !== "fun")
    throw new TlaIsabelleError("THM", "combination: not function type");
  if (!eqTyp(funType.args[0], fastypeOf(right[1])))
    throw new TlaIsabelleError("THM", "combination: types");
  return makeThm(
    Math.max(first.maxidx, second.maxidx),
    unionHyps(first.hyps, second.hyps),
    unionTpairs(first.tpairs, second.tpairs),
    mkEquals(mkApp(left[1], right[1]), mkApp(left[2], right[2])),
  );
};

export const equalElim = (first: Thm, second: Thm): Thm => {
  const parts = destEq(first);
  if (parts === undefined) throw new TlaIsabelleError("THM", "equal_elim: major premise");
  if (!aconv(second.prop, parts[1])) throw new TlaIsabelleError("THM", "equal_elim: not equal");
  return makeThm(
    Math.max(first.maxidx, second.maxidx),
    unionHyps(first.hyps, second.hyps),
    unionTpairs(first.tpairs, second.tpairs),
    parts[2],
  );
};

export const flexflexRule = (limits: Limits | undefined, thm: Thm): Seq<Thm> =>
  mapSeq(
    (envir: Envir) => {
      if (isEmptyEnvir(envir)) return thm;
      const tpairs = thm.tpairs
        .map((pair): Tpair => [normTerm(envir, pair[0]), normTerm(envir, pair[1])])
        .filter((pair) => !aconv(pair[0], pair[1]));
      const prop = normTerm(envir, thm.prop);
      return makeThm(maxidxTpairs(tpairs, maxidxOfTerm(prop)), thm.hyps, tpairs, prop);
    },
    smashUnifiers(limits, thm.tpairs, emptyEnvir(thm.maxidx)),
  );

export const generalize = (frees: readonly string[], index: number, thm: Thm): Thm => {
  if (frees.length === 0) return thm;
  if (index <= thm.maxidx) throw new TlaIsabelleError("THM", "generalize: bad index");
  if (
    thm.hyps.some((hyp) =>
      existsSubterm((sub) => sub.kind === "Free" && frees.includes(sub.name), hyp),
    )
  )
    throw new TlaIsabelleError("THM", "generalize: variable free in assumptions");
  const generalizeTerm = (term: Term): Term => {
    switch (term.kind) {
      case "Free":
        return frees.includes(term.name) ? mkVar(term.name, index, term.type) : term;
      case "Abs":
        return mkAbs(term.name, term.type, generalizeTerm(term.body));
      case "App":
        return mkApp(generalizeTerm(term.fun), generalizeTerm(term.arg));
      default:
        return term;
    }
  };
  const prop = generalizeTerm(thm.prop);
  const tpairs = thm.tpairs.map((pair): Tpair => [
    generalizeTerm(pair[0]),
    generalizeTerm(pair[1]),
  ]);
  return makeThm(maxidxTpairs(tpairs, maxidxOfTerm(prop)), thm.hyps, tpairs, prop);
};

export interface Instantiation {
  readonly variable: Var;
  readonly term: Term;
}

const instantiateTerm = (insts: readonly Instantiation[], term: Term): Term => {
  const find = (variable: Var) =>
    insts.find(
      (inst) =>
        inst.variable.name === variable.name &&
        inst.variable.index === variable.index &&
        eqTyp(inst.variable.type, variable.type),
    )?.term;
  const subst = (current: Term): Term => {
    switch (current.kind) {
      case "Var":
        return find(current) ?? current;
      case "Abs": {
        const body = subst(current.body);
        return body === current.body ? current : mkAbs(current.name, current.type, body);
      }
      case "App": {
        const fun = subst(current.fun);
        const arg = subst(current.arg);
        return fun === current.fun && arg === current.arg ? current : mkApp(fun, arg);
      }
      default:
        return current;
    }
  };
  return subst(term);
};

export const instantiate = (insts: readonly Instantiation[], thm: Thm): Thm => {
  if (insts.length === 0) return thm;
  for (const inst of insts)
    if (!eqTyp(inst.variable.type, fastypeOf(inst.term)))
      throw new TlaIsabelleError("THM", "instantiate: type conflict");
  const prop = instantiateTerm(insts, thm.prop);
  const tpairs = thm.tpairs.map((pair): Tpair => [
    instantiateTerm(insts, pair[0]),
    instantiateTerm(insts, pair[1]),
  ]);
  return makeThm(maxidxTpairs(tpairs, maxidxOfTerm(prop)), thm.hyps, tpairs, prop);
};

const instantiateTypesTerm = (tyenv: TyEnv, term: Term): Term => {
  if (maxidxOfTerm(term) < 0) return term;
  switch (term.kind) {
    case "Const":
      return mkConst(term.name, substType(tyenv, term.type));
    case "Free":
      return mkFree(term.name, substType(tyenv, term.type));
    case "Var":
      return mkVar(term.name, term.index, substType(tyenv, term.type));
    case "Bound":
      return term;
    case "Abs":
      return mkAbs(term.name, substType(tyenv, term.type), instantiateTypesTerm(tyenv, term.body));
    case "App":
      return mkApp(instantiateTypesTerm(tyenv, term.fun), instantiateTypesTerm(tyenv, term.arg));
  }
};

export const instantiateTypes = (tyenv: TyEnv, thm: Thm): Thm => {
  const prop = instantiateTypesTerm(tyenv, thm.prop);
  const tpairs = thm.tpairs.map((pair): Tpair => [
    instantiateTypesTerm(tyenv, pair[0]),
    instantiateTypesTerm(tyenv, pair[1]),
  ]);
  return makeThm(maxidxTpairs(tpairs, maxidxOfTerm(prop)), thm.hyps, tpairs, prop);
};

export const renamedProp = (prop: Term, thm: Thm): Thm => {
  if (!aconv(prop, thm.prop)) throw new TlaIsabelleError("TERM", "renamed_prop: props disagree");
  return makeThm(thm.maxidx, thm.hyps, thm.tpairs, prop);
};

export const trivial = (prop: Term): Thm => {
  if (!eqTyp(fastypeOf(prop), propT))
    throw new TlaIsabelleError("THM", "trivial: the term must have type prop");
  return makeThm(maxidxOfTerm(prop), [], [], mkImplies(prop, prop));
};

interface State {
  readonly tpairs: readonly Tpair[];
  readonly before: Term[];
  readonly goal: Term;
  readonly conclusion: Term;
}

const destState = (state: Thm, index: number): State => {
  const premises = stripImpPrems(state.prop);
  if (index < 1 || index > premises.length)
    throw new TlaIsabelleError("THM", `dest_state ${index}`);
  return {
    tpairs: state.tpairs,
    before: premises.slice(0, index - 1),
    goal: premises[index - 1],
    conclusion: listImplies(premises.slice(index), stripImpConcl(state.prop)),
  };
};

export const liftRule = (goal: Term, goalMaxidx: number, rule: Thm): Thm => {
  const increment = goalMaxidx + 1;
  const premises = stripImpPrems(rule.prop).map((premise) => liftAll(increment, goal, premise));
  return makeThm(
    rule.maxidx + increment,
    rule.hyps,
    rule.tpairs.map((pair): Tpair => [
      liftAbs(increment, goal, pair[0]),
      liftAbs(increment, goal, pair[1]),
    ]),
    listImplies(premises, liftAll(increment, goal, stripImpConcl(rule.prop))),
  );
};

export const incrIndexesThm = (increment: number, thm: Thm): Thm => {
  if (increment < 0) throw new TlaIsabelleError("THM", "negative increment");
  if (increment === 0) return thm;
  return makeThm(
    thm.maxidx + increment,
    thm.hyps,
    thm.tpairs.map((pair): Tpair => [
      incrIndexes([], increment, pair[0]),
      incrIndexes([], increment, pair[1]),
    ]),
    incrIndexes([], increment, thm.prop),
  );
};

export const assumption = (limits: Limits | undefined, index: number, state: Thm): Seq<Thm> => {
  const parts = destState(state, index);
  const newThm = (unifier: Unifier): Thm => {
    const envir = unifier.envir;
    const isEmpty = isEmptyEnvir(envir);
    const prop = listImplies(parts.before, parts.conclusion);
    return makeThm(
      envir.maxidx,
      state.hyps,
      isEmpty
        ? unifier.tpairs
        : unifier.tpairs.map((pair): Tpair => [normTerm(envir, pair[0]), normTerm(envir, pair[1])]),
      isEmpty ? prop : normTerm(envir, prop),
    );
  };
  const problems = assumProblems(-1, parts.goal);
  const conclusion = problems.abstract(problems.conclusion);
  const addprfs = (position: number): Seq<Thm> =>
    position >= problems.hyps.length
      ? emptySeq
      : makeSeq(() => {
          const hyp = problems.hyps[position];
          return mappSeq(
            newThm,
            couldUnify(hyp, problems.conclusion)
              ? unifiers(limits, emptyEnvir(state.maxidx), [
                  [problems.abstract(hyp), conclusion],
                  ...parts.tpairs,
                ])
              : emptySeq,
            addprfs(position + 1),
          ).pull();
        });
  return addprfs(0);
};

export const eqAssumption = (index: number, state: Thm): Thm => {
  const parts = destState(state, index);
  const problems = assumProblems(-1, parts.goal);
  const conclusion = etaContract(problems.conclusion);
  const isFound = problems.hyps.some(
    (hyp) => aconv(hyp, problems.conclusion) || aconv(etaContract(hyp), conclusion),
  );
  if (!isFound) throw new TlaIsabelleError("THM", "eq_assumption");
  return makeThm(
    state.maxidx,
    state.hyps,
    state.tpairs,
    listImplies(parts.before, parts.conclusion),
  );
};

export const rotateRule = (count: number, index: number, state: Thm): Thm => {
  const parts = destState(state, index);
  const params = stripAllVars(parts.goal);
  const rest = stripAllBody(parts.goal);
  const asms = stripImpPrems(rest);
  const concl = stripImpConcl(rest);
  const total = asms.length;
  const shift = count < 0 ? total + count : count;
  if (shift < 0 || shift > total) throw new TlaIsabelleError("THM", `rotate_rule ${count}`);
  const goal =
    shift === 0 || shift === total
      ? parts.goal
      : listAll(params, listImplies([...asms.slice(shift), ...asms.slice(0, shift)], concl));
  const premises = stripImpPrems(state.prop);
  return makeThm(
    state.maxidx,
    state.hyps,
    state.tpairs,
    listImplies([...parts.before, goal, ...premises.slice(index)], stripImpConcl(state.prop)),
  );
};

export const permutePrems = (fixed: number, count: number, rule: Thm): Thm => {
  const premises = stripImpPrems(rule.prop);
  const concl = stripImpConcl(rule.prop);
  if (fixed > premises.length) throw new TlaIsabelleError("THM", `permute_prems: j ${fixed}`);
  const moved = premises.slice(fixed);
  const shift = count < 0 ? moved.length + count : count;
  if (shift === 0 || shift === moved.length) return rule;
  if (shift < 0 || shift > moved.length)
    throw new TlaIsabelleError("THM", `permute_prems: k ${count}`);
  return makeThm(
    rule.maxidx,
    rule.hyps,
    rule.tpairs,
    listImplies(
      [...premises.slice(0, fixed), ...moved.slice(shift), ...moved.slice(0, shift)],
      concl,
    ),
  );
};

interface ComposeFlags {
  readonly flatten: boolean;
  readonly match: boolean;
  readonly incremented: boolean;
}

interface ComposeRule {
  readonly isElim: boolean;
  readonly rule: Thm;
  readonly subgoals: number;
}

class Compose {}

const bicomposeAux = (
  limits: Limits | undefined,
  flags: ComposeFlags,
  state: Thm,
  parts: State,
  isLifted: boolean,
  compose: ComposeRule,
): Seq<Thm> => {
  const orule = compose.rule;
  const lift = countPrems(stripAllBody(parts.goal)) + (compose.isElim ? -1 : 0);
  const addth = (newPremises: readonly Term[], unifier: Unifier, rest: Seq<Thm>): Seq<Thm> => {
    try {
      const envir = unifier.envir;
      const normt = (term: Term) => normTerm(envir, term);
      const computed = (): [readonly Tpair[], Term[], Term] => {
        if (isEmptyEnvir(envir))
          return [unifier.tpairs, [...parts.before, ...newPremises], parts.conclusion];
        const tpairs = unifier.tpairs.map((pair): Tpair => [normt(pair[0]), normt(pair[1])]);
        if (above(envir, state.maxidx))
          return isLifted
            ? [
                tpairs,
                [
                  ...parts.before,
                  ...newPremises.map((premise) => normTermSkip(envir, lift, premise)),
                ],
                parts.conclusion,
              ]
            : [tpairs, [...parts.before, ...newPremises.map(normt)], parts.conclusion];
        if (flags.match) throw new Compose();
        return [tpairs, [...parts.before, ...newPremises].map(normt), normt(parts.conclusion)];
      };
      const [tpairs, premises, conclusion] = computed();
      return consSeq(
        makeThm(
          envir.maxidx,
          unionHyps(orule.hyps, state.hyps),
          tpairs,
          listImplies(premises, conclusion),
        ),
        rest,
      );
    } catch (error) {
      if (error instanceof Compose) return rest;
      throw error;
    }
  };
  const stripped = (() => {
    try {
      return stripPrems(compose.subgoals, [], orule.prop);
    } catch (error) {
      if (error instanceof TlaIsabelleError && error.exception === "TERM")
        throw new TlaIsabelleError("THM", "bicompose: rule");
      throw error;
    }
  })();
  const reversedAs = stripped[0];
  const conclusion = stripped[1];
  const newAs = (
    premises: readonly Term[],
    index: number,
    dpairs: readonly Tpair[],
    tpairs: readonly Tpair[],
  ) => {
    const rename = isLifted ? renameBvars(dpairs, tpairs, conclusion, premises) : undefined;
    const renamed =
      rename === undefined
        ? [...premises]
        : premises.map((premise) => stripApply(rename, conclusion, premise));
    try {
      return flags.flatten ? renamed.map((premise) => flattenParams(index, premise)) : renamed;
    } catch (error) {
      if (error instanceof TlaIsabelleError && error.exception === "TERM")
        throw new TlaIsabelleError("THM", "bicompose: 1st premise");
      throw error;
    }
  };
  const bbi: Tpair = isLifted ? stripAssums2(conclusion, parts.goal) : [conclusion, parts.goal];
  const dpairs: Tpair[] = [bbi, ...orule.tpairs, ...parts.tpairs];
  const eres = (envir: Envir, premises: readonly Term[]): Seq<Thm> => {
    if (premises.length === 0) throw new TlaIsabelleError("THM", "bicompose: no premises");
    const first = premises[0];
    const rest = premises.slice(1);
    const problems = assumProblems(lift + 1, first);
    const concl = problems.abstract(problems.conclusion);
    const tryasms = (position: number): Seq<Thm> => {
      for (let index = position; index < problems.hyps.length; index += 1) {
        const asm = problems.hyps[index];
        if (!couldUnify(asm, problems.conclusion)) continue;
        const closed = problems.abstract(asm);
        const cell = unifiers(limits, envir, [[closed, concl], ...dpairs]).pull();
        if (cell === undefined) continue;
        const prepared = newAs(rest, index + 1, [bbi, [concl, closed]], cell[0].tpairs);
        return itRightSeq(
          (unifier, tail: Seq<Thm>) => addth(prepared, unifier, tail),
          makeSeq(() => cell),
          deferSeq(() => tryasms(index + 1)),
        );
      }
      return emptySeq;
    };
    return tryasms(0);
  };
  const res = (envir: Envir): Seq<Thm> => {
    const cell = unifiers(limits, envir, dpairs).pull();
    if (cell === undefined) return emptySeq;
    const prepared = newAs([...reversedAs].reverse(), 0, [bbi], cell[0].tpairs);
    return itRightSeq(
      (unifier, tail: Seq<Thm>) => addth(prepared, unifier, tail),
      makeSeq(() => cell),
      emptySeq,
    );
  };
  const initial = emptyEnvir(Math.max(orule.maxidx, state.maxidx));
  const envir = flags.incremented ? initial : unifyVarTypes(state, orule, initial);
  if (envir === undefined) return emptySeq;
  return compose.isElim ? eres(envir, [...reversedAs].reverse()) : res(envir);
};

export const bicompose = (
  limits: Limits | undefined,
  flags: ComposeFlags,
  compose: ComposeRule,
  index: number,
  state: Thm,
) => bicomposeAux(limits, flags, state, destState(state, index), false, compose);

const couldBires = (hyps: readonly Term[], goal: Term, isElim: boolean, rule: Thm) => {
  if (!couldUnify(conclOf(rule), goal)) return false;
  if (!isElim) return true;
  const first = premsOf(rule)[0];
  return first !== undefined && hyps.some((hyp) => couldUnify(first, hyp));
};

export interface BiresRule {
  readonly isElim: boolean;
  readonly rule: Thm;
}

export const biresolution = (
  limits: Limits | undefined,
  match: boolean,
  rules: readonly BiresRule[],
  index: number,
  state: Thm,
): Seq<Thm> => {
  const parts = destState(state, index);
  const goal = stripAssumsConcl(parts.goal);
  const hyps = stripAssumsHyp(parts.goal);
  const res = (position: number): Seq<Seq<Thm>> => {
    for (let current = position; current < rules.length; current += 1) {
      const brule = rules[current];
      if (!couldBires(hyps, goal, brule.isElim, brule.rule)) continue;
      return makeSeq(() => [
        bicomposeAux(limits, { flatten: true, match, incremented: true }, state, parts, true, {
          isElim: brule.isElim,
          rule: liftRule(parts.goal, state.maxidx, brule.rule),
          subgoals: nprems(brule.rule),
        }),
        res(current + 1),
      ]);
    }
    return emptySeq;
  };
  return flatSeq(res(0));
};

export const rsn = (rule: Thm, index: number, state: Thm): Thm => {
  const [results] = chopSeq(
    2,
    biresolution(undefined, false, [{ isElim: false, rule }], index, state),
  );
  if (results.length === 0) throw new TlaIsabelleError("THM", `RSN: no unifiers ${index}`);
  if (results.length > 1) throw new TlaIsabelleError("THM", `RSN: multiple unifiers ${index}`);
  return results[0];
};

export const rs = (rule: Thm, state: Thm) => rsn(rule, 1, state);
