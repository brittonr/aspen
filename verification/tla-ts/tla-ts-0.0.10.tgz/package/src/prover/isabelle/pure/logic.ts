// Ported from Isabelle2025's Pure/logic.ML. Copyright (c) 1986-2025 University of Cambridge, Technische Universitaet Muenchen, and contributors, see LICENSE.

import { TlaIsabelleError } from "../../../errors";
import { variantList } from "./name";
import {
  aconv,
  fastypeOf,
  funT,
  funTs,
  incrBoundvars,
  mapAtyps,
  mkAbs,
  mkApp,
  mkBound,
  mkConst,
  mkFree,
  mkTVar,
  mkVar,
  mayOccur,
  propT,
  type App,
  type Term,
  type Typ,
} from "./term";

export const occs = (term: Term, other: Term): boolean =>
  mayOccur(term, other) &&
  (aconv(term, other) ||
    (other.kind === "App"
      ? occs(term, other.fun) || occs(term, other.arg)
      : other.kind === "Abs" && occs(term, other.body)));

export interface Binder {
  readonly name: string;
  readonly type: Typ;
}

export const allConst = (type: Typ) => mkConst("Pure.all", funT(funT(type, propT), propT));

export const listAll = (vars: readonly Binder[], body: Term): Term =>
  vars.reduceRight<Term>(
    (result, variable) =>
      mkApp(allConst(variable.type), mkAbs(variable.name, variable.type, result)),
    body,
  );

export const mkEquals = (left: Term, right: Term) => {
  const type = fastypeOf(left);
  return mkApp(mkApp(mkConst("Pure.eq", funTs([type, type], propT)), left), right);
};

interface ConstApp2 extends App {
  readonly fun: App;
}

const isConstApp2 = (term: Term, name: string): term is ConstApp2 =>
  term.kind === "App" &&
  term.fun.kind === "App" &&
  term.fun.fun.kind === "Const" &&
  term.fun.fun.name === name;

export const isEquals = (term: Term): term is ConstApp2 => isConstApp2(term, "Pure.eq");

export const destEquals = (term: Term): [Term, Term] => {
  if (!isConstApp2(term, "Pure.eq")) throw new TlaIsabelleError("TERM", "dest_equals");
  return [term.fun.arg, term.arg];
};

export const implies = mkConst("Pure.imp", funTs([propT, propT], propT));

export const mkImplies = (premise: Term, conclusion: Term) =>
  mkApp(mkApp(implies, premise), conclusion);

export const isImplies = (term: Term): term is ConstApp2 => isConstApp2(term, "Pure.imp");

export const destImplies = (term: Term): [Term, Term] => {
  if (!isConstApp2(term, "Pure.imp")) throw new TlaIsabelleError("TERM", "dest_implies");
  return [term.fun.arg, term.arg];
};

export const listImplies = (premises: readonly Term[], conclusion: Term) =>
  premises.reduceRight((result, premise) => mkImplies(premise, result), conclusion);

export const stripImpPrems = (term: Term): Term[] => {
  const premises: Term[] = [];
  let current = term;
  while (isConstApp2(current, "Pure.imp")) {
    premises.push(current.fun.arg);
    current = current.arg;
  }
  return premises;
};

export const stripImpConcl = (term: Term): Term => {
  let current = term;
  while (isConstApp2(current, "Pure.imp")) current = current.arg;
  return current;
};

export const stripPrems = (
  count: number,
  premises: readonly Term[],
  term: Term,
): [Term[], Term] => {
  if (count === 0) return [[...premises], term];
  if (!isConstApp2(term, "Pure.imp")) throw new TlaIsabelleError("TERM", "strip_prems");
  return stripPrems(count - 1, [term.fun.arg, ...premises], term.arg);
};

export const countPrems = (term: Term) => stripImpPrems(term).length;

const protectConst = mkConst("Pure.prop", funT(propT, propT));

export const protect = (term: Term) => mkApp(protectConst, term);

export const isProtected = (term: Term) =>
  term.kind === "App" && term.fun.kind === "Const" && term.fun.name === "Pure.prop";

export const mkTerm = (term: Term) =>
  mkApp(mkConst("Pure.term", funT(fastypeOf(term), propT)), term);

export const combound = (term: Term, start: number, count: number): Term =>
  count > 0 ? mkApp(combound(term, start + 1, count - 1), mkBound(start)) : term;

export const rlistAbs = (binders: readonly Binder[], body: Term) =>
  binders.reduce((result, binder) => mkAbs(binder.name, binder.type, result), body);

const incrTVar = (increment: number, type: Typ) =>
  increment === 0
    ? type
    : mapAtyps(
        (atom) =>
          atom.kind === "TVar" ? mkTVar(atom.name, atom.index + increment, atom.sort) : atom,
        type,
      );

const incrIndexesFixed = (
  fixed: readonly string[],
  types: readonly Typ[],
  increment: number,
  level: number,
  term: Term,
): Term => {
  if (fixed.length === 0 && types.length === 0 && increment === 0) return term;
  const count = types.length;
  const incr = (depth: number, current: Term): Term => {
    switch (current.kind) {
      case "Var":
        return combound(
          mkVar(
            current.name,
            current.index + increment,
            funTs(types, incrTVar(increment, current.type)),
          ),
          depth,
          count,
        );
      case "Free":
        return fixed.includes(current.name)
          ? combound(
              mkFree(current.name, funTs(types, incrTVar(increment, current.type))),
              depth,
              count,
            )
          : mkFree(current.name, incrTVar(increment, current.type));
      case "Abs":
        return mkAbs(
          current.name,
          incrTVar(increment, current.type),
          incr(depth + 1, current.body),
        );
      case "App":
        return mkApp(incr(depth, current.fun), incr(depth, current.arg));
      case "Const":
        return mkConst(current.name, incrTVar(increment, current.type));
      case "Bound":
        return current;
    }
  };
  return incr(level, term);
};

export const incrIndexes = (types: readonly Typ[], increment: number, term: Term) =>
  incrIndexesFixed([], types, increment, 0, term);

const isAllAbs = (
  term: Term,
): term is Extract<Term, { kind: "App" }> & {
  arg: Extract<Term, { kind: "Abs" }>;
} =>
  term.kind === "App" &&
  term.fun.kind === "Const" &&
  term.fun.name === "Pure.all" &&
  term.arg.kind === "Abs";

export const liftAbs = (increment: number, goal: Term, term: Term): Term => {
  const lift = (types: Typ[], current: Term): Term => {
    if (isConstApp2(current, "Pure.imp")) return lift(types, current.arg);
    if (isAllAbs(current))
      return mkAbs(
        current.arg.name,
        current.arg.type,
        lift([current.arg.type, ...types], current.arg.body),
      );
    return incrIndexes([...types].reverse(), increment, term);
  };
  return lift([], goal);
};

export const liftAll = (increment: number, goal: Term, term: Term): Term => {
  const lift = (types: Typ[], current: Term): Term => {
    if (isConstApp2(current, "Pure.imp"))
      return mkApp(mkApp(current.fun.fun, current.fun.arg), lift(types, current.arg));
    if (isAllAbs(current))
      return mkApp(
        current.fun,
        mkAbs(
          current.arg.name,
          current.arg.type,
          lift([current.arg.type, ...types], current.arg.body),
        ),
      );
    return incrIndexes([...types].reverse(), increment, term);
  };
  return lift([], goal);
};

export const stripAssumsHyp = (term: Term): Term[] => {
  let hyps: Term[] = [];
  let current = term;
  for (;;) {
    if (isConstApp2(current, "Pure.imp")) {
      hyps = [current.fun.arg, ...hyps];
      current = current.arg;
    } else if (isAllAbs(current)) {
      hyps = hyps.map((hyp) => incrBoundvars(1, hyp));
      current = current.arg.body;
    } else return hyps.reverse();
  }
};

export const stripAssumsConcl = (term: Term): Term => {
  let current = term;
  for (;;) {
    if (isConstApp2(current, "Pure.imp")) current = current.arg;
    else if (isAllAbs(current)) current = current.arg.body;
    else return current;
  }
};

export const stripParams = (term: Term): Binder[] => {
  const params: Binder[] = [];
  let current = term;
  for (;;) {
    if (isConstApp2(current, "Pure.imp")) current = current.arg;
    else if (isAllAbs(current)) {
      params.push({ name: current.arg.name, type: current.arg.type });
      current = current.arg.body;
    } else return params;
  }
};

const isMeta = (term: Term) =>
  isConstApp2(term, "Pure.eq") ||
  isConstApp2(term, "Pure.imp") ||
  (term.kind === "App" && term.fun.kind === "Const" && term.fun.name === "Pure.all");

export const hasMetaPrems = (term: Term): boolean => {
  if (isConstApp2(term, "Pure.imp")) return isMeta(term.fun.arg) || hasMetaPrems(term.arg);
  if (isAllAbs(term)) return hasMetaPrems(term.arg.body);
  return false;
};

const removeParams = (count: number, index: number, term: Term): Term => {
  if (count === 0 && index <= 0) return term;
  if (isConstApp2(term, "Pure.imp"))
    return index === 1
      ? removeParams(count, index - 1, term.arg)
      : mkImplies(incrBoundvars(count, term.fun.arg), removeParams(count, index - 1, term.arg));
  if (isAllAbs(term)) return removeParams(count - 1, index, term.arg.body);
  if (index > 0) throw new TlaIsabelleError("TERM", "remove_params");
  return term;
};

export const flattenParams = (index: number, term: Term) => {
  const params = stripParams(term);
  const names = variantList(
    [],
    params.map((param) => param.name),
  );
  const vars = params.map((param, position) => ({ name: names[position], type: param.type }));
  return listAll(vars, removeParams(vars.length, index, term));
};

const stripAssumsImp = (count: number, hyps: Term[], term: Term): [Term[], Term] => {
  if (count === 0) return [hyps, term];
  if (isConstApp2(term, "Pure.imp"))
    return stripAssumsImp(count - 1, [term.fun.arg, ...hyps], term.arg);
  return [hyps, term];
};

const stripAssumsAll = (params: Binder[], term: Term): [Binder[], Term] =>
  isAllAbs(term)
    ? stripAssumsAll([{ name: term.arg.name, type: term.arg.type }, ...params], term.arg.body)
    : [params, term];

interface AssumProblems {
  readonly abstract: (term: Term) => Term;
  readonly hyps: Term[];
  readonly conclusion: Term;
}

export const assumProblems = (count: number, term: Term): AssumProblems => {
  const [params, body] = stripAssumsAll([], term);
  const [hyps, conclusion] = stripAssumsImp(count, [], body);
  return { abstract: (inner) => rlistAbs(params, inner), hyps: [...hyps].reverse(), conclusion };
};
