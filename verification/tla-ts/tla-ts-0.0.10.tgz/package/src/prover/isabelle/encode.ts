// Ported from tlapm's src/backend/isabelle.ml (BSD licensed, see LICENSE-tlapm).

import { TlapmBugError, TlaProverError, TlaUnsupportedError } from "../../errors";
import { createContext, getBoundName, popNames, pushName } from "../../obligations/printer";
import type { Bound, Builtin, Expr, Sequent } from "../../obligations/expression";
import { getUnprintableError, pickle, printFact, splitFirstBound } from "../first-order";

const cook = (name: string) => `is${pickle(name)}`;

const ATOMS: Partial<Record<Builtin, string>> = {
  TRUE: "TRUE",
  FALSE: "FALSE",
  STRING: "STRING",
  BOOLEAN: "BOOLEAN",
  Nat: "Nat",
  Int: "Int",
  Real: cook("Real"),
  Infinity: cook("Infinity"),
  Any: "Any",
};

const UNARY: Partial<Record<Builtin, string>> = {
  Neg: "~",
  DOMAIN: "DOMAIN",
  SUBSET: "SUBSET",
  UNION: "UNION",
};

const BINARY: Partial<Record<Builtin, string>> = {
  Implies: "\\<Rightarrow>",
  Equiv: "\\<Leftrightarrow>",
  Conj: "\\<and>",
  Disj: "\\<or>",
  Eq: "=",
  Neq: "\\<noteq>",
  Subseteq: "\\<subseteq>",
  Mem: "\\<in>",
  Notmem: "\\<notin>",
  Setminus: "\\\\",
  Cap: "\\<inter>",
  Cup: "\\<union>",
  OneArg: ":>",
  Extend: "@@",
};

const NONFIX: Partial<Record<Builtin, [string, number]>> = {
  Plus: ["addint", 2],
  Minus: ["subint", 2],
  Uminus: ["minus", 1],
  Times: ["mult", 2],
  Ratio: [cook("/"), 2],
  Quotient: [cook("\\div"), 2],
  Remainder: [cook("%"), 2],
  Exp: [cook("^"), 2],
  Lteq: ["leq", 2],
  Lt: ["less", 2],
  Gteq: ["geq", 2],
  Gt: ["greater", 2],
  Range: ["intvl", 2],
  Seq: ["Seq", 1],
  Len: ["Len", 1],
  BSeq: ["BSeq", 1],
  Cat: [cook("\\circ"), 2],
  Append: ["Append", 2],
  Head: ["Head", 1],
  Tail: ["Tail", 1],
  SubSeq: ["SubSeq", 3],
  SelectSeq: ["SelectSeq", 2],
  Print: ["Print", 2],
  PrintT: ["PrintT", 1],
  Assert: ["Assert", 2],
  JavaTime: ["JavaTime", 0],
  TLCGet: ["TLCGet", 1],
  TLCSet: ["TLCSet", 2],
  Permutations: ["Permutations", 1],
  SortSeq: ["SortSeq", 2],
  RandomElement: ["RandomElement", 1],
  ToString: ["ToString", 1],
};

const DECLARED: [string, number][] = [
  ["Real", 0],
  ["/", 2],
  ["\\div", 2],
  ["%", 2],
  ["..", 2],
  ["Infinity", 0],
  ["[]", 1],
  ["<>", 1],
];

const HEADER = [
  "consts",
  ...DECLARED.map(
    (declared) =>
      `  "${cook(declared[0])}" :: ${declared[1] === 0 ? "c" : `"[${Array(declared[1]).fill("c").join(",")}] => c"`}`,
  ),
  "",
].join("\n");

const getSuccessors = (integer: string) => {
  const count = Number.parseInt(integer, 10);
  return `${"succ[".repeat(count)}0${"]".repeat(count)}`;
};

const getTheoryHeader = (name: string, isVerbose: boolean) => [
  "(* automatically generated -- do not edit manually *)",
  `theory ${name} imports Constant Zenon begin`,
  ...(isVerbose ? ['ML_command \\<open> writeln ("*** TLAPS PARSED\\n"); \\<close>'] : []),
  HEADER,
];

const printLemma = (sequent: Sequent) => {
  const context = createContext();
  const adjoin = (name: string) => pushName(context, pickle(name));
  const bump = () => pushName(context, "");

  const withBound = (name: string, print: (bound: string) => string) => {
    const printed = print(adjoin(name));
    popNames(context, 1);
    return printed;
  };

  const printExpr = (expression: Expr) => `(${formatExpr(expression)})`;
  const printDelimited = (args: Expr[]) => args.map(printExpr).join(", ");
  const printNonfix = (name: string, args: Expr[]) => `(${name} (${printDelimited(args)}))`;

  const printInternal = (builtin: Builtin, args: Expr[]): string => {
    const atom = ATOMS[builtin];
    if (atom !== undefined && args.length === 0) return atom;
    const unary = UNARY[builtin];
    if (unary !== undefined && args.length === 1) return `(${unary} ${printExpr(args[0])})`;
    const binary = BINARY[builtin];
    if (binary !== undefined && args.length === 2)
      return `(${printExpr(args[0])} ${binary} ${printExpr(args[1])})`;
    const operator = NONFIX[builtin];
    if (operator && operator[1] === args.length) return printNonfix(operator[0], args);
    if (builtin === "Unprimable" && args.length === 1) return printExpr(args[0]);
    if (builtin === "Irregular" && args.length === 1) throw new TlaUnsupportedError("Irregular");
    throw getUnprintableError(builtin, args.length, "Backend.Isabelle.pp_apply");
  };

  const printApply = (operator: Expr, args: Expr[]): string => {
    switch (operator.kind) {
      case "Ix": {
        const name = getBoundName(context, operator.index);
        if (operator.index <= 0 || name === undefined) throw new TlapmBugError();
        return args.length === 0 ? name : `(${name} (${printDelimited(args)}))`;
      }
      case "Opaque": {
        const name = pickle(operator.name);
        return args.length === 0 ? `(${name} :: c)` : `(${name} (${printDelimited(args)}) :: c)`;
      }
      case "Internal":
        return printInternal(operator.builtin, args);
      // tlapm prints a lambda without the arguments it's applied to.
      case "Lambda": {
        const names = operator.params.map((param) => `${adjoin(param.name)} `).join("");
        const printed = `\\<lambda> ${names}. ${printExpr(operator.body)}`;
        popNames(context, operator.params.length);
        return printed;
      }
      default:
        throw new TlapmBugError();
    }
  };

  const printQuant = (quantifier: "Forall" | "Exists", bounds: Bound[], body: Expr): string => {
    if (bounds.length === 0) return formatExpr(body);
    const split = splitFirstBound(quantifier, bounds, body);
    const symbol = quantifier === "Forall" ? "\\<forall>" : "\\<exists>";
    if (split.first.domain.kind === "NoDomain")
      return withBound(split.first.name, (name) => `${symbol}${name} : ${printExpr(split.inner)}`);
    if (split.first.domain.kind !== "Domain") throw new TlapmBugError();
    const domain = printExpr(split.first.domain.expression);
    return withBound(
      split.first.name,
      (name) => `${symbol} ${name} \\<in> ${domain} : ${printExpr(split.inner)}`,
    );
  };

  const printNestedSequent = (sequent: Sequent): string => {
    if (sequent.context.length === 0) return printExpr(sequent.active);
    const hyp = sequent.context[0];
    const printRest = () =>
      printNestedSequent({ context: sequent.context.slice(1), active: sequent.active });
    switch (hyp.kind) {
      case "Flex":
        return withBound(hyp.name, (name) => `(\\<And> ${name} ${name}'.${printRest()})`);
      case "Fresh": {
        if (hyp.domain && hyp.domainVisibility === "Visible") {
          const domain = printExpr(hyp.domain);
          return withBound(
            hyp.name,
            (name) =>
              `(\\<And> ${name} :: c. ${name} \\<in> ${domain} \\<Longrightarrow> ${printRest()})`,
          );
        }
        const shape = `${"c => ".repeat(hyp.shape)}c`;
        return withBound(hyp.name, (name) => `(\\<And> ${name} :: ${shape}. ${printRest()})`);
      }
      case "Fact": {
        const fact = hyp.visibility === "Visible" ? printExpr(hyp.expression) : undefined;
        bump();
        const printed = fact ? `(${fact} \\<Longrightarrow> ${printRest()})` : printRest();
        popNames(context, 1);
        return printed;
      }
      case "Defn":
        throw new TlaUnsupportedError("Inner definition");
    }
  };

  const formatExpr = (expression: Expr): string => {
    switch (expression.kind) {
      case "Ix":
      case "Internal":
      case "Opaque":
      case "Lambda":
        return printApply(expression, []);
      case "Apply":
        return printApply(expression.operator, expression.args);
      case "Bang":
        throw new TlaProverError("Backend.Isabelle.module");
      case "Sequent":
        return printNestedSequent(expression.sequent);
      case "With":
      case "Parens":
        return formatExpr(expression.expression);
      case "Let":
        throw new TlaUnsupportedError("LET");
      case "List":
        if (expression.bullet === "Refs" && expression.items.length === 0) return "TRUE";
        if (expression.bullet === "Refs" && expression.items.length === 1)
          return formatExpr(expression.items[0]);
        return expression.items.map(printExpr).join(expression.bullet === "Or" ? " | " : " & ");
      case "If":
        return `cond(${printExpr(expression.condition)}, ${printExpr(expression.consequent)}, ${printExpr(expression.alternative)})`;
      case "Quant":
        return printQuant(expression.quantifier, expression.bounds, expression.body);
      case "Tquant":
        throw new TlaUnsupportedError(expression.quantifier === "Forall" ? "\\\\AA" : "\\\\EE");
      case "Choose": {
        if (!expression.domain)
          return withBound(
            expression.name,
            (name) => `Choice(%${name}. ${printExpr(expression.body)})`,
          );
        const domain = printExpr(expression.domain);
        return withBound(
          expression.name,
          (name) => `bChoice(${domain}, %${name}. ${printExpr(expression.body)})`,
        );
      }
      case "SetSt": {
        const domain = printExpr(expression.domain);
        return withBound(
          expression.name,
          (name) => `subsetOf(${domain}, %${name}. ${printExpr(expression.body)})`,
        );
      }
      case "SetOf": {
        if (expression.bounds.length === 0) throw new TlapmBugError();
        const bound = expression.bounds[0];
        if (expression.bounds.length !== 1 || bound.domain.kind !== "Domain")
          throw new TlaUnsupportedError("SetOf (multiple declared constants)");
        const domain = printExpr(bound.domain.expression);
        return withBound(
          bound.name,
          (name) => `setOfAll(${domain}, %${name}. ${printExpr(expression.element)})`,
        );
      }
      case "SetEnum":
        return `{${printDelimited(expression.elements)}}`;
      case "Fcn": {
        const bound = expression.bounds[0];
        if (expression.bounds.length !== 1)
          throw new TlaUnsupportedError("function (multiple declared constants)");
        if (bound.domain.kind === "Ditto") throw new TlapmBugError();
        const domain =
          bound.domain.kind === "Domain" ? printExpr(bound.domain.expression) : undefined;
        return withBound(bound.name, (name) => {
          const printed = domain === undefined ? name : ` ${name} \\<in> ${domain} `;
          return `[${printed} \\<mapsto> ${printExpr(expression.body)}]`;
        });
      }
      case "FcnApp": {
        const printedFunction = printExpr(expression.function);
        return expression.args.length === 1
          ? `fapply (${printedFunction}, ${printExpr(expression.args[0])})`
          : `fapply (${printedFunction}, <<${printDelimited(expression.args)}>>)`;
      }
      case "Arrow":
        return `[${printExpr(expression.domain)} \\<rightarrow> ${printExpr(expression.range)}]`;
      case "Rect":
        return `[${expression.fields.map((field) => `''${field.name}'' : ${printExpr(field.value)}`).join(", ")}]`;
      case "Record":
        return `(${expression.fields.map((field) => `(''${field.name}'' :> ${printExpr(field.value)})`).join(" @@ ")})`;
      case "Except": {
        const specs = expression.specs.map((spec) => {
          const trail = spec.trail
            .map((point) =>
              point.kind === "Dot" ? `[''${point.field}'']` : `[${printExpr(point.expression)}]`,
            )
            .join("");
          return `!${trail} = ${printExpr(spec.value)}`;
        });
        return `[${printExpr(expression.function)} EXCEPT ${specs.join(", ")}]`;
      }
      case "Dot":
        return `fapply (${printExpr(expression.expression)}, (''${expression.field}''))`;
      case "Tuple":
        return `<<${printDelimited(expression.elements)}>>`;
      case "Product":
        return expression.factors.length === 2
          ? `(${printExpr(expression.factors[0])} \\<times> ${printExpr(expression.factors[1])})`
          : `Product(\\<langle>${printDelimited(expression.factors)}\\<rangle>)`;
      case "Sub":
      case "Tsub": {
        const suffix = expression.kind === "Sub" ? "sub" : "tsub";
        const name = expression.modal === "Box" ? cook(`a'box'${suffix}`) : `a'dia'${suffix}`;
        return `${name}(${printExpr(expression.action)},${printExpr(expression.subscript)})`;
      }
      case "Fair":
        return `${cook(expression.fairness === "Weak" ? "a'wf" : "a'sf")}(${printExpr(expression.subscript)},${printExpr(expression.action)})`;
      case "Case": {
        const conditions = printDelimited(expression.arms.map((arm) => arm.condition));
        const bodies = printDelimited(expression.arms.map((arm) => arm.body));
        return expression.other
          ? `CaseOther(<<${conditions}>>,<<${bodies}>>,${printExpr(expression.other)})`
          : `Case(<<${conditions}>>,<<${bodies}>>)`;
      }
      case "String":
        return `''${expression.value}''`;
      case "Num":
        if (expression.fraction !== "") throw new TlaUnsupportedError("real constants");
        return `(${getSuccessors(expression.integer)})`;
      case "At":
        throw new TlapmBugError();
    }
  };

  const printSequent = (sequent: Sequent) => {
    const lines: string[] = [];
    for (const hyp of sequent.context) {
      switch (hyp.kind) {
        case "Flex": {
          const name = adjoin(hyp.name);
          lines.push(`fixes ${name} ${name}'`);
          break;
        }
        case "Fresh": {
          const domain =
            hyp.domain && hyp.domainVisibility === "Visible" ? printExpr(hyp.domain) : undefined;
          const name = adjoin(hyp.name);
          lines.push(`fixes ${name}`);
          if (domain === undefined) break;
          lines.push(`assumes ${name}_in : "(${name} \\<in> ${domain})"`);
          break;
        }
        case "Fact": {
          const count = context.stack.length;
          const fact =
            hyp.visibility === "Visible"
              ? printFact(context, () => printExpr(hyp.expression))
              : undefined;
          bump();
          if (fact instanceof TlaUnsupportedError) {
            lines.push(`(* omitted temporal assumption : ${fact.message} *)`);
            break;
          }
          if (fact === undefined) break;
          lines.push(`assumes v'${count}: "${fact}"`);
          break;
        }
        case "Defn":
          if (hyp.definition.kind === "Bpragma") return [...lines, ""];
          lines.push(`(* usable definition ${hyp.definition.name} suppressed *)`);
          adjoin(hyp.definition.name);
          break;
      }
    }
    return [...lines, `shows "${printExpr(sequent.active)}"`];
  };

  try {
    const lines = printSequent(sequent);
    return {
      text: lines.join("\n"),
      isAssumed: lines.some((line) => line.startsWith("assumes ")),
    };
  } catch (error) {
    if (!(error instanceof TlaUnsupportedError)) throw error;
    throw new TlaProverError(`isabelle : unsupported operator ${error.message}`);
  }
};

export const encodeIsabelle = (id: number, sequent: Sequent, tactic: string): string => {
  const lemma = printLemma(sequent);
  return [
    ...getTheoryHeader(`tlapm_${id}`, false),
    `lemma ob'${id}:`,
    `${lemma.text}(is "PROP ?ob'${id}")`,
    "proof -",
    `show "PROP ?ob'${id}"`,
    `${lemma.isAssumed ? "using assms " : ""}by ${tactic}`,
    "qed",
    "end",
    "",
  ].join("\n");
};

interface IsabelleProof {
  id: number;
  sequent: Sequent;
  tactic: string;
}

export const encodeIsabelleTheory = (name: string, proofs: IsabelleProof[]) =>
  [
    ...getTheoryHeader(name, true),
    ...proofs.flatMap((proof) => [
      `lemma ob'${proof.id}:`,
      `${printLemma(proof.sequent).text}(is "PROP ?ob'${proof.id}")`,
      "proof -",
      `ML_command \\<open> writeln "*** TLAPS ENTER ${proof.id}"; \\<close>`,
      `show "PROP ?ob'${proof.id}"`,
      `using assms by ${proof.tactic}`,
      `ML_command \\<open> writeln "*** TLAPS EXIT ${proof.id}"; \\<close> qed`,
    ]),
    "end",
    "",
  ].join("\n");
