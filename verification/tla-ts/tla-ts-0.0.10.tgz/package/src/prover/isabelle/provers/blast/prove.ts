// Ported from Isabelle2025's Provers/blast.ML. Copyright (c) 1986-2025 University of Cambridge, Technische Universitaet Muenchen, and contributors, see LICENSE.

import type { Seq } from "../../pure/seq";
import type { GoalTactic } from "../../pure/tactical";
import { checkInterrupt } from "../../pure/interrupt";
import { cons, type List } from "../../pure/list";
import type { Thm } from "../../pure/thm";
import {
  addLit,
  equalSubst,
  joinMd,
  log4,
  match,
  negOfGoal,
  negOfGoals,
  nextVars,
  prune,
  tryClose,
} from "./branch";
import { negOfGoalTac, netMkRules, type TableauRule } from "./rules";
import {
  backtrack,
  clearTo,
  isBacktrackTo,
  unify,
  type BlastState,
  type Branch,
  type Choices,
  type Formula,
  type Level,
} from "./state";
import {
  addTermVars,
  addTermsVars,
  isGoal,
  norm,
  sameVars,
  varsInVars,
  type BlastTerm,
  type VarRef,
} from "./term";

type Tactics = List<GoalTactic> | undefined;

export type Continuation = (tactics: Tactics, choices: Choices) => Seq<Thm>;

type Step =
  | { readonly kind: "done"; readonly result: Seq<Thm> }
  | {
      readonly kind: "next";
      readonly tactics: Tactics;
      readonly choices: Choices;
      readonly brs: readonly Branch[];
    };

const done = (result: Seq<Thm>): Step => ({ kind: "done", result });

const addPremsVars = (prems: readonly (readonly BlastTerm[])[], vars: readonly VarRef[]) =>
  prems.reduceRight((result, prem) => addTermsVars(prem, result), vars);

export const prove = (
  state: BlastState,
  initial: readonly Branch[],
  cont: Continuation,
): Seq<Thm> => {
  const context = state.context;
  const safeList = [context.claset.safe0, context.claset.safep];
  const unsafeList = [context.claset.unsafe];

  const safeStep = (tactics: Tactics, choices: Choices, brs: readonly Branch[]): Step => {
    const token = {};
    const branch = brs[0];
    const rest = brs.slice(1);
    const head = branch.pairs[0];
    const md = head.safe[0].md;
    const queued: Level = { safe: head.safe.slice(1), unsafe: head.unsafe };
    const pairs = [queued, ...branch.pairs.slice(1)];
    const ntrl = state.trail.length;
    const nbrs = brs.length;
    const nxtVars = nextVars(rest);
    const formula = norm(head.safe[0].term);
    const rules = netMkRules(state, formula, branch.vars, safeList);
    const newBr = (vars: readonly VarRef[], lim: number, prems: TableauRule["prems"]): Branch[] => [
      ...prems.map((prem): Branch => {
        const level = { safe: joinMd(md, prem), unsafe: [] };
        return prem.some(isGoal)
          ? {
              pairs: [level, ...negOfGoals(state, pairs)],
              lits: branch.lits.map((lit) => negOfGoal(state, lit)),
              vars,
              lim,
            }
          : { pairs: [level, ...pairs], lits: branch.lits, vars, lim };
      }),
      ...rest,
    ];
    const deeper = (): Seq<Thm> | undefined => {
      for (let position = 0; position < rules.length; position += 1) {
        const rule = rules[position];
        if (!unify(state, addTermVars(rule.major, []), rule.major, formula)) continue;
        const isUpdated = ntrl < state.trail.length;
        const lim = isUpdated ? branch.lim - (1 + log4(rules.length)) : branch.lim;
        const vars = addPremsVars(rule.prems, varsInVars(branch.vars));
        const nextChoices = cons({ ntrl, nbrs, token }, choices);
        const nextTactics = cons(rule.tactic(isUpdated, false, true), tactics);
        try {
          if (rule.prems.length === 0)
            return prv(nextTactics, prune(state, nbrs, nxtVars, nextChoices), rest);
          if (lim < 0) {
            clearTo(state, ntrl);
            return undefined;
          }
          return prv(nextTactics, nextChoices, newBr(vars, lim, rule.prems));
        } catch (error) {
          if (!isBacktrackTo(error, token)) throw error;
          if (!isUpdated) return backtrack(choices);
          clearTo(state, ntrl);
        }
      }
      return undefined;
    };
    const closeF = (literals: readonly BlastTerm[]): Seq<Thm> | undefined => {
      for (const literal of literals) {
        const tactic = tryClose(state, formula, literal);
        if (tactic === undefined) continue;
        const nextChoices = prune(state, nbrs, nxtVars, cons({ ntrl, nbrs, token }, choices));
        try {
          return prv(cons(tactic, tactics), nextChoices, rest);
        } catch (error) {
          if (!isBacktrackTo(error, token)) throw error;
          clearTo(state, ntrl);
        }
      }
      return undefined;
    };
    const closeFl = (levels: readonly Level[]): Seq<Thm> | undefined => {
      for (const level of levels) {
        const closed =
          closeF(level.safe.map((queuedFormula) => queuedFormula.term)) ??
          closeF(level.unsafe.map((queuedFormula) => queuedFormula.term));
        if (closed !== undefined) return closed;
      }
      return undefined;
    };
    if (branch.lim < 0) return backtrack(choices);
    const substituted = equalSubst(state, formula, { ...branch, pairs });
    if (substituted !== undefined)
      return {
        kind: "next",
        tactics: cons(context.data.hypSubstTac(context.limits), tactics),
        choices,
        brs: [substituted, ...rest],
      };
    const closed = closeF(branch.lits) ?? closeFl(pairs) ?? deeper();
    if (closed !== undefined) return done(closed);
    if (netMkRules(state, formula, branch.vars, unsafeList).length === 0)
      return {
        kind: "next",
        tactics,
        choices,
        brs: [
          { pairs, lits: addLit(state, formula, branch.lits), vars: branch.vars, lim: branch.lim },
          ...rest,
        ],
      };
    const deferred: Formula = { term: negOfGoal(state, formula), md };
    return {
      kind: "next",
      tactics: isGoal(formula) ? cons(negOfGoalTac(state), tactics) : tactics,
      choices,
      brs: [
        {
          pairs: [{ safe: queued.safe, unsafe: [...queued.unsafe, deferred] }, ...pairs.slice(1)],
          lits: branch.lits,
          vars: branch.vars,
          lim: branch.lim,
        },
        ...rest,
      ],
    };
  };

  const unsafeStep = (tactics: Tactics, choices: Choices, brs: readonly Branch[]): Step => {
    const token = {};
    const branch = brs[0];
    const rest = brs.slice(1);
    const queued = branch.pairs[0].unsafe;
    const md = queued[0].md;
    const others = queued.slice(1);
    const formula = norm(queued[0].term);
    const ntrl = state.trail.length;
    const rules = netMkRules(state, formula, branch.vars, unsafeList);
    const newPrem = (
      vars: readonly VarRef[],
      pattern: BlastTerm,
      isDup: boolean,
      lim: number,
      prem: readonly BlastTerm[],
    ): Branch => {
      const safe = prem.map((term) => ({ term, md: false }));
      const unsafe = isDup ? [...others, { term: negOfGoal(state, formula), md }] : others;
      return {
        pairs: prem.some((term) => match(state, pattern, term))
          ? [{ safe, unsafe }]
          : [
              { safe, unsafe: [] },
              { safe: [], unsafe },
            ],
        lits: prem.some(isGoal) ? branch.lits.map((lit) => negOfGoal(state, lit)) : branch.lits,
        vars,
        lim,
      };
    };
    const deeper = (): Seq<Thm> | undefined => {
      for (let position = 0; position < rules.length; position += 1) {
        const rule = rules[position];
        if (!unify(state, addTermVars(rule.major, []), rule.major, formula)) continue;
        const isUpdated = ntrl < state.trail.length;
        const vars = varsInVars(branch.vars);
        const newVars = addPremsVars(rule.prems, vars);
        const isDup = md;
        const lim = isUpdated ? branch.lim - (1 + log4(rules.length)) : branch.lim - 1;
        const mayUndo = position + 1 < rules.length || isUpdated || sameVars(vars, newVars);
        const tactic = rule.tactic(isUpdated, isDup, true);
        if (lim < 0 && rule.prems.length > 0) {
          clearTo(state, ntrl);
          return undefined;
        }
        try {
          return prv(cons(tactic, tactics), cons({ ntrl, nbrs: brs.length, token }, choices), [
            ...rule.prems.map((prem) => newPrem(newVars, rule.major, isDup, lim, prem)),
            ...rest,
          ]);
        } catch (error) {
          if (!isBacktrackTo(error, token)) throw error;
          if (!mayUndo) return backtrack(choices);
          clearTo(state, ntrl);
        }
      }
      return undefined;
    };
    if (branch.lim < 1) return backtrack(choices);
    const closed = deeper();
    if (closed !== undefined) return done(closed);
    return {
      kind: "next",
      tactics,
      choices,
      brs: [
        {
          pairs: [{ safe: [], unsafe: others }],
          lits: [formula, ...branch.lits],
          vars: branch.vars,
          lim: branch.lim,
        },
        ...rest,
      ],
    };
  };

  const prv = (
    initialTactics: Tactics,
    initialChoices: Choices,
    branches: readonly Branch[],
  ): Seq<Thm> => {
    let tactics = initialTactics;
    let choices = initialChoices;
    let brs = branches;
    for (;;) {
      checkInterrupt(context.limits);
      if (brs.length === 0) return cont(tactics, choices);
      const branch = brs[0];
      const head = branch.pairs[0];
      if (head === undefined) return backtrack(choices);
      const step =
        head.safe.length > 0
          ? safeStep(tactics, choices, brs)
          : branch.pairs.length === 1 && head.unsafe.length > 0
            ? unsafeStep(tactics, choices, brs)
            : undefined;
      if (step?.kind === "done") return step.result;
      if (step !== undefined) {
        tactics = step.tactics;
        choices = step.choices;
        brs = step.brs;
        continue;
      }
      if (branch.pairs.length > 1) {
        const below = branch.pairs[1];
        brs = [
          {
            pairs: [
              { safe: below.safe, unsafe: [...head.unsafe, ...below.unsafe] },
              ...branch.pairs.slice(2),
            ],
            lits: branch.lits,
            vars: branch.vars,
            lim: branch.lim,
          },
          ...brs.slice(1),
        ];
        continue;
      }
      return backtrack(choices);
    }
  };

  return prv(
    undefined,
    cons({ ntrl: state.trail.length, nbrs: initial.length, token: undefined }, undefined),
    initial,
  );
};
