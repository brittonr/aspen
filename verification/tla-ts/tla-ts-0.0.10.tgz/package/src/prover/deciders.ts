import { SmtParseError, TlaProverError } from "../errors";
import { decideIsabelle } from "./isabelle/decide";
import { decidePtl } from "./ptl/decide";
import { decideSmt } from "./smt/solver/solver";
import type { DecideOptions, Decision, Verdict } from "./verdict";
import { decideZenon } from "./zenon/decide";

const decideZ3 = (text: string, options: DecideOptions) => {
  try {
    return decideSmt(text, options);
  } catch (error) {
    if (error instanceof SmtParseError) throw new TlaProverError(error.message, error);
    throw error;
  }
};

export const DECIDERS: Record<string, (text: string, options: DecideOptions) => Verdict> = {
  smt: decideZ3,
  z3: decideZ3,
  zenon: (text, options) => decideZenon(text, options).verdict,
  isabelle: decideIsabelle,
  ls4: decidePtl,
};

export const decide = (prover: string, text: string, options: DecideOptions): Decision => {
  const start = performance.now();
  const verdict = DECIDERS[prover](text, options);
  return { verdict, timeUsedMs: performance.now() - start };
};
