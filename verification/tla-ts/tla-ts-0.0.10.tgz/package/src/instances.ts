import {
  getChildren,
  isLocallyResolved,
  type Bound,
  type BoundPattern,
  type Definition,
  type Expression,
  type Instance,
  type Module,
  type OperatorParam,
  type SourceLocation,
  type Theorem,
} from "./ast";
import { TlaSyntaxError } from "./errors";
import { getArity, getBoundNames, getPatternNames, isBefore, LOCAL_RESOLUTION } from "./resolve";

export const contextualApplications = new WeakSet<Expression>();

export const substitutionFrames = new WeakMap<Expression, Expression[]>();

export const withSubstitutionFrames = (expression: Expression, frames: Expression[]) => {
  if (frames.length === 0) return expression;
  const copy = { ...expression };
  if (contextualApplications.has(expression)) contextualApplications.add(copy);
  substitutionFrames.set(copy, [...frames, ...(substitutionFrames.get(expression) ?? [])]);
  return copy;
};

export const renameLocals = (
  expression: Expression,
  names: Map<string, string>,
  bound = new Set<string>(),
): Expression => {
  const mapped = mapChildren(expression, (child, childBound) =>
    renameLocals(
      child,
      names,
      childBound.length === 0 ? bound : new Set([...bound, ...childBound]),
    ),
  );
  if (mapped.kind === "Identifier" && isLocallyResolved(mapped) && !bound.has(mapped.name)) {
    return { ...mapped, name: names.get(mapped.name) ?? mapped.name };
  }
  if (mapped.kind === "Apply" && isLocallyResolved(mapped) && !bound.has(mapped.operator)) {
    return { ...mapped, operator: names.get(mapped.operator) ?? mapped.operator };
  }
  if (mapped.kind === "OperatorReference" && !bound.has(mapped.operator)) {
    return { ...mapped, operator: names.get(mapped.operator) ?? mapped.operator };
  }
  return mapped;
};

const mapBounds = (bounds: Bound[], map: (child: Expression) => Expression) =>
  bounds.map((bound) => ({ pattern: bound.pattern, set: map(bound.set) }));

const sourceNames = new WeakMap<Definition, string>();

export const getSourceName = (definition: Definition) =>
  sourceNames.get(definition) ?? definition.name;

const withSourceName = (definition: Definition, source: Definition) => {
  if (getSourceName(source) !== definition.name) sourceNames.set(definition, getSourceName(source));
  return definition;
};

export const mapDefinition = (
  definition: Definition,
  map: (child: Expression, bound: string[]) => Expression,
): Definition =>
  withSourceName(
    definition.kind === "Function"
      ? {
          ...definition,
          bounds: mapBounds(definition.bounds, (child) => map(child, [])),
          body: map(definition.body, getBoundNames(definition.bounds)),
        }
      : {
          ...definition,
          body: map(
            definition.body,
            definition.params.map((param) => param.name),
          ),
        },
    definition,
  );

export const mapChildren = (
  expression: Expression,
  map: (child: Expression, bound: string[]) => Expression,
): Expression => {
  const mapUnbound = (child: Expression) => map(child, []);
  switch (expression.kind) {
    case "Number":
    case "Decimal":
    case "String":
    case "Identifier":
    case "OperatorReference":
    case "ExceptAt":
      return expression;
    case "Apply":
      return { ...expression, args: expression.args.map(mapUnbound) };
    case "Lambda":
      return { ...expression, body: map(expression.body, expression.params) };
    case "And":
    case "Or":
      return { ...expression, operands: expression.operands.map(mapUnbound) };
    case "Prime":
    case "Unchanged":
    case "Enabled":
    case "Always":
    case "Eventually":
      return { ...expression, expression: mapUnbound(expression.expression) };
    case "If":
      return {
        ...expression,
        condition: mapUnbound(expression.condition),
        consequent: mapUnbound(expression.consequent),
        alternative: mapUnbound(expression.alternative),
      };
    case "Case":
      return {
        ...expression,
        arms: expression.arms.map((arm) => ({
          condition: mapUnbound(arm.condition),
          body: mapUnbound(arm.body),
        })),
        other: expression.other ? mapUnbound(expression.other) : undefined,
      };
    case "Let": {
      const names = expression.definitions.map((definition) => definition.name);
      return {
        ...expression,
        definitions: expression.definitions.map((definition) =>
          mapDefinition(definition, (child, bound) => map(child, [...names, ...bound])),
        ),
        body: map(expression.body, names),
      };
    }
    case "Forall":
    case "Exists":
    case "FunctionConstruction":
      return {
        ...expression,
        bounds: mapBounds(expression.bounds, mapUnbound),
        body: map(expression.body, getBoundNames(expression.bounds)),
      };
    case "UnboundedQuantifier":
      return { ...expression, body: map(expression.body, expression.names) };
    case "Choose":
      return {
        ...expression,
        set: expression.set ? mapUnbound(expression.set) : undefined,
        body: map(expression.body, getPatternNames(expression.pattern)),
      };
    case "SetEnumeration":
    case "Tuple":
      return { ...expression, elements: expression.elements.map(mapUnbound) };
    case "SetFilter":
      return {
        ...expression,
        bound: { pattern: expression.bound.pattern, set: mapUnbound(expression.bound.set) },
        predicate: map(expression.predicate, getPatternNames(expression.bound.pattern)),
      };
    case "SetMap":
      return {
        ...expression,
        bounds: mapBounds(expression.bounds, mapUnbound),
        expression: map(expression.expression, getBoundNames(expression.bounds)),
      };
    case "FunctionSet":
      return {
        ...expression,
        domain: mapUnbound(expression.domain),
        range: mapUnbound(expression.range),
      };
    case "Record":
    case "RecordSet":
      return {
        ...expression,
        fields: expression.fields.map((field) => ({ ...field, value: mapUnbound(field.value) })),
      };
    case "Except":
      return {
        ...expression,
        function: mapUnbound(expression.function),
        updates: expression.updates.map((update) => ({
          path: update.path.map((step) =>
            step.kind === "Index" ? { kind: "Index", args: step.args.map(mapUnbound) } : step,
          ),
          value: mapUnbound(update.value),
        })),
      };
    case "FunctionApplication":
      return {
        ...expression,
        function: mapUnbound(expression.function),
        args: expression.args.map(mapUnbound),
      };
    case "Bracket":
      return { ...expression, args: expression.args.map(mapUnbound) };
    case "FieldAccess":
      return { ...expression, record: mapUnbound(expression.record) };
    case "Product":
      return { ...expression, factors: expression.factors.map(mapUnbound) };
    case "BoxAction":
    case "AngleAction":
      return {
        ...expression,
        action: mapUnbound(expression.action),
        subscript: mapUnbound(expression.subscript),
      };
    case "WeakFairness":
    case "StrongFairness":
      return {
        ...expression,
        subscript: mapUnbound(expression.subscript),
        action: mapUnbound(expression.action),
      };
    case "Label":
      return { ...expression, body: mapUnbound(expression.body) };
    case "Subexpression":
      return {
        ...expression,
        selectors: expression.selectors.map((selector) =>
          "args" in selector ? { ...selector, args: selector.args.map(mapUnbound) } : selector,
        ),
      };
  }
};

interface Instantiation {
  params: OperatorParam[];
  substitutions: Map<string, Expression>;
  variables: Set<string>;
  getDefinition: (key: string) => Definition | undefined;
  getOuterDefinition: (name: string) => Definition | undefined;
  isParameterized: (key: string) => boolean;
  addDefinition: (source: string, name: string, create: (key: string) => Definition) => string;
  createName: (name: string) => string;
  frame?: Expression;
}

const LAMBDA_NAME = "LAMBDA";

type RewriteMode = "Normal" | "Enabled" | "Primed";

interface Rewrite {
  instantiation: Instantiation;
  substitutedNames: Set<string>;
  copies: Map<string, string>;
  mode: RewriteMode;
  modes: Map<RewriteMode, Rewrite>;
  bindings?: Map<string, Expression>;
}

const getSubstitutionName = (name: string) => `${name}@SUBSTITUTION`;

const isVariableAlias = (expression: Expression): boolean =>
  expression.kind === "Identifier" ||
  (expression.kind === "Tuple" && expression.elements.every(isVariableAlias));

const isBoundOnce = (replacement: Expression, instantiation: Instantiation) => {
  if (replacement.kind !== "Identifier") {
    return (
      !isVariableAlias(replacement) &&
      replacement.kind !== "OperatorReference" &&
      replacement.kind !== "Lambda" &&
      replacement.kind !== "Number" &&
      replacement.kind !== "String"
    );
  }
  const definition = isLocallyResolved(replacement)
    ? undefined
    : instantiation.getOuterDefinition(replacement.name);
  return (
    definition?.kind === "Operator" &&
    definition.params.length === 0 &&
    !isVariableAlias(definition.body)
  );
};

const getFreeNames = (expression: Expression, bound = new Set<string>()): string[] => {
  const name =
    expression.kind === "Identifier"
      ? expression.name
      : expression.kind === "Apply" || expression.kind === "OperatorReference"
        ? expression.operator
        : undefined;
  const names = name === undefined || bound.has(name) ? [] : [name];
  mapChildren(expression, (child, childBound) => {
    names.push(
      ...getFreeNames(child, childBound.length === 0 ? bound : new Set([...bound, ...childBound])),
    );
    return child;
  });
  return names;
};

const createRenamer = (rewrite: Rewrite) => {
  const renamed = new Map<string, string>();
  return (name: string) => {
    if (!rewrite.substitutedNames.has(name)) return name;
    const fresh = renamed.get(name) ?? rewrite.instantiation.createName(name);
    renamed.set(name, fresh);
    return fresh;
  };
};

const bindNames = (bound: Map<string, string>, names: string[], rename: (name: string) => string) =>
  new Map([...bound, ...names.map((name): [string, string] => [name, rename(name)])]);

const renamePattern = (pattern: BoundPattern, rename: (name: string) => string): BoundPattern =>
  pattern.kind === "Name"
    ? { kind: "Name", name: rename(pattern.name) }
    : { kind: "Tuple", names: pattern.names.map(rename) };

const renameBounds = (bounds: Bound[], rename: (name: string) => string) =>
  bounds.map((bound) => ({ pattern: renamePattern(bound.pattern, rename), set: bound.set }));

const renameParams = (definition: Definition, rename: (name: string) => string): Definition =>
  definition.kind === "Function"
    ? { ...definition, bounds: renameBounds(definition.bounds, rename) }
    : {
        ...definition,
        params: definition.params.map((param) => ({
          name: rename(param.name),
          arity: param.arity,
        })),
      };

const renameNames = (
  expression: Expression,
  bound: Map<string, string>,
  rename: (name: string) => string,
): Expression => {
  const getBoundName = (name: string) => bound.get(name) ?? name;
  switch (expression.kind) {
    case "Identifier":
      return { ...expression, name: getBoundName(expression.name) };
    case "Apply":
    case "OperatorReference":
      return { ...expression, operator: getBoundName(expression.operator) };
    case "Label":
      return { ...expression, params: expression.params.map(getBoundName) };
    case "Lambda":
      return { ...expression, params: expression.params.map(rename) };
    case "Let":
      return {
        ...expression,
        definitions: expression.definitions.map((definition) =>
          withSourceName(
            { ...renameParams(definition, rename), name: rename(definition.name) },
            definition,
          ),
        ),
      };
    case "Forall":
    case "Exists":
    case "FunctionConstruction":
    case "SetMap":
      return { ...expression, bounds: renameBounds(expression.bounds, rename) };
    case "UnboundedQuantifier":
      return { ...expression, names: expression.names.map(rename) };
    case "Choose":
      return { ...expression, pattern: renamePattern(expression.pattern, rename) };
    case "SetFilter":
      return {
        ...expression,
        bound: {
          pattern: renamePattern(expression.bound.pattern, rename),
          set: expression.bound.set,
        },
      };
    default:
      return expression;
  }
};

export const getEnabledVariableName = (name: string) => `${name}@ENABLED`;

const getMode = (rewrite: Rewrite, mode: RewriteMode) => rewrite.modes.get(mode) ?? rewrite;

const isVariable = (expression: Expression, rewrite: Rewrite, bound: Map<string, string>) =>
  expression.kind === "Identifier" &&
  !bound.has(expression.name) &&
  !isLocallyResolved(expression) &&
  rewrite.instantiation.variables.has(expression.name);

const getUnchangedVariables = (
  expression: Expression,
  rewrite: Rewrite,
  bound: Map<string, string>,
): string[] | undefined => {
  if (expression.kind === "Tuple") {
    const names = expression.elements.map((element) =>
      getUnchangedVariables(element, rewrite, bound),
    );
    return names.every((element) => element !== undefined) ? names.flat() : undefined;
  }
  if (expression.kind !== "Identifier") return undefined;
  if (isVariable(expression, rewrite, bound)) return [expression.name];
  const definition = isLocallyResolved(expression)
    ? undefined
    : rewrite.instantiation.getDefinition(expression.name);
  return definition?.kind === "Operator" && definition.params.length === 0
    ? getUnchangedVariables(definition.body, rewrite, new Map())
    : undefined;
};

const substituteInEnabled = (
  expression: Expression,
  rewrite: Rewrite,
  bound: Map<string, string>,
): Expression | undefined => {
  if (rewrite.mode === "Normal") return undefined;
  if (rewrite.mode === "Primed") {
    return isVariable(expression, rewrite, bound) && expression.kind === "Identifier"
      ? {
          kind: "Identifier",
          name: getEnabledVariableName(expression.name),
          location: expression.location,
        }
      : undefined;
  }
  if (expression.kind === "Prime") {
    return {
      ...expression,
      expression: substitute(expression.expression, getMode(rewrite, "Primed"), bound),
    };
  }
  if (expression.kind === "AngleAction") {
    const location = expression.location;
    return {
      kind: "And",
      operands: [
        substitute(expression.action, rewrite, bound),
        {
          kind: "Apply",
          operator: "#",
          args: [
            {
              kind: "Prime",
              expression: substitute(expression.subscript, getMode(rewrite, "Primed"), bound),
              location,
            },
            substitute(expression.subscript, rewrite, bound),
          ],
          location,
        },
      ],
      location,
    };
  }
  if (expression.kind !== "Unchanged") return undefined;
  const names = getUnchangedVariables(expression.expression, rewrite, bound);
  if (names === undefined) return undefined;
  return {
    kind: "And",
    operands: names.map((name) => ({
      kind: "Apply",
      operator: "=",
      args: [
        {
          kind: "Prime",
          expression: {
            kind: "Identifier",
            name: getEnabledVariableName(name),
            location: expression.location,
          },
          location: expression.location,
        },
        substitute({ kind: "Identifier", name, location: expression.location }, rewrite, bound),
      ],
      location: expression.location,
    })),
    location: expression.location,
  };
};

export const createLocalIdentifier = (name: string, location: SourceLocation): Expression => ({
  kind: "Identifier",
  name,
  location,
  resolution: LOCAL_RESOLUTION,
});

export const createLocalArguments = (params: OperatorParam[], location: SourceLocation) =>
  params.map((param) => createLocalIdentifier(param.name, location));

const getInstanceOperator = (
  key: string,
  params: OperatorParam[],
  arity: number,
  location: SourceLocation,
): Expression => {
  const names = Array.from({ length: arity }, (_, index) => `argument${index}`);
  return {
    kind: "Lambda",
    params: names,
    body: {
      kind: "Apply",
      operator: key,
      args: [
        ...createLocalArguments(params, location),
        ...names.map((name) => createLocalIdentifier(name, location)),
      ],
      location,
    },
    location,
  };
};

const getCopy = (rewrite: Rewrite, key: string) =>
  rewrite.instantiation.isParameterized(key) ? copyDefinition(rewrite, key) : undefined;

const substitute = (
  expression: Expression,
  rewrite: Rewrite,
  bound: Map<string, string>,
): Expression => {
  const recurse = (node: Expression) => substitute(node, rewrite, bound);
  const instantiation = rewrite.instantiation;
  const params = instantiation.params;
  const isFree = (name: string) => !bound.has(name) && !isLocallyResolved(expression);
  if (expression.kind === "Enabled" && rewrite.mode === "Normal") {
    return {
      ...expression,
      expression: substitute(expression.expression, getMode(rewrite, "Enabled"), bound),
    };
  }
  if (
    (expression.kind === "WeakFairness" || expression.kind === "StrongFairness") &&
    rewrite.mode === "Normal"
  ) {
    return {
      ...expression,
      subscript: recurse(expression.subscript),
      action: recurse(expression.action),
      enabled: substitute(
        expression.enabled ?? {
          kind: "AngleAction",
          action: expression.action,
          subscript: expression.subscript,
          location: expression.location,
        },
        getMode(rewrite, "Enabled"),
        bound,
      ),
    };
  }
  const enabled = substituteInEnabled(expression, rewrite, bound);
  if (enabled) return enabled;
  if (expression.kind === "Identifier" && isFree(expression.name)) {
    const replacement = instantiation.substitutions.get(expression.name);
    const bindings = rewrite.bindings;
    if (replacement && (bindings === undefined || !isBoundOnce(replacement, instantiation))) {
      return withSubstitutionFrames(replacement, [expression]);
    }
    if (replacement && bindings) {
      const name = getSubstitutionName(expression.name);
      bindings.set(name, replacement);
      return createLocalIdentifier(name, expression.location);
    }
    const copy = getCopy(rewrite, expression.name);
    if (copy === undefined) return expression;
    if (params.length === 0) return { ...expression, name: copy };
    const definition = instantiation.getDefinition(expression.name);
    if (definition && getArity(definition) > 0) {
      return getInstanceOperator(copy, params, getArity(definition), expression.location);
    }
    return {
      kind: "Apply",
      operator: copy,
      args: createLocalArguments(params, expression.location),
      location: expression.location,
    };
  }
  if (expression.kind === "Apply" && isFree(expression.operator)) {
    const args = expression.args.map(recurse);
    const replacement = instantiation.substitutions.get(expression.operator);
    const isContextual =
      instantiation.substitutions.size > 0 ||
      params.length > 0 ||
      contextualApplications.has(expression);
    const markContextual = (rewritten: Expression) => {
      if (isContextual) contextualApplications.add(rewritten);
      return rewritten;
    };
    if (replacement?.kind === "Identifier" || replacement?.kind === "OperatorReference") {
      const operator = replacement.kind === "Identifier" ? replacement.name : replacement.operator;
      return markContextual({
        ...expression,
        operator,
        args,
        resolution: replacement.kind === "Identifier" ? replacement.resolution : undefined,
      });
    }
    if (replacement?.kind === "Apply") {
      return markContextual({
        ...expression,
        operator: replacement.operator,
        args: [...replacement.args, ...args],
        resolution: replacement.resolution,
      });
    }
    if (replacement?.kind === "Lambda") {
      return {
        kind: "Let",
        definitions: [
          {
            kind: "Operator",
            name: LAMBDA_NAME,
            params: replacement.params.map((name) => ({ name, arity: 0 })),
            body: replacement.body,
            isLocal: true,
            isRecursive: false,
            location: replacement.location,
          },
        ],
        body: {
          ...expression,
          operator: LAMBDA_NAME,
          args,
          resolution: LOCAL_RESOLUTION,
        },
        location: expression.location,
      };
    }
    if (replacement) {
      throw new TlaSyntaxError(
        `The operator ${expression.operator} can only be substituted by an operator at line ${expression.location.line}, column ${expression.location.column}`,
      );
    }
    const copy = getCopy(rewrite, expression.operator);
    if (copy === undefined) return markContextual({ ...expression, args });
    return {
      ...expression,
      operator: copy,
      args: [...createLocalArguments(params, expression.location), ...args],
    };
  }
  if (expression.kind === "OperatorReference" && isFree(expression.operator)) {
    const copy = getCopy(rewrite, expression.operator);
    if (copy === undefined) return expression;
    const definition = instantiation.getDefinition(expression.operator);
    if (params.length > 0 && definition) {
      return getInstanceOperator(copy, params, getArity(definition), expression.location);
    }
    return { ...expression, operator: copy };
  }
  const rename = createRenamer(rewrite);
  const mapped = mapChildren(expression, (child, names) =>
    names.length === 0
      ? recurse(child)
      : substitute(child, rewrite, bindNames(bound, names, rename)),
  );
  return renameNames(mapped, bound, rename);
};

const withInstanceParams = (
  definition: Definition,
  params: OperatorParam[],
  location: SourceLocation,
): Definition => {
  if (params.length === 0) return definition;
  if (definition.kind === "Operator") {
    return { ...definition, params: [...params, ...definition.params] };
  }
  return {
    kind: "Operator",
    name: definition.name,
    params,
    body: {
      kind: "Let",
      definitions: [definition],
      body: createLocalIdentifier(definition.name, location),
      location,
    },
    isLocal: definition.isLocal,
    isRecursive: false,
    location: definition.location,
  };
};

const copyDefinition = (rewrite: Rewrite, key: string): string => {
  const cached = rewrite.copies.get(key);
  if (cached !== undefined) return cached;
  const instantiation = rewrite.instantiation;
  const definition = instantiation.getDefinition(key);
  if (!definition) return key;
  return instantiation.addDefinition(key, definition.name, (copyKey) => {
    rewrite.copies.set(key, copyKey);
    const rename = createRenamer(rewrite);
    const bindings = new Map<string, Expression>();
    const bodyRewrite =
      definition.kind === "Operator" && rewrite.mode === "Normal"
        ? { ...rewrite, bindings }
        : rewrite;
    const mapped = renameParams(
      mapDefinition(definition, (child, bound) =>
        substitute(child, bodyRewrite, bindNames(new Map(), bound, rename)),
      ),
      rename,
    );
    const body: Expression =
      mapped.kind !== "Operator" || bindings.size === 0
        ? mapped.body
        : {
            kind: "Let",
            definitions: [...bindings].map(([name, replacement]): Definition => ({
              kind: "Operator",
              name,
              params: [],
              body: replacement,
              isLocal: true,
              isRecursive: false,
              location: replacement.location,
            })),
            body: mapped.body,
            // TLC has no such LET, so the call stack it prints has no position for it.
            location: { line: mapped.body.location.line, column: mapped.body.location.column },
          };
    const frame = instantiation.frame;
    // TLC's call stack holds the SubstInNode an instance puts around each definition it copies.
    if (frame)
      substitutionFrames.set(body, [frame, ...(substitutionFrames.get(definition.body) ?? [])]);
    return withInstanceParams({ ...mapped, body }, instantiation.params, definition.location);
  });
};

export const createInstantiation = (instantiation: Instantiation) => {
  const modes = new Map<RewriteMode, Rewrite>();
  const substitutedNames = new Set(
    [...instantiation.substitutions.values()].flatMap((expression) => getFreeNames(expression)),
  );
  const createRewrite = (mode: RewriteMode): Rewrite => {
    const created = {
      instantiation,
      substitutedNames,
      copies: new Map<string, string>(),
      mode,
      modes,
    };
    modes.set(mode, created);
    return created;
  };
  const rewrite = createRewrite("Normal");
  createRewrite("Enabled");
  createRewrite("Primed");
  return {
    getKey: (key: string) => getCopy(rewrite, key) ?? key,
    getQualifiedKey: (key: string) => {
      const copy = getCopy(rewrite, key);
      if (copy !== undefined) return copy;
      const definition = instantiation.getDefinition(key);
      if (!definition) return key;
      return instantiation.addDefinition(key, definition.name, () =>
        withInstanceParams(definition, instantiation.params, definition.location),
      );
    },
  };
};

const hasLetInstance = (expression: Expression): boolean =>
  (expression.kind === "Let" && expression.instances !== undefined) ||
  getChildren(expression).some(hasLetInstance);

const expandLetInstances = (
  expression: Expression,
  instantiate: (instance: Instance, lets: Definition[]) => Definition[],
  lets: Definition[],
): Expression => {
  const visibleLets = expression.kind === "Let" ? [...lets, ...expression.definitions] : lets;
  const mapped = mapChildren(expression, (child) =>
    expandLetInstances(child, instantiate, visibleLets),
  );
  if (mapped.kind !== "Let" || !mapped.instances) return mapped;
  const definitions = mapped.instances.reduce((current, instance) => {
    const position = current.findIndex((definition) =>
      isBefore(instance.location, definition.location),
    );
    const index = position === -1 ? current.length : position;
    return [
      ...current.slice(0, index),
      ...instantiate(instance, visibleLets),
      ...current.slice(index),
    ];
  }, mapped.definitions);
  return { ...mapped, definitions };
};

const getUnnamedStatement = (theorem: Theorem) =>
  theorem.name === undefined && theorem.statement.kind !== "AssumeProve"
    ? theorem.statement
    : undefined;

export const withLetInstances = (
  module: Module,
  instantiate: (instance: Instance, lets: Definition[]) => Definition[],
): Module => {
  const hasLetInstances =
    module.definitions.some((definition) => hasLetInstance(definition.body)) ||
    module.assumptions.some((assumption) => hasLetInstance(assumption.expression)) ||
    module.theorems.some((theorem) => {
      const statement = getUnnamedStatement(theorem);
      return statement !== undefined && hasLetInstance(statement);
    });
  if (!hasLetInstances) return module;
  return {
    ...module,
    definitions: module.definitions.map((definition) =>
      mapDefinition(definition, (child) => expandLetInstances(child, instantiate, [])),
    ),
    assumptions: module.assumptions.map((assumption) => ({
      ...assumption,
      expression: expandLetInstances(assumption.expression, instantiate, []),
    })),
    theorems: module.theorems.map((theorem) => {
      const statement = getUnnamedStatement(theorem);
      return statement === undefined
        ? theorem
        : { ...theorem, statement: expandLetInstances(statement, instantiate, []) };
    }),
  };
};
