; Read-only source extraction. Output is a campaign index, not acceptance evidence.
(define (read-text path)
  (define port (open-input-file path))
  (define text (read-port-to-string port))
  (close-input-port port)
  text)
(define (save-text path text)
  (with-output-to-file path (lambda () (display text))))
(define (starts? text prefix)
  (equal? (car (split-many text prefix)) ""))
(define (sorted-unique values) (pi-sort (pi-unique values) string<?))
(define (flatten lists)
  (if (null? lists) '() (append (car lists) (flatten (cdr lists)))))
(define (field-or record key fallback)
  (if (hash-contains? record key) (hash-ref record key) fallback))
(define (inline-values text)
  (define (select rest take? values)
    (if (null? rest) (reverse values)
        (select (cdr rest) (not take?)
                (if take? (cons (car rest) values) values))))
  (select (split-many text "`") #f '()))
(define (candidate-path? text)
  (or (starts? text "src/") (starts? text "crates/")
      (starts? text "tests/") (starts? text "checks/")
      (starts? text "pilots/") (starts? text "config/")))
(define (command? text)
  (or (starts? text "cargo ") (starts? text "nix ")
      (starts? text "cairn ") (starts? text "molten ")
      (starts? text "nickel ") (starts? text "scripts/")
      (starts? text "bash ")))
(define (requirement-blocks text)
  (define parts (split-many text "### Requirement:"))
  (if (null? parts) '() (cdr parts)))
(define (requirement-id block)
  (define parts (split-many block "r["))
  (if (null? (cdr parts)) "UNMARKED"
      (car (split-many (car (cdr parts)) "]"))))
(define (requirement-title block)
  (pi-string-trim (car (pi-lines block))))
(define (requirement-text block)
  (pi-string-trim (car (split-many block "#### Scenario:"))))
(define (requirement-row path kind owner dependencies paths commands evidence blocker block)
  (hash 'requirement (requirement-id block)
        'title (requirement-title block)
        'normative_text (requirement-text block)
        'source path 'kind kind 'owner owner
        'implementation_path_candidates (sorted-unique (append paths (field-or source-markers (requirement-id block) '())))
        'dependencies dependencies
        'acceptance_commands commands
        'evidence_path evidence
        'blocker blocker 'acceptance_state "UNKNOWN"))
(define root (pi-arg-ref 0))
(define output (pi-arg-ref 1))
(define source-revision-index 2)
(define source-revision (pi-arg-ref source-revision-index))
(define changes (hash-ref (pi-json-read (read-text (string-append output "/changes.json"))) 'changes))
(define (index-marker-event index event)
  (if (not (equal? (hash-ref event 'type) "match")) index
      (let* ((details (hash-ref event 'data))
             (text (hash-ref (hash-ref details 'lines) 'text))
             (path (hash-ref (hash-ref details 'path) 'text))
             (position (string-append path ":" (number->string (inexact->exact (hash-ref details 'line_number))))))
        (define ids
          (flatten
           (map (lambda (role)
                  (map (lambda (part) (car (split-many part "]")))
                       (cdr (split-many text role))))
                '("r[impl " "r[verify "))))
        (define (insert rest current)
          (if (null? rest) current
              (insert (cdr rest)
                      (hash-insert current (car rest)
                                   (cons position (field-or current (car rest) '()))))))
        (insert ids index))))
(define (index-marker-lines lines index)
  (if (null? lines) index
      (index-marker-lines (cdr lines)
        (if (equal? (pi-string-trim (car lines)) "") index
            (index-marker-event index (pi-json-read (car lines)))))))
(define source-markers
  (index-marker-lines (pi-lines (read-text (string-append output "/source-markers.jsonl"))) (hash)))
(define baseline-commands
  '("nix develop -c cargo test --workspace --locked"
    "nix develop -c cargo nextest run --profile ci"
    "nix develop -c cargo fmt --all -- --check"
    "nix develop -c cargo clippy --workspace --all-targets -- -D warnings"
    "cargo octet check --artifact-dir target/octet"
    "cargo run -- test octet gate --artifacts target/octet --profile strict-ci --receipt-out target/octet/gate-receipt.preserves"
    "cairn validate --root . --strict"
    "nix flake check -L"))
(define branch-blocker "B1: developer requires origin/main, but Molten uses a separate molten history. No implementation or integration route is authorized.")
(define (change-doc change suffix)
  (define path (string-append root "/" (hash-ref change 'path) "/" suffix))
  (if (path-exists? path) (read-text path) ""))
(define (change-rows change)
  (define name (hash-ref change 'name))
  (define docs (string-append (change-doc change "proposal.md") "\n"
                             (change-doc change "design.md") "\n"
                             (change-doc change "tasks.md")))
  (define inline (inline-values docs))
  (define paths (sorted-unique (filter candidate-path? inline)))
  (define commands (sorted-unique (filter command? inline)))
  (define dependencies (field-or (hash-ref change 'metadata) 'depends_on '()))
  (define (rows path)
    (map (lambda (block)
           (requirement-row path "active-delta" (string-append "Molten / " name)
                            dependencies paths (sorted-unique (append commands baseline-commands))
                            (string-append ".cairn/changes/" name "/evidence/ (required, not yet observed)")
                            branch-blocker block))
         (requirement-blocks (read-text (string-append root "/" path)))))
  (flatten (map rows (hash-ref change 'delta_specs))))
(define active-rows (flatten (map change-rows changes)))
(define accepted-root (string-append root "/.cairn/specs"))
(define accepted-dirs (pi-sort (filter is-dir? (read-dir accepted-root)) string<?))
(define (accepted-rows-for dir)
  (define path (string-append dir "/spec.md"))
  (if (not (path-exists? path)) '()
      (map (lambda (block)
             (requirement-row (string-replace path (string-append root "/") "")
                              "accepted-regression-contract"
                              (string-append "Molten / " (car (reverse (split-many dir "/"))))
                              '() '() baseline-commands
                              "Repository-owned subsystem receipts plus current release bundle. Exact per-requirement acceptance remains unverified."
                              "B1 plus no current per-requirement acceptance mapping. Historical receipts and trace markers are not current acceptance."
                              block))
           (requirement-blocks (read-text path)))))
(define accepted-rows (flatten (map accepted-rows-for accepted-dirs)))
(define summary
  (hash 'changes (length changes) 'active_requirements (length active-rows)
        'accepted_requirements (length accepted-rows)
        'unmarked_active (length (filter (lambda (row) (equal? (hash-ref row 'requirement) "UNMARKED")) active-rows))
        'unmarked_accepted (length (filter (lambda (row) (equal? (hash-ref row 'requirement) "UNMARKED")) accepted-rows))))
(define (require-check passed label) (if passed #t (error label)))
(require-check (equal? (requirement-id "a\nr[molten.example] rule") "molten.example") "positive requirement parsing")
(require-check (equal? (requirement-id "a rule without a marker") "UNMARKED") "unmarked requirements stay explicit")
(require-check (not (command? "src/example.rs")) "paths cannot become commands")
(require-check (candidate-path? "src/example.rs") "source path extraction")
(define marker-fixture
  (hash 'type "match"
        'data (hash 'lines (hash 'text "r[impl molten.example]")
                    'path (hash 'text "src/example.rs") 'line_number 1.0)))
(require-check (equal? (hash-ref (index-marker-event (hash) marker-fixture) "molten.example")
                       '("src/example.rs:1")) "marker lines use integer positions")
(require-check (equal? (index-marker-event (hash) (hash 'type "begin")) (hash))
               "non-match events cannot become source evidence")
(define manifest (pi-json-read (read-text (string-append output "/manifest.json"))))
(define assigned (flatten (map (lambda (group) (hash-ref group 'changes)) (hash-ref manifest 'groups))))
(define change-names (map (lambda (change) (hash-ref change 'name)) changes))
(require-check (equal? (sorted-unique assigned) (sorted-unique change-names)) "every active change has a group")
(require-check (= (length assigned) (length changes)) "each change has exactly one group")
(require-check (= (hash-ref manifest 'active_changes) (length changes)) "change count matches the manifest")
(require-check (= (hash-ref manifest 'active_requirements) (length active-rows)) "delta count matches the manifest")
(require-check (= (hash-ref manifest 'accepted_requirements) (length accepted-rows)) "accepted count matches the manifest")
(require-check (equal? (hash-ref manifest 'source_revision) source-revision) "source revision matches the manifest")
(save-text (string-append output "/requirements.json")
           (pi-json-write/pretty (hash 'schema "molten.completion.discovery.v1"
                                      'source_revision source-revision
                                      'scope "All current active deltas and accepted specification requirements. Release obligations are recorded separately."
                                      'non_claim "Extraction does not verify implementation, acceptance, or ownership. Commands and paths are source candidates."
                                      'summary summary
                                      'active active-rows 'accepted accepted-rows)))
(println (pi-json-write summary))
