You are a subagent. Don't run memo.

Goal: audit the frozen Tracey heading-marker correction. Return a concrete source-backed defect or a bounded no-finding report.
Root: /home/brittonr/git/OnixResearch/aspen/.pi/molten-completion/implementation-tracey
Parent: 077d7eacfaebf9cc0a59e32879d1792376375809
Source manifest: /home/brittonr/git/OnixResearch/aspen/.pi/molten-completion/logs/tracey-heading-candidate-inputs.b3

Use only read, grep, find, and ls. Do not run commands, edit files, delegate, change lifecycle state, publish, or grant acceptance.
Read required guidance within this budget. Use Simple English.
Budget: five minutes, twelve reads/searches, one report of at most 400 words.

Inspect tools/tracey/definition_marker.rs, definition_marker_tests.rs, both inherited_debt scripts, and their input tests.
Compare the accepted CAS heading syntax in .cairn/specs/object-store-cas-coordinator/spec.md.

Two distinct risks:
1. False definitions: prose, examples, role references, malformed wrappers, ambiguous headings, or version text must not manufacture a heading definition.
2. Lost obligations: the four CAS identifiers must retain exact identity and location. Existing standalone-marker behavior, unknown-reference rejection, and duplicate rejection for baseline identifiers must remain intact.

Do not demand arbitrary Markdown grammar or global uniqueness outside the existing contract.
Do not propose moving active definitions into accepted specs, marker removal, or baseline growth to make a gate pass.
All arithmetic, runtime, lifecycle, and effect authority remain outside this parser.

Report each finding with severity, exact function, discriminating input, and a test that exposes it.
Otherwise name inspected boundaries and missing evidence. Your source review cannot establish Nix acceptance or validate archived bytes.
