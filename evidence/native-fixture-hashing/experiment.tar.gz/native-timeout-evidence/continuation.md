# Native timeout continuation

## Current result

The native timeout remains unresolved. No product repair is complete.
Two instrumented default-profile tests time out during their first executable-content-reference call, before cohort admission or process startup.
The repaired Cargo candidate remains `89f63d71e3f7bf45b141be0e6772470f5bb9908c`.

## Source and execution boundary

The dedicated worktree is `/home/brittonr/.local/share/molten-completion/implementation-native-fixture`.
Its branch is `completion/native-fixture-inputs-20260913`.
It was created from freshly fetched `origin/molten`, then fast-forwarded to the Cargo candidate.
The diagnostic changed only `tests/nativesystemextension/support.rs` to print read/hash timing.
The temporary source is archived, and the worktree is restored to clean `89f63d71e` after both rounds.
Product code, assertions, compiler selection, profiles, producer pins, and time limits remain unchanged.
Original source, the exact temporary diff, and input hashes remain in the primary campaign logs and their emergency copy.
The first restore check passes all content hashes but fails the archive's modification-time comparison.
After restoring the helper's archived timestamp, all original hashes and the full archive comparison pass.
Both restore logs remain intact. The CI JUnit copy also passes byte comparison.

Task 1389 rebuilds the missing native binary in 4m 08s, exit 0.
The separately recorded cold-build allocation was 24 minutes with two Cargo jobs.
Task 1393 runs only the two affected native cases with the default profile and two test threads.
Both time out near 60 seconds, exit 100. Six native cases are not selected.
Both read a 927,552,568-byte executable. The reads take 568,238 and 652,434 microseconds.
Neither reaches the marker after its first `content_ref_from_bytes` call.
That production function calls `blake3::hash` and formats its content reference.
These observations exclude later admission and process operations for these default-profile samples.
Reusing one observation alone is not a validated repair because the first hash already exceeds the concurrent default bound.

Task 1425 runs one instrumented CI case after an unexpected 3m 26s rebuild.
The fixture is absent again during that build. The cause of its removal is not established.
The test times out at 180.080 seconds, exit 100. Seven native cases are not selected.
Four completed hash calls take 41,339,725; 39,463,119; 40,043,028; and 42,897,739 microseconds.
The fifth hash has started when the timeout occurs. Each completed file read takes less than half a second.

Task 1445 samples only the matching test process, with an exact executable, test name, and worktree check.
The test thread is runnable at both samples. Its recorded CPU time rises from 47 to 66 seconds over a 20-second sample interval.
This supports substantial CPU work in the test. It is not a stack trace or a complete timing breakdown.
Tasks 1432 and 1442 find no test process while compilation is still underway. They supply no runtime sample.

The unchanged Cargo feature graph selects BLAKE3 1.8.5 with `pure` through Basalt's vendored `ucan-core`.
The source is `vendor/ucan/crates/ucan-core/Cargo.toml:18` at Basalt revision `89675cd4f585f837323c049e4a25f7b94c903038`.
BLAKE3's `Cargo.toml.orig:75-85` says this feature forces a pure-Rust fallback instead of the default x86_64 assembly implementations.
The builds use the unoptimized test profile. No alternate build setting or producer change has been tested.
The Cargo and Rust version output still matches the repaired Cargo and original May compiler cohort.

## Independent reads

Runtime reader task 1330 completes after thirteen reads/searches, exit 0.
The coordinator confirms that bounded-exec revision `29dac88ecded94457572db3fdfaaaab95fa91525` starts its execution timer after spawn.
Worker-result joins also lack their own timer. No measured failure reaches these operations.
The observations do not prove a producer-contract violation or explain the measured timeout.

Tracey heading reader task 1391 completes after twelve reads/listings, exit 0.
It reports no concrete parser defect within the requested contract.
Its two passes are correlated passes by one reader, not two independent reviews.
The account-routing extension provides a new mechanism after the earlier provider-startup failures.
The coordinator verifies the parser, positive/negative fixtures, unknown-reference guard, baseline duplicate check, and unchanged source identity from `5c71c5b4`.
The report has two location errors: `aspen.cas.boundary` is at line 46, not 45; `aspen.cas.verification` is at line 66, not 65.
The other CAS locations are lines 9 and 27. These corrections do not change the four exact IDs or the bounded parser result.
Neither reader grants lifecycle approval or Nix acceptance.

## Evidence-write blocker

Updating the primary campaign report fails with `EDQUOT: unknown error, write`.
The prior 3,523-byte report remains intact.
Task 1414 reports zero available bytes on `datapool/git`.
The dataset quota remains 858,993,459,200 bytes; refquota remains zero.
No unrelated files were deleted and no quotas or cache settings changed.
This directory is an emergency evidence copy on the home filesystem, outside every disposable worktree.
It does not replace or modify the primary campaign's historical records.
Git-backed evidence updates were blocked by the quota.
Task 1470 later observes 271,889,858,560 available bytes on the Git dataset.
Space returned without task-owned cleanup or quota changes. Storage is no longer an established blocker.

## Remaining work

The allocated diagnostic rounds are complete. No further unchanged acceptance retry is allocated.
The observed hash cost is a current setup bottleneck. Its full build-setting and scheduling causes remain unproven.
A repair must preserve exact BLAKE3 identities, producer revisions, compiler cohort, test assertions, fresh state, and runtime/nextest bounds.
Repeated observations and unnecessary observation of the native binary in shell-error cases are distinct from the first-call cost.
Do not adopt a global cache or assume that removing repetition alone resolves the default profile.
Storage is available again. A new candidate will optimize only BLAKE3 in the existing Cargo development/test build.
It keeps the `pure` feature, dependency revision, compiler cohort, runtime behavior, and nextest profiles unchanged.
This is a repository-owned Cargo configuration change, not a command-local acceptance override.
No test, assertion, or repeated scenario will be removed.
The first validation round uses the unchanged default nextest command with an eight-minute limit and two test threads.
A passing round permits the existing CI profile and scoped Clippy/format/lifecycle checks.
A failed round requires a concrete correction or new evidence before another attempt.

No sync, archive, integration, push, deployment, or worktree removal is authorized by these observations.
Cargo and F12 acceptance tasks remain open.
