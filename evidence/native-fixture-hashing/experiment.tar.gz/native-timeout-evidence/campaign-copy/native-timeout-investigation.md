# Native-process timeout investigation

## Goal and completion evidence

Restore the native integration suite under its existing nextest profiles and time limits.
Keep all failure scenarios, isolation, assertions, compiler choices, producer pins, and runtime limits intact.
A scoped repair needs observed setup/process timing, positive and negative controls, both nextest profiles, Clippy, and lifecycle checks.
A source review or a faster isolated case does not prove a complete suite pass.

Base candidate: `89f63d71e3f7bf45b141be0e6772470f5bb9908c`.
The prior CI run executed 1,646 tests with 1,645 passes and one 180-second timeout.
The prior default run includes one 60-second timeout and two outer-deadline terminations.
These logs remain the before-change evidence. They do not prove a cause for the durations.

## Approach registry

| Family | Mechanism | Evidence needed | State |
| --- | --- | --- | --- |
| Fixture setup | Repeated executable observation or admission work consumes the test budget | Separate read, content-identity, admission, and whole-case observations | Active coordinator pass |
| Runtime process | Child startup, pipe exchange, deadline enforcement, or teardown waits consume the budget | Independent source references and a discriminating process observation | Bounded read-only review |
| Host/build state | Missing build artifacts, cache waits, or host contention alter the observation | Current artifact inventory and command-local resource observations | Active prerequisite check |

The current source creates a new cohort for every negative scenario.
The investigation must preserve fresh journals and value stores. Cloning a cohort can share mutable state and is not an admitted repair.
No global cache, weaker timeout, ignored test, skipped scenario, synthetic executable identity, or metadata workaround is permitted.
No performance gain is claimed before current measurements.

## Budget and authority

The missing executable requires a separate build prerequisite before measurement.
One build-only command has a 24-minute cold-build allocation and two Cargo jobs.
It uses the unchanged compiler, wrapper, build profile, and shared target path.
This is not another unchanged nextest acceptance retry.
After the build, one initial measurement round has an eight-minute command limit and two Cargo build jobs.
The runtime reader has one five-minute round, at most sixteen reads/searches, and at most 450 output words.
It cannot edit, run commands, access credentials, delegate, publish, or change lifecycle state.
The coordinator is the only source writer and lifecycle operator.
Further execution needs a recorded source correction or a new discriminating mechanism.
Allowed outcomes are a validated scoped result, an exact blocker, or an exhausted allocation.

The previously used fixture executable is absent from the shared target directory.
This prevents direct reuse of that binary for timing. No cause of its removal is asserted here.
The fetched `origin/molten` remains `87c289bf68c45987d2d79572de1ca458a7ca662f`.
The Git dataset has little available space. No unrelated data or quota changes are authorized.
The dedicated fixture worktree will use `/home/brittonr/.local/share/molten-completion/implementation-native-fixture` on the home filesystem.
Campaign evidence stays under the primary checkout's `.pi/molten-completion/`.
This fixture-only investigation does not change public behavior or create a new lifecycle contract.
Cargo and F12 acceptance tasks stay open.
