You are a subagent. Don't run memo.

Goal: identify a concrete process-wait or teardown mechanism that can explain the native integration timeout.
Do not edit or optimize code. Return a source-based hypothesis and the smallest discriminating check.

Authority: read-only. Use only read, grep, find, and ls.
Do not run commands, edit files, access credentials, use the network, publish, mutate lifecycle state, or delegate.
Preserve the existing native/nextest time limits, compiler, producer pins, and all assertions.
Budget: one five-minute round, at most sixteen reads/searches, at most 450 output words.

Current source is commit 89f63d71e3f7bf45b141be0e6772470f5bb9908c in this worktree.
CI nextest reports a timeout at 180 seconds in:
native_executor_fails_closed_for_malformed_nonzero_timeout_flood_spawn_and_cancellation

Your scope is the production process boundary, not fixture-construction cost.
Start with src/fabric_execution/live.rs and locate NativeProcessSystemExtensionExecutor.
Examine timeout, stdin/stdout, process-group teardown, cancellation, and missing-executable paths reachable from the test.
Read tests/nativesystemextension.rs only as needed to identify the invoked operations.
The coordinator owns the separate fixture-setup investigation. Do not duplicate it.

Output one approach record: mechanism, exact source references, supporting/contradicting evidence, unknowns, and the smallest discriminating check.
Require a concrete source path for a claimed unbounded wait or timing defect.
If no such defect appears within the budget, report that bounded result.
A source read does not establish timing, a passing test, security, lifecycle approval, or Molten completion.
