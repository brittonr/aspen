You are a subagent. Don't run memo.

Goal: audit one bounded Molten source-hardening candidate. Do not implement it.
The coordinator is checking an uncommitted merge in:
/home/brittonr/.local/share/molten-completion/implementation-combined

The selected Octet source is immutable:
/nix/store/fmnq5i0razc5bdmncvfw331lh047100g-source
Its `src/safety/no_panic.rs` requires production errors instead of panic macros.
The current catalog flags eight distinct guarded `unreachable!` sites across two Molten files.
They occur twice through library and library-test targets. No reachable public panic is established.

Candidate: make the four private encoding helpers and their private dispatcher return the existing `Result<IOValue>`.
Propagate errors through `canonical_replica_message`, whose public signature already returns `Result`.
Replace their wrong-message fallbacks with explicit `MoltenError::invalid_harness` errors.
Replace the four private transition dispatch fallbacks with the same existing error type.
Keep message variants, valid-input paths, canonical records, byte identities, handlers, and public APIs unchanged.
No suppressions, producer edits, dependency changes, new ports, or policy weakening are allowed.

Primary source:
- src/fabric_consistency/raft/canonical.rs
- src/fabric_consistency/raft/transition/message.rs
- Related caller and test files needed to assess this candidate.

Find a concrete semantic or ownership defect in this candidate, or explain its bounded compatibility case.
Compare it with direct exhaustive matching only if that changes your verdict.
Name required positive and negative cases, including exact bytes and unchanged state on helper rejection.
Check whether public callers can reach those wrong-message fallbacks today. Do not infer reachability from lint counts.
Return at most 450 words with source paths, line numbers, unresolved facts, and a verdict of validated, refuted, or exhausted.
A validated design is not execution evidence, lifecycle approval, or strict acceptance.

Authority: read-only. Use read, grep, find, and ls only.
Do not run commands, write files, inspect credentials, access the network, delegate, approve lifecycle actions, or publish anything.
Source is frozen during active checks. Do not request edits from another agent.
Budget: one five-minute round and at most twelve file/search tool calls. Stop at the bound.
Use short, clear English. Preserve exact identifiers and diagnostics.
