# Combine the checked native and retry candidates

## Goal and authority

Preserve both candidate histories in one dedicated worktree, then obtain fresh checks over their combined source.
The inputs are `55eecf8a158da4ee0db89c80f6f73175b66db99f` and `06837c6a619d0a21491dd0830119da123d2ece72`.
A fresh fetch still reports `origin/molten` at `87c289bf68c45987d2d79572de1ca458a7ca662f`.
The coordinator owns all source and lifecycle writes. Workers remain read-only.

The completion evidence is preserved ancestry, a reviewed merge diff, focused before/after tests, public positive/negative read-back, and fresh combined-source checks.
This round does not grant strict Octet acceptance, lifecycle completion, release authority, or permission to weaken any gate.
The primary HEAD, staged ZIP/audit blobs, producer/compiler pins, nextest profiles, accepted specifications, and historical receipts stay intact.

## Budgets

Each ordinary check has an eight-minute deadline and two Cargo jobs. Nextest uses two test threads.
A cold-build timeout can justify one separately recorded cold allocation, but no active deadline changes.
The prior full-Nix run ended during Cargo 1.95 dependency compilation after its eight-minute deadline.
This combined-source round allocates one 24-minute full-Nix cold run with two build cores and one Nix job.
It changes no runtime limit, nextest profile, compiler pin, producer input, or already active deadline.
The attribution reader gets five minutes, sixteen reads/searches, and a 500-word report.
A separate Raft-remedy reader gets five minutes, twelve reads/searches, and a 450-word report.
Both readers remain read-only. No recursive delegation is permitted.
Only the coordinator can run commands, create the worktree, merge source, or commit.
No sync, archive, deployment, force-push, pull request, or worktree removal occurs without its required evidence and authority.

## Approach registry

| Family | Mechanism | Claim | State | Next check |
| --- | --- | --- | --- | --- |
| Candidate composition | Preserve both Git parents and run the real affected tests | Domain-bound retry evidence works with the repaired Cargo and native hashing build | Validated bounded result | Both nextest profiles pass 1,648 tests. Public report bytes match the retry parent. Strict and Nix gates still fail. |
| Producer and source attribution | Read diagnostics and the selected Octet contract | Separate source attribution from reachable defects and producer ownership | Validated bounded result | The source guard already rejects empty peers. No reachable division defect or producer bug is established. |
| Existing remediation capability | Run the public remediation planner on preserved artifacts | Obtain a canonical, non-accepting inventory without a new analyzer | Validated inventory | The native-parent planner receipt exists. It does not establish combined-source acceptance. |
| Raft panic error paths | Review existing-Result fallbacks against exhaustive callers | Preserve valid bytes and transitions without panic macros | Validated design only | The read-only review found no concrete incompatibility. Complete variant fixtures and actual source-gate checks remain necessary. |

Warning-only process success, artifact import, a dry-run sync, or a historical clean claim cannot establish acceptance.
A source-scope diagnostic is not automatically a semantic defect or a producer bug.
Allowed terminal states are validated bounded result, exact blocker, or exhausted budget with retained evidence.

## Recorded boundaries

The combined strict receipt denies 6,810 warnings and 330 critical findings.
The full-Nix cold run completes Cargo 1.95 compilation, then rejects the six unresolved F12 and ChaosControl references.
No runtime or nextest deadline changes occur.

Eighteen full Pueue export attempts return `{}` after the corresponding task entries disappear.
Direct logs, recorded exits, canonical receipts, and JUnit data remain.
The final result of the formatting/metadata/Cairn bundle is unavailable. Its structured outputs remain separate evidence.
The coordinator does not rerun completed tests only to replace missing terminal receipts.
The cause of the missing entries remains unknown.

The separate validation report records source identities, commands, observed results, review limits, and remaining acceptance work.
