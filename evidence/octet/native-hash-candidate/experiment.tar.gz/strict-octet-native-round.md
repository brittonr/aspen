# Strict Octet boundary round

## Goal and completion evidence

Obtain the actual strict-gate decision for commit `d98f7ff97024c3b8e16fca46f4a4a716e4304615`.
Preserve producer artifacts, their source binding, the corpus receipt, and the canonical consumer receipt.
An explicit denial is a valid diagnostic outcome. It is not acceptance.

The installed hook already produced current workspace-metadata artifacts with 6,787 warnings and no errors.
Its command exits 0 with status `warning-only`.
This round reuses those exact artifacts instead of another unchanged configured check.
The separate library check, real corpus command, artifact import, and strict consumer command remain distinct observations.
Each new command has an eight-minute deadline. Build commands retain two Cargo jobs and the normal wrapper.
No source, marker, policy, profile, baseline, compiler cohort, or producer revision can change in this round.

## Distinct approaches

| Family | Mechanism | Evidence goal | State |
| --- | --- | --- | --- |
| Strict consumer | Pass real current producer artifacts and corpus into the public import/gate path | Canonical denial for 6,787 warnings and 330 critical findings | Validated denial |
| Lifecycle ordering | Separate read-only worker inspects owning changes and controlling workflow sources | Owners and open obligations identified, mandatory gate cycle unproven | Exhausted |

The worker has one five-minute round, twelve reads/searches, and no commands, writes, network, credentials, delegation, or approval authority.
The coordinator owns artifact writes and command runs. Neither model agreement nor a successful hook supplies acceptance.

## Excluded results

A fabricated corpus, synthetic clean status, shortened source inventory, stale metadata, or relaxed profile cannot establish a pass.
A warning-only result cannot establish strict acceptance.
A failed command cannot establish that later commands ran.
A source-level expectation cannot replace the actual strict-gate receipt.

The allowed terminal results are validated observation, blocked, exhausted, or user decision required.

## Terminal observations

The library check and corpus command exit 0. Library status remains `warning-only`, with 2,814 findings.
The real corpus records 13,682 objects. Its replay command retains the exact 1,363 supplied source paths.
The public import passes and records six artifacts. The public strict gate exits 1.
Its canonical receipt is `blake3:4f02f3335e1fb953953d72ddf0bb756274727de4aad56f513e4be9e46bf3e9f5`.
All artifact, schema, scope, metadata, and linkage checks pass. Clean status and absence of critical findings fail.

The lifecycle reader completes twelve reads/searches and grants no approval.
The coordinator verifies the owning package tasks and designs, then runs a read-only F12 sync plan.
That plan is mechanically unblocked, but it has no acceptance/review identifiers and mutates nothing.
It does not satisfy the outstanding source checks. No accepted-spec mutation follows.

The next acceptance requirement is a clean strict producer result without weaker gates or suppressed findings.
Broader implementation, full Nix, candidate combination, and lifecycle completion remain open.
`evidence/octet/native-hash-candidate/validation.md` retains the checked result and receipt limits.
