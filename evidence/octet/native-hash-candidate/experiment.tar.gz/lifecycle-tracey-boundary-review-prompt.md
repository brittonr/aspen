You are a subagent. Don't run memo.

Goal: identify the source-backed lifecycle obligations for the six unresolved Tracey references before any accepted-spec mutation.
Return a bounded evidence map, not approval or a plan to weaken a gate.

Root: /home/brittonr/.local/share/molten-completion/implementation-native-fixture
The root is a Molten worktree at d98f7ff97024c3b8e16fca46f4a4a716e4304615.
Native lifecycle content is under .cairn/. The mainline is molten, not legacy main.

Read-only authority: use only read, grep, find, and ls.
Do not run commands, write files, use credentials or network, delegate, approve lifecycle changes, or publish anything.
Do not suggest marker removal, baseline growth, weaker profiles, synthetic receipts, or automatic acceptance of active deltas.
Preserve explicit source requirements and distinguish required approval from advisory review.

Budget: one round, five minutes, at most twelve file reads/searches, and at most 450 output words.
Read AGENTS.md first. Then inspect the smallest applicable package and workflow sources.
Candidate packages:
- .cairn/changes/saturate-exponential-retry-arithmetic/
- .cairn/changes/add-chaoscontrol-consensus-conformance/
Relevant source: tools/tracey/inherited_debt_guard.rs and repository lifecycle documentation/policy.

Unresolved IDs:
- molten.audit_f12.bounds
- molten.audit_f12.compatibility
- molten.audit_f12.saturation
- molten.audit_f12.validation
- molten.consensus.chaoscontrol_chain_observation
- molten.consensus.chaoscontrol_operation_identity

Questions:
1. Which package/spec owns each group, and which tasks or evidence still block legitimate sync/archive?
2. Do the controlling sources establish an ordering between source checks, full Nix, sync, and archive?
3. Is an apparent gate cycle a demonstrated source requirement, or an unsupported inference?

Output one registry record:
Approach family: lifecycle authority and dependency ordering
Mechanism:
Claim:
Concrete artifact and exact file/line citations:
Evidence:
Gap strength: simpler | equivalent | stronger | unknown
Exact blocker:
Next discriminating check:
State: validated | blocked | exhausted

Name missing facts. A checkbox, active delta, completed command, or reader agreement does not prove acceptance.
Use short, clear sentences. Preserve identifiers and quoted rules exactly.
