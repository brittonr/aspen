# Separate cold-build allocation

Task 312 reached its eight-minute deadline before the integration tests. Its direct exit is 124. The log ends during the build of `/nix/store/iykx4bqma0yqp8r9csjq36x62sjjxsav-molten-cargo-pathless-1.98.0-nightly.drv`.

This is the previously reviewed Cargo derivation. The command also recorded cache connection timeouts and fetched its dependencies. These observations do not establish why the former output was unavailable.

Allocate one separate 24-minute prerequisite build. Keep two cores, one Nix job, the normal wrapper, and all pins unchanged. Keep the build output through a task-owned Nix result link. Do not modify or extend task 312.

After the prerequisite succeeds, repeat the unchanged baseline with the ordinary eight-minute limit and `--locked`. This is a previously unexecuted test baseline, not a replacement for missing historical receipts. If the separate build fails, retain the exact failure and stop this implementation attempt before source edits.
