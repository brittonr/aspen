# Content-replication test errors

## Goal and boundary

Make the private integration-test helper return setup and transfer errors. Add direct accepted and rejected outcome tests. Preserve every existing success assertion and the real two-process transport path.

The owner is Molten's content-replication integration suite. The immediate consumer is `tests/content_replication.rs`. The durable contribution is a directly tested outcome boundary, not a new product component.

Parent: `2465a5e8480e718a0169221a50a097143ea0c802`.
Worktree: `/home/brittonr/.local/share/molten-completion/implementation-content-errors`.
Branch: `completion/content-test-errors-20260914`.
Evidence stays in the primary campaign directory, outside the worktree.

## Selected mechanism

Reuse `TransferOutcome`, `TransferEnvelope`, and `molten::error::Result`. A private converter accepts `Received` unchanged and rejects each other variant with `InvalidHarness`. `run_action` propagates existing setup, fetch, and verification errors. Its callers retain their assertion boundary.

Alternatives considered:

- Keep the panic: this preserves the old test behavior but leaves the outcome boundary without direct rejection coverage.
- Add an injectable production adapter or port: this expands product authority and interfaces without a product need. Reject this option.
- Use a test-local converter and existing adapter rejection inputs: selected. No producer, dependency, protocol, profile, accepted requirement, or public API changes are needed.

The concrete multiprocess adapter currently succeeds only with `Received`. Its other failures return `Err`. This work does not establish a reachable public runtime panic.

## Evidence sequence

1. Run the unchanged integration suite. Preserve the original helper and input hash.
2. Extract the old outcome match and expose a fallible signature while retaining its old panic and `expect` behavior. Add positive and negative tests. Record executed red failures, not compile errors.
3. Replace those test-helper panic paths with explicit errors. Test all four rejected variants, complete-envelope preservation, setup rejection, adapter-open rejection, and real fetch rejection.
4. Keep the existing transport decision, receipt, call-count, identity, size, repair, and protection assertions. Keep process limits unchanged.
5. Run focused tests, both nextest profiles, Clippy with `-D warnings`, formatting, configured Octet and the public strict gate, Cairn validation, and full Nix. Record denials as denials.
6. Obtain one bounded read-only implementation review. Preserve source, logs, numeric exits, available task envelopes, and source-bound evidence before committing.

## Limits

Checks use eight-minute deadlines, two Cargo jobs, two test threads, one Nix job, and two Nix cores. Commit and publication commands have separate twelve-minute deadlines. Use the normal wrapper and unchanged toolchain. Do not extend a running deadline.

Only the coordinator may edit or publish. Reviewers may read and search only, with no commands, network, credentials, delegation, lifecycle mutation, or approval. A review does not replace tests or lifecycle acceptance.

Do not rerun old Raft checks to reconstruct missing task receipts. Preserve the published worktree, original primary staging, historical evidence, and `origin/molten`. Do not integrate, deploy, weaken policy, change baselines, apply lifecycle sync/archive, or remove worktrees during this scope.
