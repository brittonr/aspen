# Nextest command correction

Tasks 390 and 391 include an explicit `-p molten` argument. The prior standard commands omit that argument. These tasks remain package-scoped observations, not evidence that the unchanged commands pass.

An attempt to stop queued task 391 failed:

```text
pueue kill 391 failed (exit code 1).
The command failed for tasks: 391
Task 391 is Queued in group "molten-content-errors". Retry pueue_kill ids=[391].
```

The coordinator did not force-start the task or change the group budget. Both scoped tasks retain their original logs and outcomes. The next commands use the exact standard package selection. Their output files have separate names.
