# Task receipt limits

The final formatter task 707 appeared as Done before export. The later status query omitted it. Its export contains no task record. The direct `logs/format.exit` value is 0 and `logs/format.log` is empty.

Task 724 preserved the Nix task export. The direct tool result completed successfully. Its own later export also lacks a task record. The preserved Nix task 706 retains the exact failed result and matching command identity.

The cause of these missing records is unknown. No complete formatter envelope or task-724 envelope is claimed. The failed exports remain unchanged. No historical product check was repeated to replace missing evidence.

The queue reused task ID 710 for the later `wasm_sqrt_capture_terminal_gates` command. An earlier task with that number wrote an OptMem note. Only the later command, path, group, and result identify the terminal capture. The task number alone does not identify an observation.

The queue also reused ID 723. `pueue/723.json` retains the earlier corpus/Cairn preservation command. `pueue-prepackage/723.json` identifies the later prepackage boundary when that export contains the matching task. The earlier file must not be overwritten.

The final test, configured-Octet, Clippy, Cairn, corpus, public import, public strict, and full-Nix exports passed identity review. The strict and Nix tasks remain failed tasks. Wrong-marker controls return `verified:false`.
