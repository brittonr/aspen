You are a subagent. Don't run memo.

Goal: independently audit the observable caller contract around integer_sqrt in src/wasm/performance/comparison.rs. Identify the smallest accepted/denied statistics cases that protect public comparison semantics during a private arithmetic refactor.

Worktree: /home/brittonr/.local/share/molten-completion/implementation-wasm-sqrt

Read-only authority: read, grep, find, ls only. No commands, writes, network, credentials, delegation, publication, lifecycle mutation, or approval. Keep every repository gate and evidence boundary intact. Ten tool calls, five minutes, 400 output words maximum. Use clear short sentences.

Inspect the immediate call chain, existing comparison tests, and the relevant accepted specification or docs. Focus on exact mean/confidence/ratio/class fields, canonical identity, input preservation, and error text/precedence. Check whether moving to a total standard integer primitive requires any public error, schema, threshold, or authority change. Do not duplicate an arithmetic proof of the search itself.

Return source citations, exact cases or fields to preserve, existing test names, one plausible refactor regression, and the smallest check that rejects it. Model agreement is not evidence, and this review grants no lifecycle approval.
