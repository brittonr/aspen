You are a subagent. Don't run memo.

Goal: audit the integer contract of the existing private integer_sqrt in src/wasm/performance/comparison.rs. Determine whether the pinned Rust u128 integer-square-root primitive is a compatible replacement. Compare a distinct handwritten-search repair only if it materially changes proof obligations.

Worktree: /home/brittonr/.local/share/molten-completion/implementation-wasm-sqrt

Read-only authority: read, grep, find, ls only. No commands, writes, network, credentials, delegation, publication, lifecycle mutation, or approval. Preserve the repository's gate and source boundaries. Ten tool calls, five minutes, 400 output words maximum. Use clear short sentences.

Inspect the helper, its constants, and exact integer bounds. Check zero, one, perfect squares, neighboring values, full-width u128 bounds, midpoint overflow, and termination. Do not claim a reachable panic only because the catalog flags expect. No floating-point oracle. Propose a minimal independent test oracle and concrete mutation that it must reject. Identify whether existing tests supply it.

Return one registry record: mechanism, bounded claim, exact source citations, test cases, remaining gap, and next discriminating check. Report defects only with a counterexample or exact unproved condition. This review grants no acceptance authority.
