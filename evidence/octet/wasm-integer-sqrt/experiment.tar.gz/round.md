# Wasm integer-square-root round

## Goal and completion evidence

Remove the actual production `no_unwrap` finding in the private Wasm statistics helper without changing integer statistics or error behavior.

Acceptance for this bounded source repair requires an unchanged-source test baseline, exact integer-boundary checks, existing comparison denials, a discriminating mutation, and final source-bound checks. The configured catalog and public strict receipt must describe the actual result. A complete strict pass is not presumed.

The deliverable is a reviewed source patch, positive and negative tests, repository-owned evidence, and a verified change-branch publication. Mainline integration and whole-Molten acceptance remain separate.

## Owner and source

Molten owns `src/wasm/performance/comparison.rs`. Its statistics feed the existing recorded performance comparison. The helper has no I/O or authority effects.

The parent is `ba1d203280df4c645f8e88914d78d052ba310ba1`. Setup fetches `origin`, creates a dedicated worktree from `origin/molten`, and retains that published candidate.

The parent catalog reports `no_unwrap` as `F6275` and `F6276` at `src/wasm/performance/comparison.rs:500`. These are two observations of one source call. The divisor already has a positive compile-time assertion. No reachable divide-by-zero defect is established.

The prior node-profile advisory is not selected. The current catalog has no `no_unwrap` entry for `src/node/profile_config.rs`. The pinned lint explicitly skips recognized test contexts. A source `unwrap` alone is not a current diagnostic attribution.

The other production finding is the guarded lifecycle config extraction in `src/cluster_harness/runner.rs`. It remains a separate owner boundary.

## Approach registry

| Family | Mechanism | State | Next evidence |
|---|---|---|---|
| Library primitive | Reuse the pinned Rust integer square root while preserving the private total-function contract | Active | Independent arithmetic review and floor-bound tests |
| Fallible division | Change a total helper to a result and propagate an impossible constant-divisor error | Not selected | Adds a new error surface without an observed failure |
| Handwritten search | Keep the search and express its constant division without `expect` | Audit alternative | Compare proof obligations and lint consequences |
| Node fixture | Make a test-local adapter fixture fallible | Not selected | No matching current critical finding |
| Lifecycle extraction | Propagate incomplete config as an error | Deferred | Separate lifecycle receipt-preservation tests |

The existing compiler cohort supplies integer arithmetic. A targeted Trellis Rust-source search finds no square-root component. No source copy, new dependency, public port, or generic helper package is proposed.

## Bounds and authority

Only the coordinator edits, commits, publishes, or changes lifecycle state. Workers receive read/search/list tools, no commands, writes, network, credentials, delegation, or approval authority.

One arithmetic-contract worker and one independent caller/evidence worker each receive at most ten tool calls, five minutes, and 400 output words. One follow-up review can receive six calls and five minutes if new evidence requires it.

Ordinary checks retain eight-minute deadlines, two Cargo jobs, two test threads, one Nix job, two cores, and `/tmp/molten-completion-20260913-target`. Commit and push limits remain twelve minutes. No active deadline extension is permitted.

Keep source frozen during checks and hooks. Preserve red and rejected source, logs, numeric exits, task identities, exact source/payload hashes, full archive comparisons, and remote containment observations.

Do not change pins, profiles, timeouts, accepted specs, task classifications, baselines, allowances, or required gates. Preserve the primary HEAD, original staged ZIP/audit blobs, published worktrees, and historical evidence.

No deployment, force-push, pull request, lifecycle sync/archive, or worktree removal is authorized by this bounded repair. Change-branch publication remains covered by the existing completion request.

## Audit risks and non-claims

The root must be the floor for every admitted unsigned value. Small values, perfect squares, values on both sides of a square, powers of two, and the full-width maximum need explicit coverage.

A floating-point oracle is unsuitable for full-width integers. Comparing the new primitive only with itself is circular. Use integer lower/upper-square inequalities and fixed expected cases.

The comparison caller must retain sample-count, arithmetic-overflow, compatibility, confidence, and ratio behavior. A source-policy repair does not validate statistical methodology or establish a benchmark improvement.

The old implementation can be correct despite its source-policy finding. A deliberate mutation is not an original runtime defect. Passing local checks does not replace strict, Nix, lifecycle, feature, target, VM, fault, or release acceptance.

The round ends with a validated scoped result, an exact blocker, or its declared budget exhausted. No result is promoted from model agreement alone.
