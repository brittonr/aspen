# Baseline selection and review limits

Task 587 used the source-path-shaped filter `wasm::performance`. It exited zero after compilation, but ran zero tests and filtered 1,488. This is not a test baseline.

`src/lib.rs:107-108` names the module `wasm_performance`. Task 598 uses that exact module filter. It exits zero with 15 passed tests and 1,473 filtered tests. No source edit preceded that baseline.

The coordinator retains both logs and task exports. The correction changes test selection, not a timeout or production input.

The arithmetic reader finds no concrete defect in the old floor-root search. Its fixed divisor and loop bounds protect the flagged `expect`. Its invariant argument is advisory, not a machine-checked proof.

The caller reader identifies exact confidence values that the prior class-only tests do not assert. The new cases use the existing public comparison API and fixture builders. Their independent expected fields cover constant samples, non-square variance, threshold equality, complete comparison identity, and unchanged input values.

The negative cases preserve direct-comparison rejection for empty/singleton phases, zero baseline means, and candidate variance overflow. Direct run validation differs from builder sample-bound validation. This repair does not change or endorse that separate admission boundary.

The primitive audit uses integer square bounds rather than floating point or another call to the same root primitive. It also rejects deliberately wrong roots. The separate ceiling-root mutation must fail these checks and the exact confidence case.

The review group permits two independent read-only workers. Each retains its declared five-minute and ten-call limit. Neither worker executes tests, edits source, or grants acceptance.
