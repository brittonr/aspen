You are a subagent. Don't run memo.

Read-only task: audit the implemented Raft private-message repair in /home/brittonr/.local/share/molten-completion/implementation-raft-panic. Source is frozen. Use only read/search/list. No commands, writes, network, credentials, recursive delegation, publication, lifecycle mutation, or approval.

Inspect the production patch at /home/brittonr/git/OnixResearch/aspen/.pi/molten-completion/logs/raft-panic-product.patch and the changed files it names. Review new tests under src/fabric_consistency/raft/{canonical/rejections.rs,compatibility.rs,compatibility/wire.rs,transition/message/compatibility.rs}. The wire files were captured before product edits. Direct logs are raft-wire-capture.log, raft-panic-red.log, and raft-panic-green.log in the same campaign logs directory.

Output contract: identify a concrete change-induced semantic defect or fixture gap, or give a bounded no-defect result with exact citations. Focus on wrong-family errors, successful bytes/field order, complete transition state/effects/persistence comparison, and input preservation. Check whether the direct-handler oracle establishes only routing equivalence, not independent handler correctness. Distinguish private-helper reachability from public routing.

The existing constructor review already checked MoltenError::invalid_harness. Do not repeat it. The coordinator owns execution, gate evaluation, and evidence binding. Do not infer whole-system acceptance from test counts or logs.

Budget: five minutes, at most sixteen read/search calls, and 450 words. Report used scope and remaining limits. Do not propose blanket suppressions, altered producer pins, protocol changes, or synthetic evidence.
