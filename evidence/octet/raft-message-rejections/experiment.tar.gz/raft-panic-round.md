# Raft private message rejection round

## Outcome and authority

Replace eight private Raft message-family panic fallbacks with existing deterministic errors. Preserve public APIs, valid canonical bytes, parser rules, transitions, and ordered effects. The Molten consistency owner maintains this code and its regression tests.

The new worktree is `/home/brittonr/.local/share/molten-completion/implementation-raft-panic`, branch `completion/raft-panic-rejections-20260913`. It was created from freshly fetched `origin/molten`, then fast-forwarded to `6db5f15c4ab3fe1ccab9948875f3c7b145350701`. The coordinator alone may write source or lifecycle files. Readers have no execution, mutation, publication, delegation, or approval authority.

This is source-policy hardening, not a demonstrated reachable public defect. Current exhaustive dispatchers only call matching private helpers. No producer replacement, new port, public API, suppression, baseline change, accepted-spec edit, or runtime-profile change is allowed.

This narrow private repair does not change admitted public requests, public compatibility, mutation rules, architecture, receipt schemas, or roadmap requirements. It stays within the accepted consistency implementation. No new lifecycle requirement or accepted-spec promotion is needed for this scope. Existing lifecycle and release obligations remain open.

## Mechanisms and evidence

The prior bounded review validated error propagation as a design only. Direct exhaustive matching remains an alternative, but it would change more handler structure. Select existing `Result` propagation if the error-constructor review confirms that it stays deterministic and effect-free.

Before product edits, run the existing Raft tests. Add all eight message variants, empty and nonempty append batches, and empty and nonempty snapshot request inventories. Capture pre-change canonical bytes with an explicit, refusing-directory test-only recorder. Remove recorder I/O from the retained regression suite after capture. Bind the captured files and recorder source with BLAKE3.

Run negative private-helper tests against the old fallbacks. Preserve the failed source and direct result. Then require exact error variants and diagnostics, unchanged input, and unchanged transition state, effects, and persistence flags. Compare every successful dispatch with the unchanged direct handler, including full state, ordered effects, and persistence decisions.

Run the focused suite after the change, workspace/all-target Clippy with `-D warnings`, formatting, default and CI nextest, and current configured Octet. Source-gate findings are not semantic proofs. Retain all required broad gate blockers; do not promote this narrow round to whole-Molten acceptance.

## Budgets

Ordinary commands have an eight-minute outer limit. Commits have twelve minutes. Use two Cargo jobs, two test threads, the existing shared target, one Nix job, and two cores. Do not extend active deadlines. Preserve direct logs, numeric exits, source manifests, and available full Pueue envelopes immediately after completion.

One error-constructor reader has five minutes, eight read/search calls, and a 350-word report limit. Its report is advisory, not independent lifecycle approval.
