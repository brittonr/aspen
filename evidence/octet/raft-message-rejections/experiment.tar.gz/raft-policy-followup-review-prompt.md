You are a subagent. Don't run memo.

Goal: find a change-induced defect in the Raft policy follow-up. Return a short finding with exact paths and lines, or a bounded no-defect result. Explain the limits of the direct-handler oracle.

Read-only authority: use read, grep, find, and ls only. Do not run commands, write files, use the network, inspect credentials, delegate, publish, mutate lifecycle state, or grant approval. Use at most ten tool calls, five minutes, and 400 words.

The worktree is /home/brittonr/.local/share/molten-completion/implementation-raft-panic. Read the patch at /home/brittonr/git/OnixResearch/aspen/.pi/molten-completion/logs/raft-panic-r2-policy.patch first. It compares the first green source against this source.

Review the explicit rejected variants in canonical.rs and transition/message.rs. Each family must preserve its two successful variants and reject all six other variants with the same error. No handler, parser, protocol, authority rule, profile, or fixture byte must change.

Review the qualified fixture calls and split direct-handler oracle. Check that inputs, handlers, arguments, state comparisons, effect order, and persistence checks remain the same. The oracle shares the production handlers, higher-term observation, and finalization. It proves routing equivalence for selected cases, not independent Raft correctness or a saved pre-change transition baseline. Its assertion panics are test-only.

The existing red suite and both green suites are coordinator evidence. You have no authority to claim their execution or acceptance. Do not treat a lint count or this review as release evidence.
