use super::*;
use crate::fabric_consistency::raft::compatibility::Family;
use crate::fabric_consistency::raft::compatibility::cases;

#[test]
fn vote_encoding_rejects_other_families_without_panicking() {
    assert_rejections(Family::Vote);
}

#[test]
fn append_encoding_rejects_other_families_without_panicking() {
    assert_rejections(Family::Append);
}

#[test]
fn read_encoding_rejects_other_families_without_panicking() {
    assert_rejections(Family::Read);
}

#[test]
fn snapshot_encoding_rejects_other_families_without_panicking() {
    assert_rejections(Family::Snapshot);
}

fn assert_rejections(family: Family) {
    let mut panic_count = 0;
    for case in cases() {
        if case.family == family {
            continue;
        }
        let before = case.envelope.clone();
        let observed = std::panic::catch_unwind(|| encode(family, &case.envelope.message));
        assert_eq!(case.envelope, before, "{}", case.name);
        if observed.is_err() {
            panic_count += 1;
        }
    }
    assert_eq!(panic_count, 0, "wrong-family encoding must return an error, not panic");
}

fn encode(family: Family, message: &RaftMessage) {
    match family {
        Family::Vote => { let _ = vote_message_value(message); }
        Family::Append => { let _ = append_message_value(message); }
        Family::Read => { let _ = read_message_value(message); }
        Family::Snapshot => { let _ = snapshot_message_value(message); }
    }
}
