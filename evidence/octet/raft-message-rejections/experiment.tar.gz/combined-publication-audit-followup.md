# Combined publication receipt correction

The publication of `6db5f15c4ab3fe1ccab9948875f3c7b145350701` remains verified. The retained push and remote-verification envelopes match the expected commands, paths, groups, and successful terminal results. A wrong-command control rejects.

The original `combined-publication-validation.md` says:

> `logs/combined-publication-cairn-metadata.*` and its task export bind the hook source snapshot.

That statement overstates the available task export. The direct metadata JSON, log, and zero exit survive. The later export does not contain the expected terminal envelope for task 2082. The audit returns `missing_task` and `verified:false`. The successful push receipts do not replace that missing envelope.

The selected immutable Cairn source remains `/nix/store/69f8rrsv266dvpamj90b87wspv93832c-source`. No metadata rerun, replacement receipt, policy change, or mainline integration occurred for this correction. The original report and exports remain historical evidence.
