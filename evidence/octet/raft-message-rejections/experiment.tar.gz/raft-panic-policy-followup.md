# Raft source-policy follow-up

The first green candidate passed 58 focused tests, both nextest profiles with 1,660 passes, and workspace/all-target Clippy. Its public strict receipt still denied 6,817 warnings and 314 critical findings. All artifact and linkage checks passed. The configured catalog reduced `no_panic` from 17 findings to one.

The first candidate introduced eight `catch_all_on_enum` findings in the transition rejection arms. New tests also introduced twelve non-trait imports, a repeated name, and a long oracle function. Correct those sites rather than suppress the rules. Use explicit rejected variants, qualified owner paths, and bounded per-family oracle helpers. Keep the same tests, fixture bytes, errors, and state assertions.

The source archive `raft-panic-first-green-source.tar.gz`, `octet-raft-panic/`, and `logs/raft-panic-*` retain the first attempt. New observations use `r2` names and do not overwrite those artifacts.

The first catalog also reports findings at unchanged source paths for `fat_trait`, `negated_predicate`, and `renamed_imports`. Do not attribute those observations to this repair without evidence. The selected executable and lint-library BLAKE3 checks still match their retained identities.

Repeat relevant checks because the source changed. Retain eight-minute command bounds, two Cargo jobs, two test threads, one Nix job, two cores, and the existing target. Do not weaken strict policy, alter producer pins, or change accepted specifications. The direct-handler comparison remains a routing oracle, not independent handler correctness or a saved pre-change transition snapshot.
