#!/usr/bin/env -S nix develop --no-write-lock-file -c cargo -q -Zscript
---
[dependencies]
cargo-util-schemas = "=0.13.2"
---

use cargo_util_schemas::core::{GitReference, PackageIdSpec, SourceKind};

const PACKAGE_NAME: &str = "vm-cohort-core";
const PACKAGE_VERSION: &str = "0.1.0";
const ORDINARY_URL: &str = "ssh://git@github.com/OnixResearch/vm-cohort.git";
const PATHLESS_URL: &str = "rad://z2QJLUqyAZnnHPiZQ1BFjLsX9ush3";
const MISSING_PATH_DIAGNOSTIC: &str = "pkgid urls must have at least one path component";

fn package(url: &str) -> PackageIdSpec {
    PackageIdSpec::new(PACKAGE_NAME.to_string())
        .with_version(PACKAGE_VERSION.parse().expect("controlled package version"))
        .with_url(url.parse().expect("controlled source URL"))
        .with_kind(SourceKind::Git(GitReference::DefaultBranch))
}

fn main() {
    println!("probe_kind=expected_failure_reproduction");
    let ordinary = package(ORDINARY_URL);
    let ordinary_text = ordinary.to_string();
    let expected = format!("git+{ORDINARY_URL}#{PACKAGE_NAME}@{PACKAGE_VERSION}");
    assert_eq!(ordinary_text, expected);
    assert_eq!(PackageIdSpec::parse(&ordinary_text).expect("ordinary round-trip"), ordinary);
    println!("ordinary_round_trip=pass");

    let pathless = package(PATHLESS_URL);
    assert!(pathless.url().expect("source URL").path_segments().is_none());
    let formatted = std::panic::catch_unwind(|| pathless.to_string());
    assert!(formatted.is_err(), "the pathless formatter did not reproduce the panic");
    println!("pathless_formatter_panics=true");

    let explicit = format!("git+{PATHLESS_URL}#{PACKAGE_NAME}@{PACKAGE_VERSION}");
    let error = PackageIdSpec::parse(&explicit).expect_err("pathless parser rejection");
    assert!(error.to_string().contains(MISSING_PATH_DIAGNOSTIC));
    println!("pathless_explicit_name_rejected={error}");

    assert!(PackageIdSpec::parse("invalid-package@").is_err());
    println!("invalid_version_rejected=true");
    println!("cargo_or_nextest_repair_claim=false");
}
