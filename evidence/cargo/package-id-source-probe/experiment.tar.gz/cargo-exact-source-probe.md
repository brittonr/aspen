# Exact-source Cargo package-ID probe

## Goal and completion evidence

Run the existing package-ID counterexample against Cargo source revision `4d1f984518c77fad6eeef4f40153b002a659e662`.
A successful reproduction must pass an ordinary SSH URL round-trip and an invalid-version rejection control.
It must also observe the pathless formatter panic and the separate explicit-name parser rejection.
The exact resolved library revision and selected source hashes must accompany the result.

This is a new mechanism after the registry-only probe failed before compilation.
It uses an immutable Git dependency for `cargo-util-schemas`, not an arbitrary available registry version.
The inspected source declares version `0.13.2` and Rust `1.94` as its minimum version.
The formatter unwraps path segments. The parser demands a path component before it examines an explicit identity fragment.
Neither source observation substitutes for the executable probe.

## Authority and budget

Only task-owned diagnostic files, Cargo cache entries, and retained logs can change.
Repository manifests, producer pins, toolchain selection, accepted specs, and lockfiles remain unchanged.
The probe performs no Radicle network request. GitHub source fetches use SSH.
The repository Nix environment remains the compiler owner, rather than a different standalone Fenix cohort.
The command records `cargo -Vv` and `rustc -Vv` from that environment before compilation.

Budget: one probe command, eight minutes, two Cargo build jobs, eight further source reads/searches, and one source-identity check.
Use the existing serialized build group and target directory.
No provider review retry belongs to this probe. The independent review service reached its usage limit in the preceding round.
Allowed outcomes are a validated narrow reproduction, a concrete blocker, or budget exhaustion.
A Cargo or nextest repair requires a separate source correction, compatibility checks, and complete gate evidence.

## Approach registry

| Family | Mechanism | Evidence boundary | State |
|---|---|---|---|
| Exact-source formatter | Build the schema crate from the installed Cargo source revision | The unwrapped diagnostic catches the expected panic at line 248 | Validated narrow counterexample |
| Explicit identity parser | Parse an explicit name/version on the same pathless URL | The unwrapped diagnostic gets the expected missing-path error | Validated separate rejection |
| Registry substitution | Ask for schema version 0.13.2 from crates.io | Resolution failed before any assertion ran | Closed, blocked |
| Transport rewrite | Previously tested namespace and HTTP routes | Namespace lacked HEAD and selected HTTP endpoints failed | Closed for tested routes |

## Source binding

The Molten candidate used for its Nix environment is `5c71c5b443423f4c601c78a5b56a89c19b658b78`.
Its tracked worktree is clean. GitHub CLI configuration reports `git_protocol=ssh`.
The diagnostic script retains a native Cargo manifest because `cargo -Zscript` consumes that format directly.
The earlier probe and failed resolution logs remain unchanged.

## Git dependency result

The command ended at its eight-minute deadline with exit 124.
It printed the expected Cargo and Rust compiler identities, then two diagnostics from upstream negative manifest fixtures.
The log contains no compilation or probe assertion output.
These observations do not establish why the command exhausted its deadline.
The Git dependency route did not produce the required executable reproduction.

The source-identity check then passed with exit 0.
The fetched checkout is exactly revision `4d1f984518c77fad6eeef4f40153b002a659e662`, with no tracked or staged diff.
The identity log binds its root manifest, upstream lockfile, schema manifest, and package-ID implementation with BLAKE3.

## Direct-path diagnostic round

New mechanism: reference the verified schema crate directory directly from a separate Cargo script.
This avoids asking Cargo to discover the dependency through a Git source repository.
The exact library source and its workspace-inherited dependency declarations remain unchanged.
The path is a diagnostic input, not a product dependency or a published component contract.
The immutable revision, absence of source changes, and source hashes remain the provenance boundary.
No claim is made that this isolates the cause of the previous timeout.

Budget: one additional eight-minute command, two build jobs, and one final source-preservation check.
Retain the same compiler cohort, assertions, profile, and target directory.
Preserve both earlier failed scripts and all logs.
A timeout or failure ends this diagnostic round without an unchanged retry.
A successful expected-failure reproduction still does not repair Cargo or nextest.

One bounded process observation is also admitted while the second command runs.
Select only the exact task-owned script invocation. Inspect its process state and children without controlling unrelated processes.
The first log does not establish whether compilation began. The earlier progress message overstated that boundary.

## Observed environmental blockers

At elapsed time 2:30, the direct-path command had two `kache rustc` children in `locks_lock_inode_wait`.
They requested compilation of `quote` and `proc_macro2`. Cargo waited in `futex_do_wait`.
This observation concerns the direct-path round. It does not explain every earlier timeout.
A later lock query showed the task-owned wrapper waiting for `/var/cache/kache-nix/user-brittonr/store/gc.lock`.
The reported lock holder was process `1875945`. Its ownership was not established, so it was not controlled or stopped.

A campaign-note update then failed with `EDQUOT: unknown error, write`.
Read-back showed that the prior note remained intact.
`df` reported zero available bytes on `datapool/git`. The campaign occupied about 0.22 GiB there.
The task's 18.90 GiB build directory is on the separate `datapool/tmp` dataset, which had 154 GiB available.
Removal of that build directory does not free space on the separate Git dataset.
No source, evidence, cache, worktree, or user data was deleted.

The coordinator killed only task 812 after checking its exact command and owned group.
Pueue records it as killed, not as a successful run or a timeout.
The direct-path round produced no probe result. Its log and process observation remain retained.
A later ZFS query reported 4,522,299,392 bytes available under an unchanged 858,993,459,200-byte quota.
That recovery was external to this task. No quota or dataset setting was changed.

## Unwrapped diagnostic round

The new mechanism bypasses only `RUSTC_WRAPPER` for one diagnostic command inside the same repository Nix environment.
The compiler, schema source, dependency declarations, assertions, build profile, job limit, and target directory remain unchanged.
Verbose Cargo output makes compilation progress visible. No performance comparison is claimed.
This bypass is not a repository configuration change or acceptance evidence for the normal cached build path.
The goal is to distinguish library behavior from the observed shared cache-lock wait.

Budget: one eight-minute command and the previously reserved final source-preservation check.
Do not stop the cache-lock owner, alter the shared cache, or retry this command unchanged.
No independent source review or Cargo/nextest repair is implied by a passing diagnostic.

## Validated narrow result

Task 831 completed with exit 0. Cargo reports compilation in 20.76 seconds, after an initial build-directory lock message.
That duration is not a benchmark or a causal comparison with earlier attempts.
The log records an empty `RUSTC_WRAPPER`, the unchanged compiler identities, and compilation of the exact schema checkout.

The following controls completed:

- The ordinary SSH package ID formats exactly and parses back to the original value.
- The pathless package ID triggers a caught panic at `package_id_spec.rs:248:40`.
- The formatter leaves the input unchanged.
- Parsing the explicit pathless name/version returns `pkgid urls must have at least one path component`.
- The invalid version control rejects.

The panic text is expected counterexample output, not an unhandled probe failure.
The final output states `cargo_or_nextest_repair_claim=false`.
No Radicle request is necessary for these formatter and parser failures.

The probe uses the exact schema source, but it resolves its own registry dependency set.
It does not claim the complete dependency closure of the installed Cargo binary.
Both generated script lockfiles remain evidence. Neither is a product lockfile.
A working formatter alone does not satisfy the explicit-identity round-trip requirement.
Normal cached builds, actual Cargo metadata, nextest, and strict acceptance remain separate obligations.

## Budget and review limits

The Git route used one eight-minute command and ended with exit 124.
The direct-path route was killed after the cache-lock and quota observations. It did not exhaust its own deadline.
The unwrapped route used one command and completed within its eight-minute limit.
The extra process and storage observations changed the next mechanism. They did not authorize control of the cache-lock holder.
The coordinator performed these passes. No independent review completed in this round.

A preliminary Octet source read used the nonexistent `src/cli/testing/octet.rs` path.
File discovery found `src/cli/ops/octet.rs`. No new strict Octet command ran.
A provisional lockfile search respected ignore rules and found no matches. Direct reads supplied both generated lockfiles.

The first formatting check returned exit 1 because the repository format splits grouped imports.
The executed scripts were archived and compared before that formatting-only correction.
One final eight-minute command is admitted to bind the formatted script to the same controls after the source edit.
This command also repeats the formatting check. It changes no assertions, dependency input, or build profile.
The formatted script and formatting check pass with exit 0. Every expected control completes again.
The final source-identity check matches the original identity log byte for byte.

An attempted JSON export of the killed Pueue task returned `{}`.
It does not preserve a structured terminal receipt. The captured Pueue tool output supplies the killed-state observation.
No direct exit file exists for that killed command, and no numeric exit code is inferred.

## Durable contribution and remaining blocker

Molten build maintainers own this diagnostic evidence and its future regression fixture.
The current consumer is the blocked Molten Cargo metadata and nextest path.
The source pin, generated diagnostic lockfiles, positive and negative controls, logs, and BLAKE3 manifests support reproduction.
The probe depends on an explicitly recorded local checkout path. It is not a portable product dependency.

The validated result is a transport-independent package-ID counterexample at the exact schema revision.
The installed Cargo binary remains unchanged. It still needs a repair that preserves explicit identity round-trips and existing URL behavior.
The normal cache path also lacks a successful result from this round.
No core implementation, accepted spec, producer pin, repository lockfile, lifecycle state, or integration branch changed.
