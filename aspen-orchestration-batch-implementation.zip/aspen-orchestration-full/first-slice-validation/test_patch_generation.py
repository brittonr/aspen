"""Tests of patch transformations against exact relevant fetched source windows.
These do not validate the whole repository or compile any Rust.
"""
import importlib.util
from pathlib import Path
import unittest

path = Path(__file__).resolve().parents[1] / "apply.py"
spec = importlib.util.spec_from_file_location("change_installer", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

ENUM = """    Complete {
        job_id: String,
        owner: String,
        completion_ref: String,
    },
"""
ERROR_VARIANT = "    MissingLeaseOwner(String),\n"
MATCH = """        DistributedSchedulerOperation::Complete {
            job_id,
            owner,
            completion_ref,
        } => {
"""
MUTATION = "            job.phase = ReferenceJobPhase::Completed;\n"
CONSTRUCTOR = """        &ReferenceServiceOperation::DistributedScheduler(DistributedSchedulerOperation::Complete {
            job_id: "job-a".to_string(),
            owner: "worker-a".to_string(),
            completion_ref: content_ref('a'),
        }),
"""

class PatchTests(unittest.TestCase):
    def test_core_transformation_binds_epoch_before_completion(self):
        text = module.patch_reference(ENUM + ERROR_VARIANT + MATCH + MUTATION)
        self.assertIn("lease_epoch: u64,", text)
        self.assertIn("LeaseEpochMismatch", text)
        self.assertLess(text.index("if *lease_epoch != job.lease_epoch"), text.index(MUTATION.strip()))
        self.assertIn("actual: *lease_epoch", text)

    def test_existing_completion_constructors_are_updated(self):
        text = module.patch_constructors(CONSTRUCTOR * 3, 3)
        self.assertEqual(text.count("lease_epoch: 1,"), 3)
        self.assertEqual(text.count("completion_ref:"), 3)

    def test_unexpected_number_of_constructors_is_rejected(self):
        with self.assertRaises(ValueError):
            module.patch_constructors(CONSTRUCTOR, 3)

    def test_missing_and_duplicate_core_anchors_are_rejected(self):
        for source in ("", ENUM * 2 + ERROR_VARIANT + MATCH + MUTATION):
            with self.assertRaises(ValueError):
                module.patch_reference(source)

    def test_already_patched_source_is_rejected(self):
        text = module.patch_reference(ENUM + ERROR_VARIANT + MATCH + MUTATION)
        with self.assertRaises(ValueError):
            module.patch_reference(text)

    def test_new_file_uses_dev_null_unified_patch(self):
        patch = module.unified("pilots/example.rs", "", "fn example() {}\n", is_new=True)
        self.assertTrue(patch.startswith("--- /dev/null\n+++ b/pilots/example.rs\n"))
        self.assertIn("+fn example() {}", patch)

if __name__ == "__main__":
    unittest.main()
