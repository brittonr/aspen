#!/usr/bin/env python3
"""Independent finite Python model; does NOT execute or prove the Rust code."""
from dataclasses import dataclass, replace
from itertools import product
import json
from pathlib import Path

@dataclass(frozen=True)
class State:
    phase: str = "assigned"
    revision: int = 0
    fence: tuple[int, ...] = (1, 2, 3, 4, 1, 1)

EVENTS = ("dispatch", "started", "rejected", "unknown", "complete")
TABLE = {
    ("assigned", "dispatch"): "dispatching",
    ("dispatching", "started"): "running",
    ("dispatching", "rejected"): "rejected",
    ("dispatching", "unknown"): "unknown",
    ("dispatching", "complete"): "terminal",
    ("running", "complete"): "terminal",
    ("unknown", "complete"): "terminal",
}

def step(state: State, fence: tuple[int, ...], event: str) -> State | None:
    if fence != state.fence or state.revision == 2**64 - 1:
        return None
    phase = TABLE.get((state.phase, event))
    return None if phase is None else replace(state, phase=phase, revision=state.revision + 1)

def main() -> None:
    sequences = 0
    transitions = 0
    for events in product(EVENTS, repeat=6):
        sequences += 1
        state = State()
        dispatches = completions = 0
        for event in events:
            before = state
            proposal = step(state, state.fence, event)
            if proposal is not None:
                transitions += 1
                state = proposal
                dispatches += event == "dispatch"
                completions += event == "complete"
                assert state.revision == before.revision + 1
            assert state.fence == before.fence
            assert dispatches <= 1 and completions <= 1
            if before.phase in ("terminal", "rejected"):
                assert state == before
    fence_checks = 0
    for phase in {x for x, _ in TABLE} | {"terminal", "rejected"}:
        for dimension in range(6):
            state = State(phase=phase)
            stale = list(state.fence)
            stale[dimension] += 1
            for event in EVENTS:
                assert step(state, tuple(stale), event) is None
                fence_checks += 1
    assert step(State(revision=2**64 - 1), State().fence, "dispatch") is None
    # Explicit reference-scheduler ABA counterexample and fenced correction.
    owners_and_epochs = [("A", 1), ("B", 2), ("A", 3)]
    stale_owner, stale_epoch = owners_and_epochs[0]
    current_owner, current_epoch = owners_and_epochs[-1]
    assert stale_owner == current_owner  # old owner-only rule accepts
    assert (stale_owner, stale_epoch) != (current_owner, current_epoch)
    report = {
        "scope": "independent Python allocation-law model, not Rust execution or proof",
        "length_6_sequences": sequences,
        "accepted_transitions_across_sequences": transitions,
        "fence_drift_checks": fence_checks,
        "reference_scheduler_aba_counterexample_reproduced": True,
        "revision_overflow_denied": True,
        "result": "pass",
        "rust_compilation": "not run: no Rust toolchain available",
        "whole_repository_tests": "not run",
        "production_or_distributed_correctness_claim": False,
    }
    path = Path(__file__).resolve().parent / "model-result.json"
    path.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    main()
