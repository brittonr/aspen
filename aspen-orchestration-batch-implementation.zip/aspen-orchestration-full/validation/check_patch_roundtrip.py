#!/usr/bin/env python3
"""Apply all delivered text hunks to a synthetic Git fixture, not the Aspen tree."""
from pathlib import Path
import importlib.util, subprocess, tempfile
BASE=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('patcher',BASE/'apply.py')
patcher=importlib.util.module_from_spec(spec);spec.loader.exec_module(patcher)
spec=importlib.util.spec_from_file_location('fixtures',BASE/'first-slice-validation/test_patch_generation.py')
fixtures=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixtures)
paths=list(patcher.ORIGINALS)
originals={paths[0]:fixtures.ENUM+fixtures.ERROR_VARIANT+fixtures.MATCH+fixtures.MUTATION,
           paths[1]:fixtures.CONSTRUCTOR*3,paths[2]:fixtures.CONSTRUCTOR}
expected={paths[0]:patcher.patch_reference(originals[paths[0]]),
          paths[1]:patcher.patch_constructors(originals[paths[1]],3),
          paths[2]:patcher.patch_constructors(originals[paths[2]],1)}
hunks=[patcher.unified(p,originals[p],expected[p]) for p in paths]
for p in sorted((BASE/'overlay').rglob('*')):
    if p.is_file():
        rel=p.relative_to(BASE/'overlay').as_posix()
        expected[rel]=p.read_text()
        hunks.append(patcher.unified(rel,'',expected[rel],True))
patch=''.join(hunks).encode()
with tempfile.TemporaryDirectory(prefix='orchestration-patch-') as tmp:
    root=Path(tmp)
    subprocess.run(['git','init','--quiet',tmp],check=True,capture_output=True)
    for rel,text in originals.items():
        p=root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
    for args in [('apply','--check','-'),('apply','-')]:
        run=subprocess.run(['git','-C',tmp,*args],input=patch,capture_output=True)
        if run.returncode:raise RuntimeError(run.stderr.decode())
    for rel,text in expected.items():
        if (root/rel).read_text()!=text:raise AssertionError(f'Round-trip mismatch: {rel}')
print(f'PASS: git apply --check, apply, and byte-equivalent round-trip for {len(expected)} text files in a synthetic fixture.')
print('Not run against the complete Aspen tree. Exact HEAD/blob checks remain enforced by apply.py when the user runs it.')
