#!/usr/bin/env python3
"""Limited lexical/manifest checks. Does not compile, type-check, or execute Rust."""
from pathlib import Path
import json, re, subprocess, sys, tomllib
from pygments import lex
from pygments.lexers import RustLexer
from pygments.token import Comment, String, Error
BASE=Path(__file__).resolve().parents[1]
ROOT=BASE/'overlay/pilots/orchestration'
errors=[]; checked=[]
for p in ROOT.rglob('*.toml'):
    try: tomllib.loads(p.read_text());checked.append(str(p.relative_to(BASE)))
    except Exception as exc: errors.append(f'{p}: {exc}')
rust=list((BASE/'overlay').rglob('*.rs'))
for p in rust:
    stack=[]; line=1
    for kind,text in lex(p.read_text(),RustLexer()):
        if kind in Error: errors.append(f'{p.relative_to(BASE)}:{line}: RustLexer Error token {text!r}')
        if kind not in Comment and kind not in String:
            for c in text:
                if c in '({[':stack.append((c,line))
                elif c in ')}]':
                    if not stack or stack[-1][0] != {')':'(',']':'[','}':'{'}[c]: errors.append(f'{p.relative_to(BASE)}:{line}: unmatched delimiter {c}')
                    else:stack.pop()
        line += text.count('\n')
    if stack:errors.append(f'{p.relative_to(BASE)}: unclosed delimiters {stack}')
    # Only static literal include paths; env!/concat! need the actual compiler.
    for rel in re.findall(r'include_(?:str|bytes)!\("([^"]+)"\)',p.read_text()):
        if not (p.parent/rel).is_file():errors.append(f'{p.relative_to(BASE)}: missing included file {rel}')
for p in ROOT.rglob('*.sh'):
    proc=subprocess.run(['bash','-n',str(p)],capture_output=True,text=True)
    if proc.returncode:errors.append(proc.stderr)
for p in [BASE/'apply.py',ROOT/'check_boundaries.py',Path(__file__)]:
    try:compile(p.read_text(),str(p),'exec')
    except SyntaxError as exc:errors.append(str(exc))
tests=sum(len(re.findall(r'#\[(?:tokio::)?test(?:\([^\]]*\))?\]',p.read_text())) for p in rust)
result={'rust_files_lexically_scanned':len(rust),'rust_test_annotations_authored':tests,'toml_files_parsed':len(checked),'shell_files_syntax_checked':len(list(ROOT.rglob('*.sh'))),'errors':errors,'rust_compilation':'NOT RUN','rust_tests':'NOT RUN','limitations':'Pygments lexical/delimiter checks are not Rust parsing or type checking. Bash/TOML checks do not execute the Rust program.'}
print(json.dumps(result,indent=2))
sys.exit(bool(errors))
