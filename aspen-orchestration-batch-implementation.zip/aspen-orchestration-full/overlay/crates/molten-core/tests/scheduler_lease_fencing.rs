//! Regression tests for the reference scheduler, not a live-ownership proof.
use molten_core::fabric::ReferenceSystemKind;
use molten_core::fabric_simulation::*;

fn apply(state: &ReferenceServiceState, operation: DistributedSchedulerOperation) -> ReferenceServiceState {
    apply_reference_operation(state, &ReferenceServiceOperation::DistributedScheduler(operation))
        .expect("reference transition").next
}
fn leased() -> ReferenceServiceState {
    let initial = initial_reference_state(ReferenceSystemKind::DistributedScheduler);
    let submitted = apply(&initial, DistributedSchedulerOperation::Submit { job_id: "job-a".into() });
    apply(&submitted, DistributedSchedulerOperation::Lease { job_id: "job-a".into(), owner: "worker-a".into() })
}
fn complete(owner: &str, epoch: u64) -> ReferenceServiceOperation {
    ReferenceServiceOperation::DistributedScheduler(DistributedSchedulerOperation::Complete {
        job_id: "job-a".into(), owner: owner.into(), lease_epoch: epoch,
        completion_ref: format!("blake3:{}", "a".repeat(64)),
    })
}
fn failover(state: &ReferenceServiceState, owner: &str) -> ReferenceServiceState {
    apply(state, DistributedSchedulerOperation::Failover { job_id: "job-a".into(), next_owner: owner.into() })
}
fn assert_epoch_denied(state: &ReferenceServiceState, owner: &str, expected: u64, actual: u64) {
    let before = state.clone();
    assert_eq!(
        apply_reference_operation(state, &complete(owner, actual)),
        Err(ReferenceServiceIssue::LeaseEpochMismatch { job_id: "job-a".into(), expected, actual }),
    );
    assert_eq!(*state, before);
}

#[test]
fn reference_scheduler_rejects_aba_delayed_completion() {
    let a1 = leased();
    let b2 = failover(&a1, "worker-b");
    let a3 = failover(&b2, "worker-a");
    assert_epoch_denied(&a3, "worker-a", 3, 1);
    assert!(apply_reference_operation(&a3, &complete("worker-a", 3)).is_ok());
}

#[test]
fn reference_scheduler_rejects_old_attempt_after_same_owner_replacement() {
    let a2 = failover(&leased(), "worker-a");
    assert_epoch_denied(&a2, "worker-a", 2, 1);
    assert!(apply_reference_operation(&a2, &complete("worker-a", 2)).is_ok());
}

#[test]
fn reference_scheduler_rejects_zero_and_future_epochs() {
    let a1 = leased();
    assert_epoch_denied(&a1, "worker-a", 1, 0);
    assert_epoch_denied(&a1, "worker-a", 1, 2);
}

#[test]
fn reference_scheduler_accepts_current_epoch_once() {
    let done = apply_reference_operation(&leased(), &complete("worker-a", 1)).unwrap();
    assert!(matches!(
        apply_reference_operation(&done.next, &complete("worker-a", 1)),
        Err(ReferenceServiceIssue::DuplicateAuthoritativeCompletion(_))
    ));
}
