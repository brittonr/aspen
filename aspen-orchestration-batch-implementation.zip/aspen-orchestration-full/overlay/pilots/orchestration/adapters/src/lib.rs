#![forbid(unsafe_code)]
//! Capability-rooted infrastructure adapters and the explicit composition boundary.
pub mod root;
pub mod identity;
pub mod storage;
pub mod policy;
pub mod protocol;
pub mod transport;
pub mod wasm;
pub mod service;
pub use root::*;
pub use identity::*;
pub use storage::*;
pub use policy::*;
pub use protocol::*;
pub use transport::*;
pub use wasm::*;
pub use service::*;
use molten_batch_application::Error;
fn invalid(e:impl std::fmt::Display)->Error{Error::Invalid(e.to_string())}
