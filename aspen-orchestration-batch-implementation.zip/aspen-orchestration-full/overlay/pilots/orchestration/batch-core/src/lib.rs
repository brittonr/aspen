#![no_std]
#![forbid(unsafe_code)]
//! Pure batch and worker state machines. Every observation is explicit input.
extern crate alloc;
mod model;
mod controller;
mod worker;
pub use model::*;
pub use controller::*;
pub use worker::*;

mod policy;
pub use policy::*;
