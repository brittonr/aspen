# Native Molten integration boundary

This delivery has two deliberately separate parts:

1. A guarded patch to the existing fabric simulation scheduler that requires an
   exact lease epoch on completion, with regression tests.
2. An executable standalone batch service under `pilots/orchestration`, using real
   Redb, Iroh and Wasmtime adapters behind application-owned ports.

The second part is NOT registered in `SystemExtensionHost` and does not change
`src/node/daemon.rs`, the root Cargo workspace, the ALPN registry, or any admitted
system-tier manifest. It does not produce invented Basalt/Cairn admission receipts.
Its explicit operator policy is a different, named deployment profile.

## How the boundary should be connected

| Existing owner | New contract | Required integration law |
|---|---|---|
| System extension lifecycle / generation | Controller and WorkerService driving adapters | Exact manifest, service identity, active generation and port bindings must be admitted before callbacks or effects. |
| Membership / `RoleAssignment` / placement | `PlacementPort`, controller assignment input | Reuse observed descriptors and exact epochs; map an advisory placement into one authoritative reservation transaction. |
| Assignment persistence / consistency | `StateStore` | Workload insertion, capacity accounting and allocation ownership must share one authority. Do not mirror independent successful writes and call them atomic. |
| Coordination delivery | `WorkerClient` and assignment outbox | Preserve the exact attempt fence and unknown outcomes; a delivery acknowledgement is not execution completion. |
| Content store / replication | `ContentPort` | Reuse verified bytes and manifests through an explicit identity conversion; do not assume the standalone wrapper's content id equals an existing Molten object id. |
| Basalt / provenance / resource admission | `AdmissionPort` | Recheck real current policy/capability/provenance/resource facts. An identity hash or signed transport peer is not a capability. |
| Execution and supervision | `ExecutionPort` | Advertise the exact supported runtime and teardown evidence; the in-process recovery assumption does not apply to native or VM processes. |
| Evidence / observability | `ObservabilityPort` | Add canonical evidence at semantic boundaries and read-only bounded status, not per-packet receipts or authority inferred from counters. |

The orchestration semantic core should remain an extension-owned crate. Its
commands, attempts, DAG behavior and retry policy must not move into node-core
semantics. Infrastructure adaptation should not redefine those decisions.

## Unimplemented native/production integration

Actual SystemExtensionHost installation and callback routing, canonical fabric
port registration, Basalt/Cairn integration, shared reservation storage,
coordination-delivery composition, root content-id translation, live consistency
for controller failover, persistent services and production qualification still
require implementation and their own tests. The standalone service is not an
implicit fallback for any of them.

Root baseline for the companion source patch:
`bb6f3830ee7327da9875ea85a8c8e25697eddc35`. The guarded installer refuses another
commit or changed source blobs. Reconcile a later branch explicitly rather than
removing the guards. No GitHub write was performed for this delivery.
