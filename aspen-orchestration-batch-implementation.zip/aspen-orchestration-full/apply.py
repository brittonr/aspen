#!/usr/bin/env python3
"""Generate and validate the batch implementation patch against an exact Aspen checkout.

No network access, branch changes, commits, dependency installation, or pushes.
Default: dry-run. Add --apply to change the working tree after validation.
Requires Python 3.11+ and Git. Never runs Rust code or claims Rust tests passed.
"""
from __future__ import annotations
import argparse
import difflib
import hashlib
from pathlib import Path
import re
import subprocess
import sys

BASE = "bb6f3830ee7327da9875ea85a8c8e25697eddc35"
ORIGINALS = {
    "crates/molten-core/src/fabric_simulation/reference.rs": "e683270d24ef2dbd2a47f61a7b0c2283b367d771",
    "crates/molten-core/src/fabric_simulation/tests.rs": "61ad580cfde3433c18f7387c91730f5e7b40dce8",
    "src/fabric_simulation/reference.rs": "2a15d1a2d6eb4ba19990f6225e30f30d498139a1",
}

def git(repo: Path, *args: str, data: bytes | None = None) -> bytes:
    done = subprocess.run(["git", "-C", str(repo), *args], input=data, capture_output=True, check=False)
    if done.returncode:
        raise RuntimeError(done.stderr.decode("utf-8", errors="replace").strip())
    return done.stdout

def replace_once(text: str, old: str, new: str) -> str:
    if text.count(old) != 1:
        raise ValueError(f"Expected exactly one patch anchor, found {text.count(old)}: {old[:90]!r}")
    return text.replace(old, new, 1)

def patch_reference(text: str) -> str:
    text = replace_once(text,
        "    Complete {\n        job_id: String,\n        owner: String,\n        completion_ref: String,\n    },",
        "    Complete {\n        job_id: String,\n        owner: String,\n        lease_epoch: u64,\n        completion_ref: String,\n    },")
    text = replace_once(text, "    MissingLeaseOwner(String),",
        "    LeaseEpochMismatch {\n        job_id: String,\n        expected: u64,\n        actual: u64,\n    },\n    MissingLeaseOwner(String),")
    text = replace_once(text,
        "        DistributedSchedulerOperation::Complete {\n            job_id,\n            owner,\n            completion_ref,\n        } => {",
        "        DistributedSchedulerOperation::Complete {\n            job_id,\n            owner,\n            lease_epoch,\n            completion_ref,\n        } => {")
    return replace_once(text, "            job.phase = ReferenceJobPhase::Completed;",
        "            if *lease_epoch != job.lease_epoch {\n"
        "                return Err(ReferenceServiceIssue::LeaseEpochMismatch {\n"
        "                    job_id: job_id.clone(),\n"
        "                    expected: job.lease_epoch,\n"
        "                    actual: *lease_epoch,\n"
        "                });\n"
        "            }\n"
        "            job.phase = ReferenceJobPhase::Completed;")

def patch_constructors(text: str, expected_count: int) -> str:
    pattern = re.compile(
        r"(DistributedSchedulerOperation::Complete \{\n(?P<indent>[ \t]+)job_id: [^\n]+\n(?P=indent)owner: [^\n]+\n)"
    )
    changed, count = pattern.subn(lambda m: m[1] + m["indent"] + "lease_epoch: 1,\n", text)
    if count != expected_count:
        raise ValueError(f"Expected {expected_count} completion constructors; found {count}")
    return changed

def unified(path: str, old: str, new: str, is_new: bool = False) -> str:
    return "".join(difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True),
        fromfile="/dev/null" if is_new else f"a/{path}", tofile=f"b/{path}", n=3))

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, type=Path)
    parser.add_argument("--apply", action="store_true", help="Apply the validated patch; default is dry-run")
    parser.add_argument("--output", type=Path, default=Path("aspen-orchestration-batch.patch"))
    args = parser.parse_args()
    repo = args.repo.resolve(strict=True)
    if Path(git(repo, "rev-parse", "--show-toplevel").decode().strip()).resolve() != repo:
        raise ValueError("--repo must be the repository root")
    if git(repo, "rev-parse", "HEAD").decode().strip() != BASE:
        raise ValueError(f"Expected HEAD {BASE}. Use a separate branch/worktree at this commit; no reset is performed.")
    if git(repo, "status", "--porcelain", "--untracked-files=all").strip():
        raise ValueError("Working tree must be clean, including untracked files. Keep this bundle OUTSIDE the checkout.")
    output = args.output.resolve()
    if output == repo or repo in output.parents:
        raise ValueError("Write --output outside the checkout so dry-run does not dirty the repository")
    if output.exists():
        raise ValueError(f"Refusing to overwrite existing output: {output}")
    patch = []
    for path, expected_sha in ORIGINALS.items():
        data = (repo / path).read_bytes()
        actual_sha = hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest()
        if actual_sha != expected_sha:
            raise ValueError(f"Source drift in {path}: expected {expected_sha}, got {actual_sha}")
        original = data.decode("utf-8")
        changed = patch_reference(original) if path == next(iter(ORIGINALS)) else patch_constructors(
            original, 3 if path.endswith("tests.rs") else 1)
        patch.append(unified(path, original, changed))
    overlay = Path(__file__).resolve().parent / "overlay"
    for file in sorted(overlay.rglob("*")):
        if file.is_symlink():
            raise ValueError(f"Symlinks are not accepted: {file}")
        if not file.is_file():
            continue
        relative = file.relative_to(overlay).as_posix()
        target = repo / relative
        if target.exists() or target.is_symlink():
            raise ValueError(f"Refusing to replace new-file target: {relative}")
        if any(parent.is_symlink() for parent in target.parents if parent != repo and repo in parent.parents):
            raise ValueError(f"Symlinked target directory: {relative}")
        patch.append(unified(relative, "", file.read_text(encoding="utf-8"), is_new=True))
    payload = "".join(patch).encode()
    # Check against the full user's checkout, not only the fetched source windows.
    git(repo, "apply", "--check", "-", data=payload)
    with output.open("xb") as handle:
        handle.write(payload)
    if args.apply:
        git(repo, "apply", "-", data=payload)
    print(f"{'Applied' if args.apply else 'Validated; not applied'}: {output}")
    print("No Rust tests have been run by this installer. See overlay/pilots/orchestration/README.md.")
    return 0

if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, UnicodeError, ValueError, RuntimeError) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        raise SystemExit(1)
