# Aspen / Molten batch orchestration implementation

Source candidate based on `brittonr/aspen`, branch `molten`, commit
`bb6f3830ee7327da9875ea85a8c8e25697eddc35` (August 29, 2026).

**Rust compilation, Rust tests, and the end-to-end demo have not run in the
preparation environment. This is source for independent validation, not a
validated release. No GitHub branch, commit, or pull request was created.**

The bundle extends the first allocation slice into a standalone, single-controller,
multi-worker batch/DAG service. It includes real Redb persistence, Iroh peer-authenticated
RPC, import-free Wasmtime Component execution, canonical Preserves identities,
controller/worker recovery, cancellation fencing, resource reservations, data
publication, and operator commands. Infrastructure depends on application-owned
ports; the controller and worker transition laws remain pure.

## Start here

The workspace can be built directly from the extracted bundle, without modifying
an Aspen checkout:

```sh
cd overlay/pilots/orchestration
bash scripts/verify.sh
bash scripts/demo.sh
```

Use Rust 1.94 or newer with Cargo, rustfmt and clippy, a native C build toolchain,
Python 3.11+, and dependency-download access on the first run. The supplied
`rust-toolchain.toml` selects stable. The verification script formats the authored
source, runs the actual Rust tests, invokes Clippy, and builds the executable.
No resolved `Cargo.lock` is supplied; generate, review and retain it with the test
log. Compilation or test failures should be treated as real defects to resolve,
not as a reason to weaken assertions.

The demo starts a controller and one worker, submits a dependency graph, retrieves
its output, and retains a temporary run directory with logs. A separate Rust test
runs a controller and **two** workers, exercises independent placement, restart
persistence, duplicate submissions, peer rejection, and queued cancellation.
These tests are authored, not reported passing.

## Source layout

| Location | Responsibility |
|---|---|
| `overlay/pilots/orchestration/core` | Original allocator-free `no_std` allocation FSM, plus checked restore. |
| `overlay/pilots/orchestration/application` | Original allocation use cases and owned ports. |
| `overlay/pilots/orchestration/batch-core` | Pure DAG, scheduling, worker-journal, admission-rule and recovery transitions. |
| `overlay/pilots/orchestration/batch-application` | Controller/worker effect ordering over owned ports. |
| `overlay/pilots/orchestration/codec` | Canonical Preserves projection and verified reconstruction. |
| `overlay/pilots/orchestration/adapters` | Redb, capability-rooted files, Iroh, Wasmtime, and composition. |
| `overlay/pilots/orchestration/cli` | Operator interface and separate-process integration test. |
| `overlay/crates/molten-core/tests/scheduler_lease_fencing.rs` | Original reference scheduler regressions. |
| `apply.py` | Guarded patch generator for the exact Aspen base. |
| `validation` | Checks actually run on this expanded source. |
| `first-slice-validation` | Historical first-slice checks; not evidence for the expanded Rust implementation. |

Read `overlay/pilots/orchestration/README.md` for enrollment, cross-host configuration,
commands, bounds and deployment assumptions. `VALIDATION.md` distinguishes authored
tests from executed checks. The workspace's `docs/MOLTEN-INTEGRATION.md` identifies
what remains to connect this standalone service to the admitted Molten node runtime.

## Scope boundary

This is the **single-controller, import-free Wasm batch profile**, not the full
set of future orchestration features. It is **not yet a manifest-installed Molten
system extension** and does not consume the root node's Basalt/Cairn admission,
shared placement/reservation ledger, or coordination-delivery service. Its explicit
operator policy and separate database are a distinct standalone profile, not
substitutes that claim those stronger contracts.

Controller HA/Raft integration, persistent services, containers/native commands,
WASI/hostcalls, rolling deployments, automatic uncertain-worker replacement,
history GC, production isolation and WAN/relay qualification are not implemented.
Do not use this source as an already validated orchestrator for valuable workloads.

## Apply the reference fix and workspace to Aspen

Keep the bundle outside the checkout. Use a new clean worktree at the exact base:

```sh
git worktree add -b orchestration/batch-runtime ../aspen-orchestration \
  bb6f3830ee7327da9875ea85a8c8e25697eddc35
```

From this bundle directory, generate and check a patch without changing that checkout:

```sh
python3 apply.py --repo /absolute/path/to/aspen-orchestration \
  --output /tmp/aspen-orchestration-batch.patch
```

Review it, then apply using Git:

```sh
git -C /absolute/path/to/aspen-orchestration apply --check /tmp/aspen-orchestration-batch.patch
git -C /absolute/path/to/aspen-orchestration apply /tmp/aspen-orchestration-batch.patch
```

The installer checks the exact HEAD, all three original Git blob identities, patch
anchors, a clean worktree, and absence of new-file targets. It does not reset,
force-push, replace existing code, or silently rebase onto a moved branch. If the
first slice is already installed, use a separate clean base worktree and reconcile
the overlay changes deliberately; the installer will refuse to overwrite it.

The companion patch requires `lease_epoch` on reference scheduler completion and
updates all known constructors. Run `scripts/reference-tests.sh` from the installed
workspace with Aspen's own pinned dependencies available. The independent workspace
build does **not** validate the root-crate modification.

Repository-owned changes follow the project's `AGPL-3.0-or-later` license. Dependencies
retain their own licenses; no third-party source or private credentials are bundled.
